# sET WORKING DIRECTORY 
setwd('D:/Sean/SAS/Methodology_verification')

install.packages("vcd")
install.packages("corrplot")

library(data.table)
library(here)
library(vcd)
library(corrplot)
library(xlsx)

# Create cramer's V martix 
data <- fread(here('Data', 'sample_variables_BIPD.csv'))
data_nominal <- data[,-c('ST_CD', 'PHYS_POL_KEY', 'PP', 'BIPD_ECY', 'TERR_MDL', 'rownumber', 'VAGE_RAW','PUC_GRP_FLEET_CR_GRP_FLEET')]

  # Create empty mattix for V-value
    empty_matrix <- matrix(ncol = length(data_nominal),
                       nrow = length(data_nominal),
                       dimnames = list(names(data_nominal),
                                       names(data_nominal)
                                       )
                       )
    
  # Calculate V-value and return to v_matrix
    cal_v <- function (m,df) {
      for (r in seq (nrow (m))) {
        for (c in seq (ncol (m))) {
          m[[r, c]] <- assocstats (table (df[[r]], df[[c]]))$cramer
        }
      }
      return(m)
    }
    
# Get Cramer'V correlation matrix 
v_matrix <- cal_v(empty_matrix, data_nominal)
corrplot (v_matrix)

# Step 1 vs Step 2 Cramer'v correlation matrix
v_matrix_12 <- v_matrix

# Export result
write.xlsx(v_matrix,here('Analysis','V_Matrix.xlsx'))
  
