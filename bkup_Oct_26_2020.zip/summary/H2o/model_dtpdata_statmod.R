#Set working environment
setwd('D:/Sean/H2O')

library("here")
library("data.table")
library("XLConnect")
library("dplyr")
library('reshape2')
library('tweedie')
library("statmod")

# TWEEDIE CONSTANT ONLY MODEL - statmod package

for(j in 0:20){
  dt = get(paste0("dtp",1.5+0.01*j))
  power = 1.5+0.01*j 
  outcome <- paste0('outcome_p',1.5+0.01*j)
  assign(outcome, data.table())
  
  act_mean <- sapply(dt,mean)
  act_var <- sapply(dt,var)
  
  out_beta <- rep(NA, length(dt))
  out_phi <- rep(NA, length(dt))
  number = 1
  
  for (i in 1:length(dt)){
    dependent = colnames(dt)[i]
    mdl <- glm(get(dependent)~ 1,data = dt, 
               family=tweedie(var.power=power,link.power=0),na.action = na.omit)
    
    beta <- coefficients(mdl)
    phi <- summary(mdl)$dispersion
    
    out_beta[number] <- as.numeric(beta)
    out_phi[number] <- as.numeric(phi)
    number = number + 1
  }
  
  get(outcome)[,phi:= colnames(dt)]
  get(outcome)[,out_beta:= out_beta]
  get(outcome)[,out_phi:= out_phi]
  get(outcome)[,est_mean:= exp(out_beta)]
  get(outcome)[,est_var:= est_mean^power*out_phi]
  get(outcome)[,act_mean:= act_mean]
  get(outcome)[,act_var:= act_var]
  
  fwrite(get(outcome),
         paste0("D:/Sean/H2O/Output/sim_data/stat_mod",outcome,".csv"))
}


# Combine Result 
final <- data.table()
for(j in 0:20){
  dt = get(paste0("outcome_p",1.5+0.01*j))
  final <- rbind(final, dt)
}

fwrite(final,"D:/Sean/H2O/Output/sim_data/stat_mod/outcome.csv")

# P = 1.5 PHI around 2k CONSTANT ONLY MODEL 

dt <- dtp
power = 1.5 
outcome <- "outcome_p1.5_phi2k"
assign(outcome, data.table())

act_mean <- sapply(dt,mean)
act_var <- sapply(dt,var)

out_beta <- rep(NA, length(dt))
out_phi <- rep(NA, length(dt))
number = 1

for (i in 1:length(dt)){
  dependent = colnames(dt)[i]
  mdl <- glm(get(dependent)~ 1,data = dt, 
             family=tweedie(var.power=power,link.power=0),na.action = na.omit)
  
  beta <- coefficients(mdl)
  phi <- summary(mdl)$dispersion
  
  out_beta[number] <- as.numeric(beta)
  out_phi[number] <- as.numeric(phi)
  number = number + 1
}

get(outcome)[,phi:= colnames(dt)]
get(outcome)[,out_beta:= out_beta]
get(outcome)[,out_phi:= out_phi]
get(outcome)[,est_mean:= exp(out_beta)]
get(outcome)[,est_var:= est_mean^power*out_phi]
get(outcome)[,act_mean:= act_mean]
get(outcome)[,act_var:= act_var]

fwrite(get(outcome),
       paste0("D:/Sean/H2O/Output/sim_data/stat_mod/","outcome_p1.5_phi2k",".csv"))

#################################################
# DO j & i STEP SEPERATELY

for(j in 0:3){
  dt = get(paste0("dtp",1.5+0.01*j))
  power = 1.5+0.01*j 
  for (i in 0:3){
    tt <- glm("phi550"~ 1,data = dt, 
              family=tweedie(var.power=power,link.power=0),na.action = na.omit)
    return(tt)
  }
}


out_beta <- rep(NA, 3)
out_phi <- rep(NA, 3)
number = 1

for (i in 1:3){
  dependent = colnames(dtp1.5)[i]
  mdl <- glm(get(dependent)~ 1,data = dtp1.5, 
             family=tweedie(var.power=power,link.power=0),na.action = na.omit)
  
  beta <- coefficients(mdl)
  phi <- summary(mdl)$dispersion
  
  out_beta[number] <- as.numeric(beta)
  out_phi[number] <- as.numeric(phi)
  number = number + 1
}

outcome <- data.table(out_beta,out_phi)


