# SET ENVIRONMENT
library(data.table)
library(odbc)
library(stringr)

# DEFINE ARGUMENT 
start_date <- "2017-01-01"
end_date <- "2019-12-31"
uid <- "x011870"
pwd <- readLines('U:/x011870/pswd.txt', warn = FALSE)
var_lib_path <- "D:/Sean/8.0_CAPP/Off_Balance/BLOCK_1_2_on_2019/Data/XLS_FILE"
MN_PIF_day <- "2019-06-28"
B1_PIF_day <- "2019-11-30"

###################################
# GET VIOLATION CNT AT DRVR LEVEL #
###################################
# CONNECT TO CAW
caw_con <- dbConnect(odbc(), 'DB2P', uid=uid, pwd=pwd)

# VIOLATIONS QUERY
viol_qry <- 
  "
  SELECT 
  CAW.DRIVER_VIOL.ST_CD, 
  CAW.DRIVER_VIOL.PHYS_POL_KEY, 
  CAW.DRIVER_VIOL.PHYS_DRVR_KEY, 
  CAW.DRIVER_VIOL.VIOL_CD, 
  CAW.DRIVER_VIOL.DRVR_INCID_DT, 
  CAW.DRIVER_VIOL.DRVR_PNT_SRCE_CD
  FROM 
  CAW.DRIVER_VIOL
  WHERE 
  CAW.DRIVER_VIOL.POL_EXPR_YR IN (pol_expr_yrs)
  ;
"

# DRIVER LICIENCE NBR QUERY
dr_lic_qry <- 
  "
  SELECT 
  CAW.DRVR_SEC_VIEW.ST_CD,
  CAW.DRVR_SEC_VIEW.PHYS_POL_KEY,
  CAW.DRVR_SEC_VIEW.PHYS_DRVR_KEY,
  CAW.DRVR_SEC_VIEW.DRVR_LIC_NBR 
  FROM
  CAW.DRVR_SEC_VIEW 
  WHERE 
  CAW.DRVR_SEC_VIEW.POL_EXPR_YR IN (pol_expr_yrs)
  ;
  "

# POLICY DATES QUERY
pol_qry <- 
  "
  SELECT 
  CAW.POLICY.ST_CD, 
  CAW.POLICY.PHYS_POL_KEY,
  CAW.POLICY.POL_ID_NBR,
  CAW.POLICY.RENW_CNT,
  CAW.POL_DATES.POL_EFF_DT,
  CAW.POL_DATES.POL_STOP_DT
  FROM 
  CAW.POL_DATES, 
  CAW.POLICY 
  WHERE 
  CAW.POL_DATES.POL_ID_CHAR = CAW.POLICY.POL_ID_CHAR 
  AND CAW.POL_DATES.RENW_SFX_NBR = CAW.POLICY.RENW_SFX_NBR 
  AND CAW.POL_DATES.POL_EXPR_YR = CAW.POLICY.POL_EXPR_YR 
  AND CAW.POL_DATES.POL_EFF_DT BETWEEN {d 'startdate'} AND {d 'enddate'}
;
"

# INSERT START AND END DATE INTO QUERY
min_pol_expr_yr <- lubridate::year(as.Date(start_date))
pol_expr_yrs <- seq(min_pol_expr_yr, lubridate::year(lubridate::today())+1)
pol_expr_yrs <- substr(pol_expr_yrs, 3, 4)
pol_expr_yrs <- paste(paste0("'", pol_expr_yrs, "'"), collapse=",")
viol_qry <- str_replace_all(viol_qry, 'pol_expr_yrs', pol_expr_yrs)
dr_lic_qry <- str_replace_all(dr_lic_qry, 'pol_expr_yrs', pol_expr_yrs)
pol_qry <- str_replace_all(pol_qry, 'startdate', start_date)
pol_qry <- str_replace_all(pol_qry, 'enddate', end_date)

# GET VIOLATION DATA
viol_data <- as.data.table(dbGetQuery(caw_con, viol_qry))

# GET DRIVER DATES DATA
dr_lic_data <- as.data.table(dbGetQuery(caw_con, dr_lic_qry))

# GET POLICY DATES
pol_data <- as.data.table(dbGetQuery(caw_con, pol_qry))

# JOIN VIOLATION AND LICIENCE NBR
viol_data <- dr_lic_data[viol_data, on=.(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY)]

# JOIN DATES AND VIOLATION DATA
viol_data <- merge(pol_data, viol_data, by=c('ST_CD', 'PHYS_POL_KEY'))

# FDL AND UDR HAVE VIOLATION DATE SET TO 11/11/1911
viol_data[DRVR_INCID_DT<=as.Date('1911-11-11'), DRVR_INCID_DT:=POL_EFF_DT]

# GET DRVR POS CNT
viol_data[,DRVR_POS_CNT:=substr(PHYS_DRVR_KEY,14,16)]

# LOOKUP VIOLATION CLASS
lookup_vio_cls <- fread(paste0(var_lib_path,'/lookup_vio_cls.csv'))
viol_data[, VIOL_CD:=trimws(VIOL_CD)]
viol_data <- lookup_vio_cls[viol_data, on=.(VIOL_CD)]
# IN IOWA SP1 CONSIDERED AS SPD IN MIN_CL
viol_data[ST_CD=='14' & VIOL_CD=='SP1', VIOL_CLS:='C']

# ASSIGN POINTS FOR FIRST VIOLATION
viol_data <- viol_data[order(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY, VIOL_CLS, DRVR_INCID_DT)]
first_viol_pts <- fread(paste0(var_lib_path,'/lookup_first_pts.csv'))
viol_data <- first_viol_pts[viol_data, on=.(VIOL_CLS)]

# ASSIGN POINTS FOR ADDITIONAL VIOLATIONS
addtl_viol_pts <- fread(paste0(var_lib_path,'/lookup_addtl_pts.csv'))
setnames(addtl_viol_pts, 'VIOL_PT', 'ADDTL_PT')
viol_data <- addtl_viol_pts[viol_data, on=.(VIOL_CLS)]
first_inds <- viol_data[, .I[1], by=.(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY, VIOL_CLS)]$V1
viol_data[!first_inds, VIOL_PT:=ADDTL_PT]

# REMOVE SAME DAY VIOLATIONS AND KEEP HIGHEST RANKED VIOLATION IN A DAY
viol_data <- viol_data[order(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY, DRVR_INCID_DT, -VIOL_PT, -VIOL_CLS)]
first_inds <- viol_data[, .I[1], by=.(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY, DRVR_INCID_DT)]$V1
viol_data <- viol_data[first_inds]

# COUNT VIOLATION BY TYPE
vio_type <- c("NP_AAF", "P_AAF", "MAJ", "MIN", "P_NAF", "NP_NAF", "DUI")
for (vio in vio_type) {viol_data[,(vio):=0]}

viol_data[,VIOL_CD:=trimws(VIOL_CD)]
viol_data[,DRVR_PNT_SRCE_CD:=trimws(DRVR_PNT_SRCE_CD)]

viol_data[VIOL_CD %in% c('AAF','AC1','CAF','CC1') & DRVR_PNT_SRCE_CD == 'P', P_AAF:= 1]
viol_data[VIOL_CD %in% c('AAF','AC1','CAF','CC1') & DRVR_PNT_SRCE_CD != 'P', NP_AAF:= 1]

viol_data[VIOL_CD %in% c('CRD','DR','FAR','FEL','FLE','FRA','HOM','LTS','RKD','SUS','WOC'), MAJ:= 1]

viol_data[VIOL_CD %in% c('DEV','FTC','FTY','IBK','IP','IT','LIC','MMV','NCS','OVW','SAF','SBV','SCH','SP1','SP2','SPD','SPO','WSR'), MIN:= 1]

viol_data[VIOL_CD %in% c('AFR','CNF','NAF') & DRVR_PNT_SRCE_CD == 'P', P_NAF:= 1]
viol_data[VIOL_CD %in% c('AFR','CNF','NAF') & DRVR_PNT_SRCE_CD != 'P', NP_NAF:= 1]

viol_data[VIOL_CD %in% c('DWI','BOT','REF'), DUI:= 1]

##################
# Driver Data    #
##################
drv_qry <- 
  "
SELECT 
CAW.POLICY.ST_CD, 
CAW.POLICY.PHYS_POL_KEY, 
CAW.DRVR_PUB_VIEW.PHYS_DRVR_KEY, 
CAW.DRVR_DATES.DRVR_AT_INCP_IND,
CAW.DRVR_DATES.DRVR_STRT_DT, 
CAW.DRVR_DATES.DRVR_STOP_DT, 
CAW.POLICY.POWER_UNIT_CNT,
CAW.DRVR_PUB_VIEW.DRVR_AGE, 
CAW.DRVR_PUB_VIEW.EXCL_IND, 
CAW.DRVR_PUB_VIEW.DRVR_MOCK_IND
FROM 
CAW.POL_DATES, 
CAW.DRVR_DATES, 
CAW.DRVR_PUB_VIEW, 
CAW.POLICY 
WHERE 
CAW.POL_DATES.POL_EFF_DT BETWEEN {d 'startdate'} and {d 'enddate'}
AND CAW.POLICY.POL_ID_CHAR = CAW.DRVR_PUB_VIEW.POL_ID_CHAR 
AND CAW.POLICY.RENW_SFX_NBR = CAW.DRVR_PUB_VIEW.RENW_SFX_NBR 
AND CAW.POLICY.POL_EXPR_YR = CAW.DRVR_PUB_VIEW.POL_EXPR_YR 
AND CAW.DRVR_PUB_VIEW.ST_CD = CAW.DRVR_DATES.ST_CD 
AND CAW.DRVR_PUB_VIEW.POL_ID_CHAR = CAW.DRVR_DATES.POL_ID_CHAR 
AND CAW.DRVR_PUB_VIEW.RENW_SFX_NBR = CAW.DRVR_DATES.RENW_SFX_NBR 
AND CAW.DRVR_PUB_VIEW.POL_EXPR_YR = CAW.DRVR_DATES.POL_EXPR_YR 
AND CAW.DRVR_PUB_VIEW.DRVR_POS_CNT = CAW.DRVR_DATES.DRVR_POS_CNT 
AND CAW.DRVR_PUB_VIEW.DRVR_VRSN_NBR = CAW.DRVR_DATES.DRVR_VRSN_NBR 
AND CAW.POLICY.POL_ID_CHAR = CAW.POL_DATES.POL_ID_CHAR 
AND CAW.POLICY.RENW_SFX_NBR = CAW.POL_DATES.RENW_SFX_NBR 
AND CAW.POLICY.POL_EXPR_YR = CAW.POL_DATES.POL_EXPR_YR 
GROUP BY
CAW.POLICY.ST_CD, 
CAW.POLICY.PHYS_POL_KEY, 
CAW.DRVR_PUB_VIEW.PHYS_DRVR_KEY, 
CAW.DRVR_DATES.DRVR_AT_INCP_IND,
CAW.DRVR_DATES.DRVR_STRT_DT,
CAW.DRVR_DATES.DRVR_STOP_DT, 
CAW.POLICY.POWER_UNIT_CNT,
CAW.DRVR_PUB_VIEW.DRVR_AGE, 
CAW.DRVR_PUB_VIEW.EXCL_IND, 
CAW.DRVR_PUB_VIEW.DRVR_MOCK_IND
;
"

# INSERT START AND END DATE INTO QUERY
drv_qry <- str_replace_all(drv_qry, 'startdate', start_date)
drv_qry <- str_replace_all(drv_qry, 'enddate', end_date)

# GET DRIVER DATA
drv_data <- as.data.table(dbGetQuery(caw_con, drv_qry))

# FILTER OUT MOCK DRIVERS, EXCLUDED DRIVERS
# drv_data <- drv_data[DRVR_AT_INCP_IND=='Y'] # Including drvr not at inception
drv_data <- drv_data[EXCL_IND!='Y']
drv_data <- drv_data[DRVR_MOCK_IND!='Y']

##################################
# GET VIOLATION COUNT FOR PRESTO #
##################################
# MERGE DRVR DATA WITH VIOLATION DATA (GET VIOLATION COUNT)
viol_cnt <- merge(drv_data, viol_data, by=c('ST_CD', 'PHYS_POL_KEY', 'PHYS_DRVR_KEY'))

# REMOVE DUPLICATE VIOLATION RECORDS DUE TO DRVR VERSION UPDATE
viol_cnt <- viol_cnt[order(ST_CD, PHYS_POL_KEY, -PHYS_DRVR_KEY, DRVR_POS_CNT, DRVR_LIC_NBR, VIOL_CD, DRVR_PNT_SRCE_CD, DRVR_INCID_DT)]
first_vio <- viol_cnt[,.I[1], by=.(ST_CD, PHYS_POL_KEY, DRVR_POS_CNT, DRVR_LIC_NBR, VIOL_CD, DRVR_PNT_SRCE_CD, DRVR_INCID_DT)]$V1
viol_cnt <- viol_cnt[first_vio]

# EXPORT
fwrite(viol_cnt, file = "D:/Sean/8.0_CAPP/Off_Balance/BLOCK_1_2_on_2019/Output/viol_cnt_for_presto.csv")

####### Test Scenario ################
test_viol_cnt <- viol_cnt[DRVR_INCID_DT > POL_EFF_DT & ST_CD == "22"]
test_viol_cnt_2 <- viol_cnt[DRVR_INCID_DT > as.Date(timeDate::timeLastDayInMonth(POL_EFF_DT)) & ST_CD == "22"]
test_viol_cnt_2 <- viol_cnt[DRVR_INCID_DT > POL_EFF_DT_ls_day & ST_CD == "22"]
test_viol_cnt_3 <- viol_cnt[DRVR_INCID_DT > POL_EFF_DT & DRVR_INCID_DT < POL_EFF_DT_ls_day & ST_CD == "22"]

test_viol_cnt_4 <- viol_cnt[DRVR_INCID_DT > (POL_EFF_DT + lubridate::days(30)) & ST_CD == "22"]
test_viol_cnt_4 <- test_viol_cnt_4[POL_EFF_DT > as.Date('2018-05-01') & DRVR_INCID_DT < as.Date('2019-07-01')]

test_viol_cnt_5 <- viol_cnt[DRVR_INCID_DT > POL_EFF_DT_ls_day & DRVR_INCID_DT < (POL_EFF_DT + lubridate::days(30)) & ST_CD == "22"]
#########################################

######################################################################
# Filtering violation based on PIF (THIS PROCESS MIMIC PRESTO PROCESS)
######################################################################
# GET PIF POL_ID GENERATE BY SAS;
pif <- fread(paste0(var_lib_path,'/PIF_POL_ID.csv'))
  # FORMAT ST_cD
  pif[,ST_CD:=str_pad(ST_CD, width=2, side='left', pad='0')]

# GET VIOL_CNT FOR PIF ONLY
pif_viol_cnt <- merge(pif, viol_cnt, by = c("ST_CD","POL_ID_NBR", "RENW_CNT"))
  
# REMOVE SAME VIOLATION ON DIFFERENT POLICY TERM
pif_viol_cnt <- pif_viol_cnt[order(ST_CD, POL_ID_NBR, -DRVR_STOP_DT, DRVR_LIC_NBR, VIOL_CD, DRVR_PNT_SRCE_CD, DRVR_INCID_DT)]
first_pif_vio <- pif_viol_cnt[,.I[1], by=.(ST_CD, POL_ID_NBR, DRVR_LIC_NBR, VIOL_CD, DRVR_PNT_SRCE_CD, DRVR_INCID_DT)]$V1
pif_viol_cnt <- pif_viol_cnt[first_pif_vio]
  
# TRIM DRIVER BASED ON DRVR_STOP_DT (GET DRVR BEFORE TRIM VIOL)
# GET DRVR_LIC_NBR ON PIF
pif_pol_key <- fread(paste0(var_lib_path,'/PIF_PHYS_POL_KEY.csv'))
  # FORMAT
  pif_pol_key[,ST_CD:=str_pad(ST_CD, width=2, side='left', pad='0')]
  pif_pol_key[,PHYS_POL_KEY:=as.character(PHYS_POL_KEY)]

# GET DRVR_LIC_NBR
pif_drvr <- merge(drv_data, dr_lic_data, by=c('ST_CD', 'PHYS_POL_KEY', 'PHYS_DRVR_KEY'))
# KEEP DRVR ON PIF TERM
pif_drvr <- merge(pif_drvr,pif_pol_key, by=c('ST_CD', 'PHYS_POL_KEY'))

# REMOVE DUPLICATE DRVR DUE TO VERSION/POSITION
drvr_on_pif <- pif_drvr[ ,.(DRVR_STRT_DT=min(DRVR_STRT_DT),
                            DRVR_STOP_DT=max(DRVR_STOP_DT)), 
                          by=.(ST_CD, PHYS_POL_KEY, DRVR_LIC_NBR)]

# GET POL_ID_NBR/ DROP PHYS_POL_KEY
drvr_on_pif[,POL_ID_NBR:=as.integer(substr(PHYS_POL_KEY,3,11))]
drvr_on_pif[,PHYS_POL_KEY:=NULL]

# REMOVE DRIVR DELETE BEFORE PIF PULLING DATE
drvr_on_pif <- drvr_on_pif[DRVR_STOP_DT>as.Date(MN_PIF_day)]

# REMOVE DRIVR ADDED AFTER PIF PULLING DATE
drvr_on_pif <- drvr_on_pif[DRVR_STRT_DT<as.Date(MN_PIF_day)]

# DELETE VIOL FROM DRVR NOT LISTED ON PIF PULLING DAY
drop_list <- c("DRVR_STOP_DT","DRVR_AGE","EXCL_IND","DRVR_MOCK_IND","VIOL_CLS","ADDTL_PT","VIOL_PT")
pif_viol_cnt[,c(drop_list):=NULL]

pif_viol_cnt <- merge(pif_viol_cnt, drvr_on_pif, by=c("ST_CD", "POL_ID_NBR", "DRVR_LIC_NBR"))

# GET PIF POL CURRENT AND PRIOR TERM POL_EFF_DT
pol_eff_dt_data <- merge(pol_data, pif, by=c("ST_CD", "POL_ID_NBR", "RENW_CNT"))
pol_eff_dt_data <- pol_eff_dt_data[,.(PRI_POL_EFF_DT=min(POL_EFF_DT),
                                      CURR_POL_EFF_DT=max(POL_EFF_DT)),
                                     by=.(ST_CD, POL_ID_NBR)]
# GET FIRST DAY A VIOLATION WILL BE COUNT
pol_eff_dt_data[,FIRST_LKBK_DT:=PRI_POL_EFF_DT-lubridate::years(3)]
# GET LAST DAY A VIOLATION WILL BE COUNT (PRESTO STILL COUNTS VIOL AFTER CURENT TERM POL_EFF_DT BUT WITHIN THE SAME MONTH)
pol_eff_dt_data[,LAST_LKBK_DT :=as.Date(timeDate::timeLastDayInMonth(CURR_POL_EFF_DT))]

# REWRITE PRI_POL_EFF_DT CURR_POL_EFF_DT FOR NB TO LAST_LKBK_DT TO AVOID COUNT ERROR IN AGGREGATE STEP
pol_eff_dt_data[PRI_POL_EFF_DT==CURR_POL_EFF_DT, PRI_POL_EFF_DT:=LAST_LKBK_DT]
pol_eff_dt_data[PRI_POL_EFF_DT==LAST_LKBK_DT, CURR_POL_EFF_DT:=LAST_LKBK_DT]

# ATTACH DATE INFO
pif_viol_cnt <- pol_eff_dt_data[pif_viol_cnt, on=.(ST_CD, POL_ID_NBR)]

# TRIM VIOL BEFORE FIRST_LKBK_DT AND AFTER LAST_LKBK_DT
pif_viol_cnt <- pif_viol_cnt[DRVR_INCID_DT >= FIRST_LKBK_DT & DRVR_INCID_DT <= LAST_LKBK_DT]

# AGGREGATE TO POLICY LEVEL
pif_viol_cnt_nb <- pif_viol_cnt[DRVR_INCID_DT < PRI_POL_EFF_DT, .(NP_AAFs=sum(NP_AAF),
                                                                  P_AAFs=sum(P_AAF),
                                                                  MAJs=sum(MAJ),
                                                                  MINs=sum(MIN),
                                                                  P_NAFs=sum(P_NAF),
                                                                  NP_NAFs=sum(NP_NAF),
                                                                  DUIs=sum(DUI)),
                                by=.(ST_CD, POL_ID_NBR)]

pif_viol_cnt_rbt <- pif_viol_cnt[DRVR_INCID_DT > PRI_POL_EFF_DT, .(RBT_NP_AAFs=sum(NP_AAF),
                                                                   RBT_P_AAFs=sum(P_AAF),
                                                                   RBT_MAJs=sum(MAJ),
                                                                   RBT_MINs=sum(MIN),
                                                                   RBT_P_NAFs=sum(P_NAF),
                                                                   RBT_NP_NAFs=sum(NP_NAF),
                                                                   RBT_DUIs=sum(DUI)),
                                 by=.(ST_CD, POL_ID_NBR)]
# FULL OUTER JOIN NB AND RBT VIOL COUNT 
pif_viol_cnt_summry <- merge(pif_viol_cnt_nb, pif_viol_cnt_rbt, by=c("ST_CD","POL_ID_NBR"), all = TRUE)

test6 <- pif_viol_cnt_summry[ST_CD=="22"]


fwrite(test6,"D:/Sean/8.0_CAPP/Off_Balance/BLOCK_1_2_on_2019/Data/test6.txt" )








