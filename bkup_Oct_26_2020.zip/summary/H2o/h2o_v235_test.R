#Set working environment
setwd('D:/Sean/H2O')

library("here")
library("data.table")
library("XLConnect")
library("dplyr")
library('ggplot2')
library('reshape2')
library('h2o')

h2o.init()

########
# BIPD #
########
data_path_bipd <<- 'Data/CAPP_BIPD_79C_LITE'
model_path_bipd <<- 'D:/Sean/H2O/Output/h2o_v235/BIPD'

#Import data
meta_data_bipd <- fread(here(data_path_bipd,"meta.csv"))
meta_data_bipd[, h2o_types:='unknown']
meta_data_bipd[types=='character', h2o_types:='string']
meta_data_bipd[types=='integer', h2o_types:='numeric']
meta_data_bipd[types=='numeric', h2o_types:='numeric']
meta_data_bipd[types=='Date', h2o_types:='time']
meta_data_bipd[types=='factor', h2o_types:='enum']

dt_bipd <- h2o.importFile('D:/Sean/H2O/Data/CAPP_BIPD_79C_LITE/data.csv',
                          destination_frame="", col.types=meta_data_bipd$h2o_types)

# Define variables
independent <<- c("UNLD_PCT",
                   "AGE_GRP01",
                   "AGE_GRP02",
                   "AGE_GRP03",
                   "AGE_GRP04",
                   "AGE_GRP05",
                   "AGE_GRP06",
                   "AGE_GRP08",
                   "AGE_GRP09",
                   "AGE_GRP10",
                   "AGE_GRP11",
                   "AGE_GRP12",
                   "AGE_GRP13",
                   "AGE_GRP14",
                   "PTS_GRP01",
                   "PTS_GRP02",
                   "PTS_GRP03",
                   "PTS_GRP04",
                   "PTS_GRP05",
                   "PTS_GRP06",
                   "PTS_GRP07",
                   "PTS_GRP08",
                   "PTS_GRP09",
                   "PTS_GRP10",
                   "PTS_GRP11",
                   "BTG_ME",
                   "BCG_ME",
                   "USE_GRP",
                   "CR_GRP_ME",
                   "UW_ROW",
                   "BIPD_SYM_GRP", 
                   "LIMIT_GRP",
                   "RADIUS_GRP",
                   "VAGE_RAW",
                   "VAGE_RAW2",
                   "VEH_PERS_USE_IND",
                   "PKG_DISC_NO_RT_NEW2",
                   "PIF_DISC",
                   "CDL_NORT_U_PCT_NEW",
                   "CDL_NORT_Y_PCT_NEW",
                   "USDOT_V41_GRPS",
                   "EFT_CURR_TERM",
                   "ST_GRP",
                   "TERR_MDL"
                  ) 
dependent <<- 'PP'
weight_var <<- 'BIPD_ECY'
power <- 1.624799

# Setup reference level
dt_bipd["BTG_ME"] <- h2o.relevel(dt_bipd["BTG_ME"], "999")
dt_bipd["BCG_ME"] <- h2o.relevel(dt_bipd["BCG_ME"], "999")
dt_bipd["USE_GRP"] <- h2o.relevel(dt_bipd["USE_GRP"], "999") 
dt_bipd["CR_GRP_ME"] <- h2o.relevel(dt_bipd["CR_GRP_ME"], "C0")
dt_bipd["UW_ROW"] <- h2o.relevel(dt_bipd["UW_ROW"], "1")
dt_bipd["BIPD_SYM_GRP"] <- h2o.relevel(dt_bipd["BIPD_SYM_GRP"], "16")
dt_bipd["LIMIT_GRP"] <- h2o.relevel(dt_bipd["LIMIT_GRP"], "999")
dt_bipd["RADIUS_GRP"] <- h2o.relevel(dt_bipd["RADIUS_GRP"], "50")
dt_bipd["VEH_PERS_USE_IND"] <- h2o.relevel(dt_bipd["VEH_PERS_USE_IND"], "N")
dt_bipd["PKG_DISC_NO_RT_NEW2"] <- h2o.relevel(dt_bipd["PKG_DISC_NO_RT_NEW2"], "N")
dt_bipd["PIF_DISC"] <- h2o.relevel(dt_bipd["PIF_DISC"], "N")
dt_bipd["USDOT_V41_GRPS"] <- h2o.relevel(dt_bipd["USDOT_V41_GRPS"], "Z98")
dt_bipd["EFT_CURR_TERM"] <- h2o.relevel(dt_bipd["EFT_CURR_TERM"], "N")
dt_bipd["ST_GRP"] <- h2o.relevel(dt_bipd["ST_GRP"], "9")

# Tweedie model
mdl <- h2o.glm(x = independent,
               y = dependent,
               #interaction_pairs = interaction_pairs,
               training_frame = dt_bipd,
               model_id = "CAPP_BIPD_79C_V325",
               seed = 44124,
               family = "tweedie",
               weights_column = weight_var, 
               tweedie_variance_power = power,
               tweedie_link_power = 0,
               solver = 'IRLSM',
               lambda = 0,
               standardize = FALSE,
               compute_p_values = TRUE,
               beta_epsilon = 1e-9,
               remove_collinear_columns = TRUE)

# Get Prediction
pred <- h2o.predict(mdl, dt_bipd)
pp_h2o <- as.data.table(pred)
coef <- h2o.coef(mdl)
coef_h2o <- as.data.table(coef)
coef_tab <- mdl@model$coefficients_table

fwrite(coef_tab,file="D:/Sean/H2O/Output/h2o_v235/BIPD/coeff.csv")
fwrite(pp_h2o,file="D:/Sean/H2O/Output/h2o_v235/BIPD/pred.csv")
h2o.saveModel(mdl, path = "D:/Sean/H2O/Output/h2o_v235/BIPD", force = TRUE)

# Compare with SAS output
h <- fread('D:/Sean/H2O/Output/h2o_v235/BIPD/pred.csv', select = c('predict'))
  h[,PRED := predict/exp(5.0761814098)]
s <- fread('D:/Sean/wumbo/Step_1_prediction_comparison/BIPD/BIPD_PRED_PP_SAS.csv')
ecy <- fread('D:/Sean/H2O/Data/CAPP_BIPD_79C_LITE/data.csv',select = c('BIPD_ECY'))

bipd_pp<-cbind(s,h,ecy)
setnames(bipd_pp,old=c('BIPD_PRED_PP','PRED'),new=c('pp_sas','pp_h2o'))
  bipd_pp[, pp_sas_adj:=pp_sas/weighted.mean(pp_sas, BIPD_ECY)]
  bipd_pp[, pp_h2o_adj:=pp_h2o/weighted.mean(pp_h2o, BIPD_ECY)]
  bipd_pp[, pch:=pp_h2o_adj/pp_sas_adj-1]
  bipd_pp[,pch_rd:=round(pch,digits = 3)]

ggplot(data = bipd_pp, aes(x = bipd_pp$pch_rd)) +
  geom_histogram(breaks=seq(-0.038,0.136,0.001)) +
   xlim(c(-0.038,0.136))

# Extra analysis for btg_me #
btg_me <- fread('D:/Sean/H2O/Data/CAPP_BIPD_79C_LITE/data.csv',select=c('BTG_ME'))
bipd_pp <- cbind(bipd_pp,btg_me)

bipd_pp_btg_997998 <- filter (bipd_pp, BTG_ME == 997 | BTG_ME == 998)
bipd_pp_btg_rest <- filter (bipd_pp, BTG_ME != 997 & BTG_ME != 998)

ggplot(data = bipd_pp_btg_997998, aes(x = bipd_pp_btg_997998$pch_rd)) +
  geom_histogram(breaks=seq(-0.038,0.136,0.001)) +
  xlim(c(-0.038,0.136)) +
  ylim(c(0,8e+05))

ggplot(data = bipd_pp_btg_rest, aes(x = bipd_pp_btg_rest$pch_rd)) +
  geom_histogram(breaks=seq(-0.038,0.136,0.001)) +
  xlim(c(-0.038,0.136)) +
  ylim(c(0,8e+05))

# Histogram by BIPD_ECY
ecy_sum_pch <- aggregate(BIPD_ECY ~ pch_rd, data = bipd_pp, FUN = sum)

ggplot(data = ecy_sum_pch) +
  geom_bar(aes(x = pch_rd, y = BIPD_ECY), stat = "identity")

ecy_sum_997998 <- aggregate(BIPD_ECY ~ pch_rd, data = bipd_pp_btg_997998, FUN = sum)
ecy_sum_rest <- aggregate(BIPD_ECY ~ pch_rd, data = bipd_pp_btg_rest, FUN = sum)

fwrite(ecy_sum_997998,file="D:/Sean/H2O/Output/h2o_v235/BIPD/pivot_bipd_pp_997998.csv")
fwrite(ecy_sum_rest,file="D:/Sean/H2O/Output/h2o_v235/BIPD/pivot_bipd_pp_rest.csv")

########
# COLL #
########

data_path_coll <<- 'Data/CAPP_COLL_79C_LITE'
model_path_coll <<- 'D:/Sean/H2O/Output/h2o_v235/COLL'

#Import data
meta_data_coll <- fread(here(data_path_coll,"meta.csv"))
meta_data_coll[, h2o_types:='unknown']
meta_data_coll[types=='character', h2o_types:='string']
meta_data_coll[types=='integer', h2o_types:='numeric']
meta_data_coll[types=='numeric', h2o_types:='numeric']
meta_data_coll[types=='Date', h2o_types:='time']
meta_data_coll[types=='factor', h2o_types:='enum']

dt_coll <- h2o.importFile('D:/Sean/H2O/Data/CAPP_COLL_79C_LITE/data.csv',
                          destination_frame="", col.types=meta_data_coll$h2o_types)

# Define indepent variablesh2o.load
independent <<- c("CR_GRP_ME",
                  "PIF_DISC",
                  "BTG_ME",
                  "DED_GRP",
                  "STATED_AMT_GRP",
                  "COLL_SYM_GRP",
                  "VAGE_RAW",
                  "VAGE_RAW2",
                  "FCC_GRP",
                  "V41_USDOT_SCR_GRPS",
                  "BCG_ME",
                  "PKG_DISC_NO_RT_NEW2",
                  "RADIUS_GRP",
                  "USE_GRP",
                  "VEH_PERS_USE_IND",
                  "UW_ROW",
                  "CDL_NORT_U_PCT_NEW",
                  "CDL_NORT_Y_PCT_NEW",
                  "TERR_MDL",
                  "ST_GRP",
                  "EFT_CURR_TERM"
) 
dependent <<- 'ADJ_PP0'
weight_var <<- 'ADJ_ECY0'
power <- 1.52

# Setup reference level
dt_coll["CR_GRP_ME"] <- h2o.relevel(dt_coll["CR_GRP_ME"], "C0")
dt_coll["PIF_DISC"] <- h2o.relevel(dt_coll["PIF_DISC"], "N")
dt_coll["BTG_ME"] <- h2o.relevel(dt_coll["BTG_ME"], "999")
dt_coll["DED_GRP"] <- h2o.relevel(dt_coll["DED_GRP"], "999")
dt_coll["STATED_AMT_GRP"] <- h2o.relevel(dt_coll["STATED_AMT_GRP"], "Z")
dt_coll["COLL_SYM_GRP"] <- h2o.relevel(dt_coll["COLL_SYM_GRP"], "9")
dt_coll["FCC_GRP"] <- h2o.relevel(dt_coll["FCC_GRP"], "999")
dt_coll["V41_USDOT_SCR_GRPS"] <- h2o.relevel(dt_coll["V41_USDOT_SCR_GRPS"], "Z98")
dt_coll["BCG_ME"] <- h2o.relevel(dt_coll["BCG_ME"], "999")
dt_coll["PKG_DISC_NO_RT_NEW2"] <- h2o.relevel(dt_coll["PKG_DISC_NO_RT_NEW2"], "N/A")
dt_coll["RADIUS_GRP"] <- h2o.relevel(dt_coll["RADIUS_GRP"], "50")
dt_coll["USE_GRP"] <- h2o.relevel(dt_coll["USE_GRP"], "999")
dt_coll["VEH_PERS_USE_IND"] <- h2o.relevel(dt_coll["VEH_PERS_USE_IND"], "N")
dt_coll["UW_ROW"] <- h2o.relevel(dt_coll["UW_ROW"], "4")
dt_coll["ST_GRP"] <- h2o.relevel(dt_coll["ST_GRP"], "41")
dt_coll["EFT_CURR_TERM"] <- h2o.relevel(dt_coll["EFT_CURR_TERM"], "N")

# Tweedie model
mdl <- h2o.glm(x = independent,
               y = dependent,
               #interaction_pairs = interaction_pairs,
               training_frame = dt_coll,
               model_id = "CAPP_COLL_79C_V325",
               seed = 44124,
               family = "tweedie",
               weights_column = weight_var, 
               tweedie_variance_power = power,
               tweedie_link_power = 0,
               solver = 'IRLSM',
               lambda = 0,
               standardize = FALSE,
               compute_p_values = TRUE,
               beta_epsilon = 1e-9,
               remove_collinear_columns = TRUE)

# Get Prediction
pred <- h2o.predict(mdl, dt_coll)
pp_h2o <- as.data.table(pred)
coef <- h2o.coef(mdl)
coef_h2o <- as.data.table(coef)
coef_tab <- mdl@model$coefficients_table

fwrite(coef_tab,file="D:/Sean/H2O/Output/h2o_v235/COLL/coeff.csv")
fwrite(pp_h2o,file="D:/Sean/H2O/Output/h2o_v235/COLL/pred.csv")
h2o.saveModel(mdl, path = "D:/Sean/H2O/Output/h2o_v235/COLL", force = TRUE)

# Compare with SAS output
h <- fread('D:/Sean/H2O/Output/h2o_v235/coll/pred.csv', select = c('predict'))
  h[,PRED := predict/exp(5.889576144)]
s <- fread('D:/Sean/wumbo/Step_1_prediction_comparison/coll/coll_PRED_PP_SAS.csv')
ecy <- fread('D:/Sean/H2O/Data/CAPP_coll_79C_LITE/data.csv',select = c('ADJ_ECY0'))

coll_pp<-cbind(s,h,ecy)
setnames(coll_pp,old=c('COLL_PRED_PP','PRED'),new=c('pp_sas','pp_h2o'))
  coll_pp[, pp_sas_adj:=pp_sas/weighted.mean(pp_sas, ADJ_ECY0)]
  coll_pp[, pp_h2o_adj:=pp_h2o/weighted.mean(pp_h2o, ADJ_ECY0)]
  coll_pp[, pch:=pp_h2o_adj/pp_sas_adj-1]
  coll_pp[,pch_rd:=round(pch,digits = 3)]

ggplot(data = coll_pp, aes(x = coll_pp$pch_rd)) +
  geom_histogram(breaks=seq(-0.129,0.218,0.001)) +
  xlim(c(-0.129,0.218))

# Histogram by BIPD_ECY
ecy_sum_pch <- aggregate(ADJ_ECY0 ~ pch_rd, data = coll_pp, FUN = sum)

ggplot(data = ecy_sum_pch) +
  geom_bar(aes(x = pch_rd, y = ADJ_ECY0), stat = "identity")
