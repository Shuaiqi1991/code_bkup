# SET ENVIRONMENT 
setwd("C:/Sean/R")

library(data.table)
library(dplyr)
library(XLConnect)
library(here)
library(tidyverse)

# IMPORT MODELING DATA
dt <- fread("C:/Sean/R/DATA/CAPP_BIPD_79C_LITE/data.csv")

# LOAD COEF SAS
coef_sas <- fread(here("DATA","Var_Para_List.csv"), 
                  select = c("names","Level","sas_reb"))

  level <- lapply(unique(coef_sas$names), function(x){
    coef_sas[names==x, Level]
  })
  names(level) <- unique(coef_sas$names)
  level <- setDT(lapply(level, 'length<-',max(lengths(level))))[]
  
  coef <- lapply(unique(coef_sas$names), function(x){
    coef_sas[names==x, sas_reb]
  })
  names(coef) <- paste0(unique(coef_sas$names),"_sas_coef")
  coef <- setDT(lapply(coef,'length<-',max(lengths(coef))))[]
  
  fct <- lapply(unique(coef_sas$names), function(x){
    coef_sas[names==x, round(exp(sas_reb),2)]
  })
  names(fct) <- paste0(unique(coef_sas$names),"_sas_fct")
  fct <- setDT(lapply(fct,'length<-',max(lengths(fct))))[]
  
sas_coef <- cbind(level, coef)
sas_coef <- sas_coef %>% select(sort(names(.)))

# EXOPORT VAEG & CDL COEF
sas_vage <- sas_coef[,c(names(sas_coef)[grep("VAGE",names(sas_coef))]), with = F]
sas_cdl <- sas_coef[,c(names(sas_coef)[grep("CDL",names(sas_coef))]), with = F]
sas_pla <- na.omit(sas_coef[,c(names(sas_coef)[grep("PLA",names(sas_coef))]), with = F])

# CLEAN sas_fct
sas_fct <- cbind(level, fct)
sas_fct <- sas_fct %>% select(sort(names(.)))

clean <- c("AGE", "VAGE", "PTS", "BMT2", "ST_GRP", "TERR_MDL", "CDL", "UNLD", "PLA")
sas_fct <- sas_fct[,-c(names(sas_fct)[grep(paste(clean, collapse = "|"),
                                           names(sas_fct))]), with = F]
sas_fct <- sas_fct[,-c("BMT_NO_LIV", "BMT_NO_LIV_sas_fct", "BCG_RAD", "BCG_RAD_sas_fct"), with = F]
  
# READ AGE_PTS FACTOR TABLE
# SAS
sas <- fread(here("DATA","SAS_DRVR_FCT.csv"))
  
  level <- lapply(unique(sas$Var), function(x){
    sas[Var==x, Level]
  })
  names(level) <- unique(sas$Var)
  level <- setDT(lapply(level,'length<-',max(lengths(level))))[]
  
  coef <- lapply(unique(sas$Var), function(x){
    sas[Var==x, round(exp(coef),2)]
  })
  names(coef) <- paste0(unique(sas$Var),"_fct")
  coef <- setDT(lapply(coef,'length<-',max(lengths(coef))))[]

lk_sas <- cbind(level,coef)
lk_sas <- lk_sas %>% select(sort(names(.)))

# Creating factor level lookup Table for Numeric Variable 
wb <- loadWorkbook(here("DATA","factor_lvl_lkup.xlsx"))
fct_lvl_lkup <- readWorksheet(wb, sheet = getSheets(wb))

for (i in 1: length(fct_lvl_lkup)){
  var <- names(fct_lvl_lkup)[i]
  table <- as.data.table(fct_lvl_lkup[i])
  names(table) <- 
    gsub(paste0(var,"."), "", names(table))
  assign(var,table)
}
#######################
# CREATE DRVR_ADJ_FCT #
#######################
dt_drvr <- fread(here("DATA","DRVR_LIST.csv"))

# Clening  DRVR_AGE DRVR_PTS
dt_drvr[,AGE := DRVR_AGE]
dt_drvr[DRVR_AGE < 14, AGE := 14]
dt_drvr[DRVR_AGE > 99, AGE := 99]

dt_drvr[,POINTS := DRVR_PTS]
dt_drvr[DRVR_PTS < 0, POINTS := 0]
dt_drvr[DRVR_PTS > 50, POINTS := 50]

# MATCH FACTOR LEVEL
for (i in 1: length(fct_lvl_lkup)){
  table <- get(names(fct_lvl_lkup)[i])
  table <- subset(table,select = names(sort(sapply(table,class))))#reorder lkup table to put string in front (influence rolling join)
  count <- sum(sum(sapply(table,class) == "integer")
            ,sum(sapply(table,class) == "numeric"))
  
  if (count < 2){
    dt_drvr <- table[dt_drvr, on= c(names(table)[-1]), roll = -Inf]
  } 
  else {
     for (j in 2:length(table)){
       
       roundUpList <- function(x, list=unique(table[[j]])) {
         if(length(x) != 1) stop("'x' must be of length 1")
         list[[which(x <= list)[[1]]]]
       }
       
       dt_drvr[,paste0(names(table)[j],"_round"):= 
            as.numeric(lapply(dt_drvr[[which(names(table)[j] == names(dt_drvr))[[1]]]],roundUpList))]
     }
    names(table)[-1] <- paste0(names(table)[-1],"_round")
    dt_drvr <- table[dt_drvr, on= c(names(table)[-1])]
    dt_drvr <- dt_drvr[, .SD, .SDcols = ! names(dt_drvr) %like% "_round"]
  }
}


# MATCH FACTOR and PRODUCT OF FACTOR
dt_drvr[,factor:= 1]

for (i in 1:length(fct_lvl_lkup)){
  var <- names(fct_lvl_lkup)[i]
  fct <- paste0(names(fct_lvl_lkup)[i],"_fct")
  lk_table <- na.omit(subset(lk_sas,select = c(var,fct)))
  dt_drvr <- lk_table[dt_drvr, on = c(names(fct_lvl_lkup)[i])]
  dt_drvr[is.na(get(fct)),(fct):= 1]
  dt_drvr[,factor:= factor*.SD[[fct]]]
}

# CAP factor AT 9.99 to mimic PRESTO
dt_drvr[factor >= 9.99, factor := 9.99]

# ADJ FOR PUC > # OF DRIVER
UNLD <- lk_sas$UNLD_PCT_fct[1]
drvr_adj_dt <- dt_drvr[,.(factor = sum(factor), puc = max(POWER_UNIT_CNT), drvr_cnt = .N), 
                  by = c("ST_CD","PHYS_POL_KEY")]
drvr_adj_dt[,cnt := drvr_cnt]
drvr_adj_dt[puc > drvr_cnt, cnt := puc]
drvr_adj_dt[,factor_adj := factor]
drvr_adj_dt[puc > drvr_cnt, factor_adj:= factor + (puc-drvr_cnt)*UNLD]
drvr_adj_dt[,avg_drvr_fct:= factor_adj/cnt]
drvr_adj_dt <- drvr_adj_dt[,c("ST_CD","PHYS_POL_KEY","avg_drvr_fct")]
drvr_adj_dt[,avg_drvr_fct:= round(avg_drvr_fct,2)]

########
# VAGE #
########
dt_vage <- dt[,c(names(dt)[grep("VAGE",names(dt))]), with = F]
BIPD_ECY <- dt$BIPD_ECY
dt_vage[,BIPD_ECY := BIPD_ECY]
dt_vage[,sum:= 0]

  coef <- sas_vage$VAGE_RAW_sas_coef[1]
  dt_vage[,VAGE_RAW_coef:= VAGE_RAW*coef]
  dt_vage[,sum:= sum + VAGE_RAW_coef]
  
  coef <- sas_vage$VAGE_RAW2_sas_coef[1]
  dt_vage[,VAGE_RAW2_coef:= VAGE_RAW2*coef]
  dt_vage[,sum:= sum + VAGE_RAW2_coef]
  
  coef <- sas_vage$VAGE_RAW_2_sas_coef[1]
  dt_vage[,VAGE_RAW_2_coef:= VAGE_RAW_2*coef]
  
  coef <- na.omit(sas_vage[,c("BTG_VAGE", "BTG_VAGE_sas_coef")])
  coef[,BTG_VAGE:= as.integer(BTG_VAGE)]
  dt_vage <- coef[dt_vage, on = .(BTG_VAGE)]
  dt_vage[is.na(BTG_VAGE_sas_coef), BTG_VAGE_sas_coef:= 0]
  dt_vage[,sum:= sum + BTG_VAGE_sas_coef]

  coef <- na.omit(sas_vage[,c("BTG_VAGE", "BTG_VAGE_VAGE_RAW_2_sas_coef")])
  coef[,BTG_VAGE:= as.integer(BTG_VAGE)]
  dt_vage <- coef[dt_vage, on = .(BTG_VAGE)]
  dt_vage[,BTG_VAGE_VAGE_RAW_2_coef:= BTG_VAGE_VAGE_RAW_2_sas_coef*VAGE_RAW_2]
  dt_vage[is.na(BTG_VAGE_VAGE_RAW_2_coef), BTG_VAGE_VAGE_RAW_2_coef:= 0]
  dt_vage[,BTG_VAGE_VAGE_RAW_2_sas_coef:= NULL]
  dt_vage[,sum:= sum + BTG_VAGE_VAGE_RAW_2_coef]

dt_vage[,vage_fct:= exp(sum)]
  
# Factor for VAGE >= 15
dt_vage_a <- dt_vage[VAGE_RAW >= 15, c("VAGE_RAW","BTG_VAGE", "BIPD_ECY","vage_fct")]
vage_factor <- dt_vage_a[,list(vage_fct = weighted.mean(vage_fct,BIPD_ECY)), by = BTG_VAGE]

# MATCH BACK
for (i in 1:max(lengths(vage_factor))){
  lkup <- vage_factor[i]
  dt_vage[VAGE_RAW>= 15 & BTG_VAGE == lkup[[1]], vage_fct:= lkup[[2]]]
}

# Round 
dt_vage[,vage_fct:= round(vage_fct,2)]

#################################################
# CDL (BCG_RAD has coef = 1, so dismiss it here)#
#################################################
dt_cdl <- dt[,c(names(dt)[grep("CDL",names(dt))]), with = F]
BCG_RAD <- dt$BCG_RAD
dt_vage[, BCG_RAD := BCG_RAD]
dt_cdl[, sum:= 0]

  coef <- sas_cdl$CDL_NORT_Y_PCT_NEW_sas_coef[1]
  dt_cdl[,CDL_NORT_Y_PCT_NEW_coef:= CDL_NORT_Y_PCT_NEW *coef]
  dt_cdl[,sum:= sum + CDL_NORT_Y_PCT_NEW_coef]

  coef <- sas_cdl$CDL_NORT_Y_PCT_NEW_2_sas_coef[1]
  dt_cdl[,CDL_NORT_Y_PCT_NEW_2_coef:= CDL_NORT_Y_PCT_NEW_2 *coef]
  dt_cdl[,sum:= sum + CDL_NORT_Y_PCT_NEW_2_coef]
  
  coef <- sas_cdl$BCG_RAD_CDL_NORT_Y_PCT_NEW_2_sas_coef[1]
  dt_cdl[BCG_RAD == 1, BCG_RAD_CDL_NORT_Y_PCT_NEW_2_coef := 
           CDL_NORT_Y_PCT_NEW_2*coef]
  dt_cdl[is.na(BCG_RAD_CDL_NORT_Y_PCT_NEW_2_coef), 
         BCG_RAD_CDL_NORT_Y_PCT_NEW_2_coef := 0]
  dt_cdl[, sum:= sum + BCG_RAD_CDL_NORT_Y_PCT_NEW_2_coef]
  
dt_cdl[,cdl_fct:= round(exp(sum),2)]
  
#######
# PLA #
#######
dt_pla <- dt[,c("POL_RENW_IND", "PLA_CNT_GRP_PUC_GRP_FLEET")]

for (i in 1:max(lengths(sas_pla))){
  lkup <- sas_pla[i]
  dt_pla[POL_RENW_IND == 'Y' & PLA_CNT_GRP_PUC_GRP_FLEET == lkup[[1]], pla_fct:= round(exp(lkup[[2]]),2)]
}

dt_pla[is.na(pla_fct), pla_fct:= 1]
dt_pla[, pla_fct:= round(pla_fct,2)]

##########################
# REST VARIABLE FCT LKUP #
##########################
varlist <- names(sas_fct)[!grepl("_fct",names(sas_fct))]

for (i in 1:length(varlist)){
  var <- varlist[i]
  fct <- paste0(var,"_sas_fct")
  lkup <- na.omit(sas_fct[,c(var,fct), with = F])
  lkup[, (var):= as.factor(get(var))]
  dt[, (var):= as.factor(get(var))]
  dt <- lkup[dt, on = c(var)]
  dt[is.na(get(fct)), (fct):= 1]
} 

dt <- drvr_adj_dt[dt,on = .(ST_CD, PHYS_POL_KEY)]
dt[is.na(avg_drvr_fct), avg_drvr_fct:= 1]
dt[,vage_fct:= dt_vage$vage_fct] 
dt[, cdl_fct:= dt_cdl$cdl_fct] 
dt[, pla_fct:= dt_pla$pla_fct] 

####################################
# Create ROC (product of all _fct) #
####################################
varlist <- names(dt)[grep("_fct",names(dt))]
dt[,roc_sas:= 1]

for (i in 1:length(varlist)){
  var <- varlist[i]
  dt[,roc_sas:= roc_sas*get(var)]
}

roc_sas <- dt[,c("ST_CD","PHYS_POL_KEY","PP", "BIPD_ECY", "roc_sas")]
fwrite(roc_sas, file = "C:/Sean/R/DATA/roc_sas.csv")

####################################
# H2O part (only change fread file) do not change var name
###################################

# IMPORT MODELING DATA
dt <- fread("C:/Sean/R/DATA/CAPP_BIPD_79C_LITE/data.csv")

# LOAD COEF SAS
coef_sas <- fread(here("DATA","Var_Para_List.csv"), 
                  select = c("names","Level","h2o_reb"))

level <- lapply(unique(coef_sas$names), function(x){
  coef_sas[names==x, Level]
})
names(level) <- unique(coef_sas$names)
level <- setDT(lapply(level, 'length<-',max(lengths(level))))[]

coef <- lapply(unique(coef_sas$names), function(x){
  coef_sas[names==x, h2o_reb]
})
names(coef) <- paste0(unique(coef_sas$names),"_sas_coef")
coef <- setDT(lapply(coef,'length<-',max(lengths(coef))))[]

fct <- lapply(unique(coef_sas$names), function(x){
  coef_sas[names==x, round(exp(h2o_reb),2)]
})
names(fct) <- paste0(unique(coef_sas$names),"_sas_fct")
fct <- setDT(lapply(fct,'length<-',max(lengths(fct))))[]

sas_coef <- cbind(level, coef)
sas_coef <- sas_coef %>% select(sort(names(.)))

# EXOPORT VAEG & CDL COEF
sas_vage <- sas_coef[,c(names(sas_coef)[grep("VAGE",names(sas_coef))]), with = F]
sas_cdl <- sas_coef[,c(names(sas_coef)[grep("CDL",names(sas_coef))]), with = F]
sas_pla <- na.omit(sas_coef[,c(names(sas_coef)[grep("PLA",names(sas_coef))]), with = F])

# CLEAN sas_fct
sas_fct <- cbind(level, fct)
sas_fct <- sas_fct %>% select(sort(names(.)))

clean <- c("AGE", "VAGE", "PTS", "BMT2", "ST_GRP", "TERR_MDL", "CDL", "UNLD", "PLA")
sas_fct <- sas_fct[,-c(names(sas_fct)[grep(paste(clean, collapse = "|"),
                                           names(sas_fct))]), with = F]
sas_fct <- sas_fct[,-c("BMT_NO_LIV", "BMT_NO_LIV_sas_fct", "BCG_RAD", "BCG_RAD_sas_fct"), with = F]

# READ AGE_PTS FACTOR TABLE
# SAS
sas <- fread(here("DATA","H2O_DRVR_FCT.csv"))

level <- lapply(unique(sas$Var), function(x){
  sas[Var==x, Level]
})
names(level) <- unique(sas$Var)
level <- setDT(lapply(level,'length<-',max(lengths(level))))[]

coef <- lapply(unique(sas$Var), function(x){
  sas[Var==x, round(exp(coef),2)]
})
names(coef) <- paste0(unique(sas$Var),"_fct")
coef <- setDT(lapply(coef,'length<-',max(lengths(coef))))[]

lk_sas <- cbind(level,coef)
lk_sas <- lk_sas %>% select(sort(names(.)))

# Creating factor level lookup Table for Numeric Variable 
wb <- loadWorkbook(here("DATA","factor_lvl_lkup.xlsx"))
fct_lvl_lkup <- readWorksheet(wb, sheet = getSheets(wb))

for (i in 1: length(fct_lvl_lkup)){
  var <- names(fct_lvl_lkup)[i]
  table <- as.data.table(fct_lvl_lkup[i])
  names(table) <- 
    gsub(paste0(var,"."), "", names(table))
  assign(var,table)
}
#######################
# CREATE DRVR_ADJ_FCT #
#######################
dt_drvr <- fread(here("DATA","DRVR_LIST.csv"))

# Clening  DRVR_AGE DRVR_PTS
dt_drvr[,AGE := DRVR_AGE]
dt_drvr[DRVR_AGE < 14, AGE := 14]
dt_drvr[DRVR_AGE > 99, AGE := 99]

dt_drvr[,POINTS := DRVR_PTS]
dt_drvr[DRVR_PTS < 0, POINTS := 0]
dt_drvr[DRVR_PTS > 50, POINTS := 50]

# MATCH FACTOR LEVEL
for (i in 1: length(fct_lvl_lkup)){
  table <- get(names(fct_lvl_lkup)[i])
  table <- subset(table,select = names(sort(sapply(table,class))))#reorder lkup table to put string in front (influence rolling join)
  count <- sum(sum(sapply(table,class) == "integer")
               ,sum(sapply(table,class) == "numeric"))
  
  if (count < 2){
    dt_drvr <- table[dt_drvr, on= c(names(table)[-1]), roll = -Inf]
  } 
  else {
    for (j in 2:length(table)){
      
      roundUpList <- function(x, list=unique(table[[j]])) {
        if(length(x) != 1) stop("'x' must be of length 1")
        list[[which(x <= list)[[1]]]]
      }
      
      dt_drvr[,paste0(names(table)[j],"_round"):= 
                as.numeric(lapply(dt_drvr[[which(names(table)[j] == names(dt_drvr))[[1]]]],roundUpList))]
    }
    names(table)[-1] <- paste0(names(table)[-1],"_round")
    dt_drvr <- table[dt_drvr, on= c(names(table)[-1])]
    dt_drvr <- dt_drvr[, .SD, .SDcols = ! names(dt_drvr) %like% "_round"]
  }
}


# MATCH FACTOR and PRODUCT OF FACTOR
dt_drvr[,factor:= 1]

for (i in 1:length(fct_lvl_lkup)){
  var <- names(fct_lvl_lkup)[i]
  fct <- paste0(names(fct_lvl_lkup)[i],"_fct")
  lk_table <- na.omit(subset(lk_sas,select = c(var,fct)))
  dt_drvr <- lk_table[dt_drvr, on = c(names(fct_lvl_lkup)[i])]
  dt_drvr[is.na(get(fct)),(fct):= 1]
  dt_drvr[,factor:= factor*.SD[[fct]]]
}

# CAP factor AT 9.99 to mimic PRESTO
dt_drvr[factor >= 9.99, factor := 9.99]

# ADJ FOR PUC > # OF DRIVER
UNLD <- lk_sas$UNLD_PCT_fct[1]
drvr_adj_dt <- dt_drvr[,.(factor = sum(factor), puc = max(POWER_UNIT_CNT), drvr_cnt = .N), 
                       by = c("ST_CD","PHYS_POL_KEY")]
drvr_adj_dt[,cnt := drvr_cnt]
drvr_adj_dt[puc > drvr_cnt, cnt := puc]
drvr_adj_dt[,factor_adj := factor]
drvr_adj_dt[puc > drvr_cnt, factor_adj:= factor + (puc-drvr_cnt)*UNLD]
drvr_adj_dt[,avg_drvr_fct:= factor_adj/cnt]
drvr_adj_dt <- drvr_adj_dt[,c("ST_CD","PHYS_POL_KEY","avg_drvr_fct")]
drvr_adj_dt[,avg_drvr_fct:= round(avg_drvr_fct,2)]

########
# VAGE #
########
dt_vage <- dt[,c(names(dt)[grep("VAGE",names(dt))]), with = F]
BIPD_ECY <- dt$BIPD_ECY
dt_vage[,BIPD_ECY := BIPD_ECY]
dt_vage[,sum:= 0]

coef <- sas_vage$VAGE_RAW_sas_coef[1]
dt_vage[,VAGE_RAW_coef:= VAGE_RAW*coef]
dt_vage[,sum:= sum + VAGE_RAW_coef]

coef <- sas_vage$VAGE_RAW2_sas_coef[1]
dt_vage[,VAGE_RAW2_coef:= VAGE_RAW2*coef]
dt_vage[,sum:= sum + VAGE_RAW2_coef]

coef <- sas_vage$VAGE_RAW_2_sas_coef[1]
dt_vage[,VAGE_RAW_2_coef:= VAGE_RAW_2*coef]

coef <- na.omit(sas_vage[,c("BTG_VAGE", "BTG_VAGE_sas_coef")])
coef[,BTG_VAGE:= as.integer(BTG_VAGE)]
dt_vage <- coef[dt_vage, on = .(BTG_VAGE)]
dt_vage[is.na(BTG_VAGE_sas_coef), BTG_VAGE_sas_coef:= 0]
dt_vage[,sum:= sum + BTG_VAGE_sas_coef]

coef <- na.omit(sas_vage[,c("BTG_VAGE", "BTG_VAGE_VAGE_RAW_2_sas_coef")])
coef[,BTG_VAGE:= as.integer(BTG_VAGE)]
dt_vage <- coef[dt_vage, on = .(BTG_VAGE)]
dt_vage[,BTG_VAGE_VAGE_RAW_2_coef:= BTG_VAGE_VAGE_RAW_2_sas_coef*VAGE_RAW_2]
dt_vage[is.na(BTG_VAGE_VAGE_RAW_2_coef), BTG_VAGE_VAGE_RAW_2_coef:= 0]
dt_vage[,BTG_VAGE_VAGE_RAW_2_sas_coef:= NULL]
dt_vage[,sum:= sum + BTG_VAGE_VAGE_RAW_2_coef]

dt_vage[,vage_fct:= exp(sum)]

# Factor for VAGE >= 15
dt_vage_a <- dt_vage[VAGE_RAW >= 15, c("VAGE_RAW","BTG_VAGE", "BIPD_ECY","vage_fct")]
vage_factor <- dt_vage_a[,list(vage_fct = weighted.mean(vage_fct,BIPD_ECY)), by = BTG_VAGE]

# MATCH BACK
for (i in 1:max(lengths(vage_factor))){
  lkup <- vage_factor[i]
  dt_vage[VAGE_RAW>= 15 & BTG_VAGE == lkup[[1]], vage_fct:= lkup[[2]]]
}

# Round 
dt_vage[,vage_fct:= round(vage_fct,2)]

#################################################
# CDL (BCG_RAD has coef = 1, so dismiss it here)#
#################################################
dt_cdl <- dt[,c(names(dt)[grep("CDL",names(dt))]), with = F]
BCG_RAD <- dt$BCG_RAD
dt_vage[, BCG_RAD := BCG_RAD]
dt_cdl[, sum:= 0]

coef <- sas_cdl$CDL_NORT_Y_PCT_NEW_sas_coef[1]
dt_cdl[,CDL_NORT_Y_PCT_NEW_coef:= CDL_NORT_Y_PCT_NEW *coef]
dt_cdl[,sum:= sum + CDL_NORT_Y_PCT_NEW_coef]

coef <- sas_cdl$CDL_NORT_Y_PCT_NEW_2_sas_coef[1]
dt_cdl[,CDL_NORT_Y_PCT_NEW_2_coef:= CDL_NORT_Y_PCT_NEW_2 *coef]
dt_cdl[,sum:= sum + CDL_NORT_Y_PCT_NEW_2_coef]

coef <- sas_cdl$BCG_RAD_CDL_NORT_Y_PCT_NEW_2_sas_coef[1]
dt_cdl[BCG_RAD == 1, BCG_RAD_CDL_NORT_Y_PCT_NEW_2_coef := 
         CDL_NORT_Y_PCT_NEW_2*coef]
dt_cdl[is.na(BCG_RAD_CDL_NORT_Y_PCT_NEW_2_coef), 
       BCG_RAD_CDL_NORT_Y_PCT_NEW_2_coef := 0]
dt_cdl[, sum:= sum + BCG_RAD_CDL_NORT_Y_PCT_NEW_2_coef]

dt_cdl[,cdl_fct:= round(exp(sum),2)]

#######
# PLA #
#######
dt_pla <- dt[,c("POL_RENW_IND", "PLA_CNT_GRP_PUC_GRP_FLEET")]

for (i in 1:max(lengths(sas_pla))){
  lkup <- sas_pla[i]
  dt_pla[POL_RENW_IND == 'Y' & PLA_CNT_GRP_PUC_GRP_FLEET == lkup[[1]], pla_fct:= round(exp(lkup[[2]]),2)]
}

dt_pla[is.na(pla_fct), pla_fct:= 1]
dt_pla[, pla_fct:= round(pla_fct,2)]

##########################
# REST VARIABLE FCT LKUP #
##########################
varlist <- names(sas_fct)[!grepl("_fct",names(sas_fct))]

for (i in 1:length(varlist)){
  var <- varlist[i]
  fct <- paste0(var,"_sas_fct")
  lkup <- na.omit(sas_fct[,c(var,fct), with = F])
  lkup[, (var):= as.factor(get(var))]
  dt[, (var):= as.factor(get(var))]
  dt <- lkup[dt, on = c(var)]
  dt[is.na(get(fct)), (fct):= 1]
} 

dt <- drvr_adj_dt[dt,on = .(ST_CD, PHYS_POL_KEY)]
dt[is.na(avg_drvr_fct), avg_drvr_fct:= 1]
dt[,vage_fct:= dt_vage$vage_fct] 
dt[, cdl_fct:= dt_cdl$cdl_fct] 
dt[, pla_fct:= dt_pla$pla_fct] 

####################################
# Create ROC (product of all _fct) #
####################################
varlist <- names(dt)[grep("_fct",names(dt))]
dt[,roc_h2o:= 1]

for (i in 1:length(varlist)){
  var <- varlist[i]
  dt[,roc_h2o:= roc_h2o*get(var)]
}

roc_h2o <- dt[,c("ST_CD","PHYS_POL_KEY", "PP", "BIPD_ECY", "roc_h2o")]
fwrite(roc_h2o, file = "C:/Sean/R/DATA/roc_h2o.csv")

####################################
# COmbining and Analysis #
####################################
roc_sas <- fread(here("DATA","roc_sas.csv"))
roc_h2o <- fread(here("DATA","roc_h2o.csv"))

roc_sas[,roc_h2o:= roc_h2o$roc_h2o]
roc_sas[,pct_chg:= roc_h2o/roc_sas-1]
roc_sas[,pct_chg_rd:= round(pct_chg,3)]

####################################
# Plot #
####################################
ggplot(data = roc_sas, aes(x = pct_chg_rd)) +
  geom_histogram(breaks=seq(-0.069,0.078,0.001)) +
  xlim(c(-0.069,0.078)) + 
  ylim(c(0,550000))

# Hist by BIPD_ECY
ecy_sum_pch <- aggregate(BIPD_ECY ~ pct_chg_rd, data = roc_sas, FUN = sum)

ggplot(data = ecy_sum_pch) +
  geom_bar(aes(x = pct_chg_rd, y = BIPD_ECY), stat = "identity")

fwrite(ecy_sum_pch, file = "C:/Sean/R/DATA/ecy_sum_pch.csv")

############################################################  
# IMPORTANT FUNCTION
roundUpNice <- function(x, nice=c(29,59,75,99)) {
  if(length(x) != 1) stop("'x' must be of length 1")
  as.numeric(nice[[which(x <= nice)[[1]]]])
}

dt[,paste0(names(table)[j],"round"):= lapply(dt[[grep(names(table)[j],names(dt))[[1]]]],
                                             roundUpList)]

dt[,paste0(names(table)[j],"round"):= lapply(dt[[which(names(table)[j] == names(dt))[[1]]]],
                                             roundUpList)]

test2[,paste0(names(test2)[1],"round"):= as.numeric(lapply(test2[[which(names(test2)[1] == names(test2))[[1]]]],
                                             roundUpNice))]

test2[,paste0("AGE","_round") := lapply(test2[[grep("AGE",names(test2))[[1]]]],roundUpNice)]

grep("string",sapply(table,class))

dt %>% group_by(AGE_GRP) %>% summarize(lower = min(AGE))

test1 <- data.table(VAGE_RAW=integer(), BTG_VAGE= integer())
for (i in 0:14){
  for (j in 1:7){
    test2[,VAGE_RAW:= i]
    test2[,BTG_VAGE:= j]
    test1 <- rbind(test1,test2)
  }
}

ggplot(dt, aes(x=VAGE_RAW, y=PP)) + geom_point(aes(colour = factor(BMT_NO_LIV)))

sas_fct <- sas_fct[, c(names(sas_fct)[!grepl("_sas_coef",names(sas_fct))]), with = F]

# AGE_PTS_GRP JOIN

test1 <- as.data.table(select(AGE_PTS_GRP, names(AGE_PTS_GRP)[2]))
test1 <- unique(test1)
test1[,paste0(names(test1),"1"):= replicate(1,test1)]

test2 <- as.data.table(select(AGE_PTS_GRP, names(AGE_PTS_GRP)[3]))
test2 <- unique(test2)
test2[,paste0(names(test2),"1"):= replicate(1,test2)]

test <- test1[test, on=.(AGE), roll = -Inf]
test <- test2[test, on=.(POINTS), roll = -Inf]

names(AGE_PTS_GRP)[-1] <- paste0(names(AGE_PTS_GRP)[-1],"1")

test <- AGE_PTS_GRP[test, on= .(AGE1, POINTS1)]

test <- BMT2_PTS_GRP[test, on= .(POINTS, BMT2), roll = -Inf]

test3 <- rep.col(test3[[2]], 1)

# TEST DATASET

test <- as.data.table(
  cbind(AGE=c(15,20,28,30,60,76),POINTS=c(0,1,2,3,4,11),
          BMT2=c("BACON","TRUCK","BACON","BACON","BACON","BACON")))
test[,AGE := as.numeric(AGE)]
test[,POINTS := as.numeric(POINTS)]

table <- as.data.table(cbind(BMT2_PTS_GRP = c("00","01","02","03","04","GE5"), POINTS=c(0,1,2,3,4,50),
        BMT2=c("BACON","BACON","BACON","BACON","BACON","BACON")))
table[,POINTS:=as.numeric(POINTS)]

test <- table[test, on= c(names(table)[-1]), roll = -Inf]


