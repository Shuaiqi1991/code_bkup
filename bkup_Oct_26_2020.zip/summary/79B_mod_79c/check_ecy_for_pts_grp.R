# S1 CHECK
dt <- fread("D:/Sean/github/Casper/data/datasets/bipd_79b_2018_age_pts_s1/data.csv",
            select=c("BIPD_ECY","PTS_GRP_00",	"PTS_GRP_01",	"PTS_GRP_02",	"PTS_GRP_03",	
                     "PTS_GRP_04",	"PTS_GRP_05",	"PTS_GRP_06",	"PTS_GRP_07",	"PTS_GRP_08",	
                     "PTS_GRP_09",	"PTS_GRP_10",	"PTS_GRP_11","UNLD_PCT")
)

names(dt)
col_list <- names(dt)[-1]

for(col in col_list){
  dt[,(paste0(col,"_ecy")):= BIPD_ECY*get(col)]
}

summary <- sapply(dt,sum)
summary <- as.data.table(summary[grep("_ecy",names(summary))],keep.rownames = T)

# S2 CHECK
dt <- fread("D:/Sean/github/Casper/data/datasets/bipd_79b_2018_age_pts_s2/data.csv",
            select=c("BIPD_ECY","PTS_GRP_XX","PTS_GRP_00",	"PTS_GRP_01",	"PTS_GRP_02",	"PTS_GRP_03",	
                     "PTS_GRP_04",	"PTS_GRP_05",	"PTS_GRP_06",	"PTS_GRP_07",	"PTS_GRP_08",	
                     "PTS_GRP_09",	"PTS_GRP_10",	"PTS_GRP_11","UNLD_PCT")
)

names(dt)
col_list <- names(dt)[-1]
col_list <- names(dt)[grep("PTS",names(dt))]
col_list <- c("PTS_GRP_XX","PTS_GRP_00",	"PTS_GRP_01",	"PTS_GRP_02",	"PTS_GRP_03",	
              "PTS_GRP_04",	"PTS_GRP_05",	"PTS_GRP_06",	"PTS_GRP_07",	"PTS_GRP_08",	
              "PTS_GRP_09",	"PTS_GRP_10",	"PTS_GRP_11")

for(col in col_list){
  dt[,(paste0(col,"_ecy")):= BIPD_ECY*get(col)]
}

summary <- sapply(dt,sum)
summary <- as.data.table(summary[grep("_ecy",names(summary))],keep.rownames = T)
summary

#########
dt[,PTS_GRP_ALL:= 0]
# for(i in 2:13){
#   dt[,PTS_GRP_ALL:= PTS_GRP_ALL+get(names(dt)[i])]
# }
for(col in col_list) dt[,PTS_GRP_ALL:= PTS_GRP_ALL+get(col)]

