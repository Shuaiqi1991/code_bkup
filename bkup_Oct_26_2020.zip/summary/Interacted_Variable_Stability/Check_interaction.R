# SET ENVIRONMENT
setwd("D:/Sean/Interacted_Variable_Stability")

library("data.table")
library("h2o")
library("here")
library("dplyr")

    # CHANGE HERE ROOT DIRECTORY
    change_here <- function(new_path){
      new_root <- here:::.root_env
      new_root$f <- function(...) {file.path(new_path, ...)}
      assignInNamespace(".root_env", new_root, ns = "here")
    }
    change_here("D:/Sean/Interacted_Variable_Stability")

# LOAD & COMBINING DATA
base_data <- fread(here("Data","Capp_2018_79b_sub_for_modeling.csv"))
    # this is old way of doing it, updated version already combine the data in SAS
    # lookup_data <- fread(here("Data", "Bipd_mdl_final_wpredpp_adjpp_sub.csv")) 
    # COMBINE LOOKUP VALUE
    # base_data <- lookup_data[base_data, on=.(ST_CD, PHYS_POL_KEY, PHYS_VEH_KEY)]

  # CHECK VARIABLE
  exld <- c("ST_CD", "POL_ID_NBR", "RENW_SFX_NBR", "PHYS_POL_KEY", "PHYS_VEH_KEY", "BIPD_ECY", "PP", 
            "SIC_CD", "BIPD_EP", "LOSS_CPD_DEV_TRND_INCR")
  exld <- c(exld,names(base_data)[25:length(names(base_data))])
  sapply(base_data[,setdiff(names(base_data), exld), with = F], 
         function(x){table(x)}
    )
  
  sapply(base_data[,setdiff(names(base_data), exld), with = F], 
         function(x){sum(is.na(x))}
  )  
  # CEHCK IF ANY NA OBS
  incld <- names(base_data)[grep("ADJ",names(base_data))]
  sapply(base_data[,incld, with = F],
         function(x){sum(is.na(x))})

# CREATE MKT
  # REPLACE NA IN CR_TIER_MTHD2_ModOne
  base_data[, CR_TIER_MTHD2_ModOne:= trimws(CR_TIER_MTHD2_ModOne)]
  base_data[is.na(CR_TIER_MTHD2_ModOne), CR_TIER_MTHD2_ModOne:="XX"]
  base_data[CR_TIER_MTHD2_ModOne=='', CR_TIER_MTHD2_ModOne:="XX"]
  base_data[CR_TIER_MTHD2_ModOne=='NC', CR_TIER_MTHD2_ModOne:="XX"]
  
  # REPLACE T WITH H IN PROD MAP
  base_data[, PROD_MAP_ADJ:=PROD_MAP]
  base_data[PROD_MAP=="T", PROD_MAP_ADJ:="H"] # ALIGN WITH MKT LKUP TABLE
  
  # IMPORT LKUP MKT TABLE
  mkt_data <- fread(here("Data","Presto Rated market table.csv"))

  #JOIN MKT
  base_data <- mkt_data[base_data, on=.(CR_TIER_MTHD2_ModOne, UW_ROW, PROD_MAP_ADJ)]
  
# CREATE INTERACTION
  # PLA * BMT
  base_data[,PLA_CNT_GRP:=trimws(PLA_CNT_GRP)]
  base_data[,BMT_NO_LIV:=trimws(BMT_NO_LIV)]
  base_data[,PLA_BMT:=paste0(as.character(PLA_CNT_GRP),"||",as.character(BMT_NO_LIV))]
  base_data[,PLA_BMT:=as.factor(PLA_BMT)]
  
  # PLA * BMT2
  base_data[,BMT2:=trimws(BMT2)]
  base_data[,PLA_BMT2:=paste0(as.character(PLA_CNT_GRP),"||",as.character(BMT2))]
  base_data[,PLA_BMT2:=as.factor(PLA_BMT2)]
  
# LUSDOT * MKT
  # CREATE LUSDOT_GRP
  base_data[LUSDOT==-1|LUSDOT==0, LUSDOT_GRP:="0"]
  base_data[LUSDOT>=1 & LUSDOT<=2, LUSDOT_GRP:="1-2"]
  base_data[LUSDOT>=3 & LUSDOT<=9, LUSDOT_GRP:="3-9"]
  base_data[LUSDOT>=10, LUSDOT_GRP:="10+"]
  base_data[is.na(LUSDOT_GRP), LUSDOT_GRP:="-998"]
  
base_data[,LUSDOT_GRP:=trimws(LUSDOT_GRP)]
base_data[,MKT:=trimws(MKT)]
base_data[LUSDOT_GRP != "-998", LUSDOT_GRP_MKT:=paste0(as.character(LUSDOT_GRP),"||", as.character(MKT))]
base_data[is.na(LUSDOT_GRP_MKT), LUSDOT_GRP_MKT:="-998"]
base_data[,LUSDOT_GRP_MKT:=as.factor(LUSDOT_GRP_MKT)]
    
# DOT * MKT
  # CREATE USDOT_V41_LEVEL
  base_data[USDOT_V41_GRPS %in% c("A01","A02","A03"), USDOT_V41_LVL:="low"]
  base_data[USDOT_V41_GRPS %in% c("A04","A05","A06"), USDOT_V41_LVL:="medium"]
  base_data[USDOT_V41_GRPS %in% c("A07","A08","A09","A10"), USDOT_V41_LVL:="high"]
  base_data[USDOT_V41_GRPS %in% c("Z92","Z95-Z96"), USDOT_V41_LVL:="new_vent"]
  base_data[USDOT_V41_GRPS %in% c("Z98"), USDOT_V41_LVL:="Z98"]
    
base_data[,USDOT_MKT:=paste0(as.character(USDOT_V41_LVL),"||",as.character(MKT))]
base_data[,USDOT_MKT:=as.factor(USDOT_MKT)]
    
# VEH_PERS_USE_IND * INSD_ORG_TYP
base_data[,VEH_PERS_USE_IND:=trimws(VEH_PERS_USE_IND)]
base_data[,INSD_ORG_TYP:=trimws(INSD_ORG_TYP)]
base_data[,VEH_PERS_INSD_ORG:=paste0(as.character(VEH_PERS_USE_IND),"||",as.character(INSD_ORG_TYP))]

# CREATE STEP 5 ADJ_PP ADJ_ECY
tweedie_power <- 1.653959 # acquire from KJ 2018 Q4 CAPP_2018 STP 4 OUTPUT
base_data[,ADJ_PP4:=ADJ_PP3/Pred_PP4_All]
base_data[,ADJ_ECY4:= ADJ_ECY3*Pred_PP4_All^(2-tweedie_power)]

# GENERATE TRAIN/TEST BASED ON POL_ID_NBR
seed_list <- c(543,888,266,200,458,132,87,968,343,904)
for(seed in seed_list){
  base_data[,(paste0("seed_",seed)):=runif(1,min=0,max=1), by=.(ST_CD, POL_ID_NBR)]
  base_data[,(paste0("seed_",seed,"_T")):=ifelse(get(paste0("seed_",seed))<0.7,"train","test")]
  base_data[,(paste0("seed_",seed)):=NULL]
}

# GENERATE META TABLE
meta <- cbind(
  as.data.table(names(base_data)),
  as.data.table(sapply(base_data,class))
)
names(meta) <- c("columns","types")

# EXPORT DATA
fwrite(base_data,here("Data","check_interaction_data.csv"))
fwrite(meta,here("Data","check_interaction_meta.csv"))

################
# PLA_BMT_DATA #
################
# SUBSET DATA
pla_bmt_data <- base_data[POL_RENW_IND=="Y",]

# GENERATE TRAIN/TEST BASED ON POL_ID_NBR
seed_list <- c(543,888,266,200,458,132,87,968,343,904)
for(seed in seed_list){
  pla_bmt_data[,(paste0("seed_",seed)):=runif(1,min=0,max=1), by=.(ST_CD, POL_ID_NBR)]
  pla_bmt_data[,(paste0("seed_",seed,"_T")):=ifelse(get(paste0("seed_",seed))<0.7,"train","test")]
  pla_bmt_data[,(paste0("seed_",seed)):=NULL]
}

# GENERATE META TABLE
meta <- cbind(
  as.data.table(names(pla_bmt_data)),
  as.data.table(sapply(pla_bmt_data,class))
  )
names(meta) <- c("columns","types")

# EXPORT DATA
fwrite(pla_bmt_data, here("Data","pla_bmt_check_interaction_data.csv"))
fwrite(meta, here("Data","pla_bmt_check_interaction_meta.csv"))

# MODEL
h2o.init()
  # LOAD DATA
  pla_bmt_data <- fread(here("Data","pla_bmt_check_interaction_data.csv"))

seed_list <- c(543,888,266,200,458,132,87,968,343,904)
var_list <- c("PLA_BMT", "PLA_BMT2")
tweedie_power <- 1.653959
rm(ase_summary)
rm(coef_summary)
ase_summary <- data.table()
coef_summary <- data.table()

meta <- fread(here("Data","pla_bmt_check_interaction_meta.csv"))
meta[, h2o_types:='unknown']
meta[types=='character', h2o_types:='string']
meta[types %in% c('integer','integer64','numeric'), h2o_types:='numeric']
meta[types=='Date', h2o_types:='time']
meta[types=='factor', h2o_types:='enum']

for(seed in seed_list){
  # PARTITION DATA
  train <- pla_bmt_data[get(paste0("seed_",seed,"_T"))=="train",]
  test <- pla_bmt_data[get(paste0("seed_",seed,"_T"))=="test",]
  fwrite(train,here("Data","train.csv"))
  fwrite(test,here("Data","test.csv"))
  train <- h2o.importFile(here("Data","train.csv"), destination_frame="train", col.types=meta$h2o_types)
  h2o_test <- h2o.importFile(here("Data","test.csv"), destination_frame="test", col.types=meta$h2o_types)
  print("partition complete")
  # GET RB_PP RB_STEP4 ASE_STP4
  mean_pp <- weighted.mean(test$PP, test$BIPD_ECY)
  if (mean_pp>0){test[,RB_PP:= 100*PP/mean_pp]} else {test[,RB_PP:=0]}
  test[,PRED_AT_STP4:= Pred_PP*Pred_PP2*Pred_PP3*Pred_PP4_All]
  mean_stp4 <- weighted.mean(test$PRED_AT_STP4, test$BIPD_ECY)
  if (mean_stp4>0){test[,RB_STP4:= 100*PRED_AT_STP4/mean_stp4]} else {test[,RB_STP4:=0]}
  test[,STP4_SE:= (RB_PP-RB_STP4)^2]
  ase_stp4 <- weighted.mean(test$STP4_SE, test$BIPD_ECY)
  print("basic SE complete")
  
  for(var in var_list){
    mdl_name <- paste0(var,"_",seed)
    print(mdl_name)
    mdl <- h2o.glm(x = var,
                   y = "ADJ_PP4",
                   # interaction_pairs = interaction_pairs,
                   training_frame = train,
                   model_id = mdl_name,
                   seed = 44124,
                   family = "tweedie",
                   weights_column = "ADJ_ECY4", 
                   tweedie_variance_power = tweedie_power,
                   tweedie_link_power = 0,
                   solver = 'IRLSM',
                   lambda = 0,
                   standardize = FALSE,
                   compute_p_values = TRUE,
                   beta_epsilon = 1e-9,
                   remove_collinear_columns = TRUE)
    # SAVE MODEL
    h2o.saveModel(mdl, path=here("Output","/h2o_model"), force=T)
    print("model saved")
    # GET PREDICTION ON TEST DATASET
    Pred_PP5_cal <- as.data.table(h2o.predict(mdl, h2o_test)[['predict']])[[1]]
    test[,Pred_PP5:= Pred_PP5_cal]
    print("prediction saved")
    # GET SE FOR STEP 5
    test[,PRED_AT_STP5:=Pred_PP5*PRED_AT_STP4]
    mean_stp5 <- weighted.mean(test$PRED_AT_STP5, test$BIPD_ECY)
    if (mean_stp5>0){test[,RB_STP5:= 100*PRED_AT_STP5/mean_stp5]} else {test[,RB_STP5:=0]}
    test[,STP5_SE:= (RB_PP-RB_STP5)^2]
    ase_stp5 <- weighted.mean(test$STP5_SE, test$BIPD_ECY)
    print("step 5 SE complete")
    
    # GET ASE
    ase <- list(mdl_name,
                ase_stp5,
                ase_stp4
                )
    ase <- as.data.table(ase)
    ase_summary <- rbind(ase_summary,ase)
    print("ase saved")
    # GET COEFFICIENTS
    coef <- as.data.table(mdl@model$coefficients_table)
    coef[,seed:= seed]
    coef_summary <- rbind(coef_summary, coef)
    print("coefficient saved")
    # EXPORT PREDICTION ON TEST DATASET
    fwrite(test,here("Output","Pred_record",paste0(mdl_name,".csv")))
    print("prediction saved")
  }
}

names(ase_summary) <- c("Model", "ASE_STP5", "ASE_STP4")
fwrite(ase_summary,here("Output","pla_bmt_pla_bmt2_ase.csv"))
fwrite(coef_summary,here("Output","pla_bmt_pla_bmt2_coef.csv"))

####################
# REST INTERACTION #
####################
# GENERATE TRAIN/TEST BASED ON POL_ID_NBR
seed_list <- c(543,888,266,200,458,132,87,968,343,904)
for(seed in seed_list){
  pla_bmt_data[,(paste0("seed_",seed)):=runif(1,min=0,max=1), by=.(ST_CD, POL_ID_NBR)]
  pla_bmt_data[,(paste0("seed_",seed,"_T")):=ifelse(get(paste0("seed_",seed))<0.7,"train","test")]
  pla_bmt_data[,(paste0("seed_",seed)):=NULL]
}

# GENERATE META TABLE
meta <- cbind(
  as.data.table(names(pla_bmt_data)),
  as.data.table(sapply(pla_bmt_data,class))
)
names(meta) <- c("columns","types")

# EXPORT DATA
fwrite(pla_bmt_data, here("Data","pla_bmt_check_interaction_data.csv"))
fwrite(meta, here("Data","pla_bmt_check_interaction_meta.csv"))

# MODEL
h2o.init()
# LOAD DATA
pla_bmt_data <- fread(here("Data","pla_bmt_check_interaction_data.csv"))

seed_list <- c(543,888,266,200,458,132,87,968,343,904)
var_list <- c("LUSDOT_GRP_MKT", "USDOT_MKT", "VEH_PERS_INSD_ORG")
tweedie_power <- 1.653959
rm(ase_summary)
rm(coef_summary)
ase_summary <- data.table()
coef_summary <- data.table()

meta <- fread(here("Data","pla_bmt_check_interaction_meta.csv"))
meta[, h2o_types:='unknown']
meta[types=='character', h2o_types:='string']
meta[types %in% c('integer','integer64','numeric'), h2o_types:='numeric']
meta[types=='Date', h2o_types:='time']
meta[types=='factor', h2o_types:='enum']

for(seed in seed_list){
  # PARTITION DATA
  train <- pla_bmt_data[get(paste0("seed_",seed,"_T"))=="train",]
  test <- pla_bmt_data[get(paste0("seed_",seed,"_T"))=="test",]
  fwrite(train,here("Data","train.csv"))
  fwrite(test,here("Data","test.csv"))
  train <- h2o.importFile(here("Data","train.csv"), destination_frame="train", col.types=meta$h2o_types)
  h2o_test <- h2o.importFile(here("Data","test.csv"), destination_frame="test", col.types=meta$h2o_types)
  print("partition complete")
  # GET RB_PP RB_STEP4 ASE_STP4
  mean_pp <- weighted.mean(test$PP, test$BIPD_ECY)
  if (mean_pp>0){test[,RB_PP:= 100*PP/mean_pp]} else {test[,RB_PP:=0]}
  test[,PRED_AT_STP4:= Pred_PP*Pred_PP2*Pred_PP3*Pred_PP4_All]
  mean_stp4 <- weighted.mean(test$PRED_AT_STP4, test$BIPD_ECY)
  if (mean_stp4>0){test[,RB_STP4:= 100*PRED_AT_STP4/mean_stp4]} else {test[,RB_STP4:=0]}
  test[,STP4_SE:= (RB_PP-RB_STP4)^2]
  ase_stp4 <- weighted.mean(test$STP4_SE, test$BIPD_ECY)
  print("basic SE complete")
  
  for(var in var_list){
    mdl_name <- paste0(var,"_",seed)
    print(mdl_name)
    mdl <- h2o.glm(x = var,
                   y = "ADJ_PP4",
                   # interaction_pairs = interaction_pairs,
                   training_frame = train,
                   model_id = mdl_name,
                   seed = 44124,
                   family = "tweedie",
                   weights_column = "ADJ_ECY4", 
                   tweedie_variance_power = tweedie_power,
                   tweedie_link_power = 0,
                   solver = 'IRLSM',
                   lambda = 0,
                   standardize = FALSE,
                   compute_p_values = TRUE,
                   beta_epsilon = 1e-9,
                   remove_collinear_columns = TRUE)
    # SAVE MODEL
    h2o.saveModel(mdl, path=here("Output","/h2o_model"), force=T)
    print("model saved")
    # GET PREDICTION ON TEST DATASET
    Pred_PP5_cal <- as.data.table(h2o.predict(mdl, h2o_test)[['predict']])[[1]]
    test[,Pred_PP5:= Pred_PP5_cal]
    print("prediction saved")
    # GET SE FOR STEP 5
    test[,PRED_AT_STP5:=Pred_PP5*PRED_AT_STP4]
    mean_stp5 <- weighted.mean(test$PRED_AT_STP5, test$BIPD_ECY)
    if (mean_stp5>0){test[,RB_STP5:= 100*PRED_AT_STP5/mean_stp5]} else {test[,RB_STP5:=0]}
    test[,STP5_SE:= (RB_PP-RB_STP5)^2]
    ase_stp5 <- weighted.mean(test$STP5_SE, test$BIPD_ECY)
    print("step 5 SE complete")
    
    # GET ASE
    ase <- list(mdl_name,
                ase_stp5,
                ase_stp4
    )
    ase <- as.data.table(ase)
    ase_summary <- rbind(ase_summary,ase)
    print("ase saved")
    # GET COEFFICIENTS
    coef <- as.data.table(mdl@model$coefficients_table)
    coef[,seed:= seed]
    coef_summary <- rbind(coef_summary, coef)
    print("coefficient saved")
    # EXPORT PREDICTION ON TEST DATASET
    fwrite(test,here("Output","Pred_record",paste0(mdl_name,".csv")))
    print("prediction saved")
  }
}

names(ase_summary) <- c("Model", "ASE_STP5", "ASE_STP4")
fwrite(ase_summary,here("Output","pla_bmt_pla_bmt2_ase.csv"))
fwrite(coef_summary,here("Output","pla_bmt_pla_bmt2_coef.csv"))

##################################################
# LUSDOT & USDOT INTERACTION FITTED SEQUENTIALLY #
##################################################

# MODEL
h2o.init()
# LOAD DATA
pla_bmt_data <- fread(here("Data","pla_bmt_check_interaction_data.csv"))

seed_list <- c(543,888,266,200,458,132,87,968,343,904)
var_list <- c("LUSDOT_GRP_MKT", "USDOT_MKT")
tweedie_power <- 1.653959
rm(ase_summary)
rm(coef_summary)
ase_summary <- data.table()
coef_summary <- data.table()

meta <- fread(here("Data","pla_bmt_check_interaction_meta.csv"))
meta[, h2o_types:='unknown']
meta[types=='character', h2o_types:='string']
meta[types %in% c('integer','integer64','numeric'), h2o_types:='numeric']
meta[types=='Date', h2o_types:='time']
meta[types=='factor', h2o_types:='enum']

for(seed in seed_list){
  # PARTITION DATA
  train <- pla_bmt_data[get(paste0("seed_",seed,"_T"))=="train",]
  test <- pla_bmt_data[get(paste0("seed_",seed,"_T"))=="test",]
  fwrite(train,here("Data","train.csv"))
  fwrite(test,here("Data","test.csv"))
  train <- h2o.importFile(here("Data","train.csv"), destination_frame="train", col.types=meta$h2o_types)
  h2o_test <- h2o.importFile(here("Data","test.csv"), destination_frame="test", col.types=meta$h2o_types)
  print("partition complete")
  # GET RB_PP RB_STEP4 ASE_STP4
  mean_pp <- weighted.mean(test$PP, test$BIPD_ECY)
  if (mean_pp>0){test[,RB_PP:= 100*PP/mean_pp]} else {test[,RB_PP:=0]}
  test[,PRED_AT_STP4:= Pred_PP*Pred_PP2*Pred_PP3*Pred_PP4_All]
  mean_stp4 <- weighted.mean(test$PRED_AT_STP4, test$BIPD_ECY)
  if (mean_stp4>0){test[,RB_STP4:= 100*PRED_AT_STP4/mean_stp4]} else {test[,RB_STP4:=0]}
  test[,STP4_SE:= (RB_PP-RB_STP4)^2]
  ase_stp4 <- weighted.mean(test$STP4_SE, test$BIPD_ECY)
  print("basic SE complete")
  
  for(i in 1:2){
    mdl_name <- paste0(var_list[i],"_",seed)
    print(mdl_name)
    # MODELING
    mdl <- h2o.glm(x = var_list[i],
                   y = paste0("ADJ_PP",i+3),
                   # interaction_pairs = interaction_pairs,
                   training_frame = train,
                   model_id = mdl_name,
                   seed = 44124,
                   family = "tweedie",
                   weights_column = paste0("ADJ_ECY",i+3), 
                   tweedie_variance_power = tweedie_power,
                   tweedie_link_power = 0,
                   solver = 'IRLSM',
                   lambda = 0,
                   standardize = FALSE,
                   compute_p_values = TRUE,
                   beta_epsilon = 1e-9,
                   remove_collinear_columns = TRUE)
    # SAVE MODEL
    h2o.saveModel(mdl, path=here("Output","/h2o_model"), force=TRUE)
    print("model saved")
    # UPDATE DEPENDENT VARIABLE & WEIGHT
    train[[paste0("Pred_PP",i+4)]] <- h2o.predict(mdl,train)[['predict']]
    print(1)
    train[[paste0("ADJ_PP",i+4)]] <- train[[paste0("ADJ_PP",i+3)]] / train[[paste0("Pred_PP",i+4)]]
    print(3)
    train[[paste0("ADJ_ECY",i+4)]] <- train[[paste0("ADJ_ECY",i+3)]]*train[[paste0("Pred_PP",i+4)]]^(2-tweedie_power)
    print(4)
    # GET PREDICTION ON TEST DATASET
    Pred_PP_cal <- as.data.table(h2o.predict(mdl, h2o_test)[['predict']])[[1]]
    test[[paste0("Pred_PP",i+4)]] <- Pred_PP_cal
    test[[paste0("PRED_AT_STP",i+4)]] <- test[[paste0("Pred_PP",i+4)]]*test[[paste0("PRED_AT_STP",i+3)]]
    print("prediction saved")
    # GET COEFFICIENTS
    coef <- as.data.table(mdl@model$coefficients_table)
    coef[,seed:= seed]
    coef_summary <- rbind(coef_summary, coef)
    print("coefficient saved")
    }
  # GET SE FOR FINAL STEP
  mean_stp6 <- weighted.mean(test$PRED_AT_STP6, test$BIPD_ECY)
  if (mean_stp6>0){test[,RB_STP6:= 100*PRED_AT_STP6/mean_stp6]} else {test[,RB_STP6:=0]}
  test[,STP6_SE:= (RB_PP-RB_STP6)^2]
  ase_stp6 <- weighted.mean(test$STP6_SE, test$BIPD_ECY)
  print("step 6 SE complete")
    
  # GET ASE
  ase <- list(mdl_name,
              ase_stp6,
              ase_stp4
  )
  ase <- as.data.table(ase)
  ase_summary <- rbind(ase_summary,ase)
  print("ase saved")
  # EXPORT PREDICTION ON TEST DATASET
  # fwrite(test,here("Output","Pred_record",paste0(mdl_name,".csv")))
  # print("prediction saved")
}

names(ase_summary) <- c("Model", "ASE_STP6", "ASE_STP4")
fwrite(ase_summary,here("Output","pla_bmt_pla_bmt2_ase.csv"))
fwrite(coef_summary,here("Output","pla_bmt_pla_bmt2_coef.csv"))
