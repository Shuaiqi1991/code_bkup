# SET ENVIRONMENT
library(data.table)
library(odbc)
library(stringr)
library(here)
library(ggplot2)
library(plotly)
library(tidyverse)
library(htmlwidgets)


change_here <- function(new_path){
  new_root <- here:::.root_env
  
  new_root$f <- function(...){file.path(new_path, ...)}
  
  assignInNamespace(".root_env", new_root, ns = "here")
}
change_here("D:/Sean/2020_Q1/Tier_Improvement")

# LOAD DATA
data <- fread("D:/Sean/2020_Q1/Tier_Improvement/Data/FILTER_TRIGGER_TEST.csv")

# CHECK TRIGGER FILER MIX;
data[,TRI_IND:='N']
data[TRIGGER > 1,TRI_IND:='Y']

# FORMAT
data[,TRI_IND:=as.factor(TRI_IND)]
data[,FILTER:=as.factor(FILTER)]

data[,test_ind:="FAIL"]
data[FILTER=="PASS", test_ind:="FILTER"]
data[TRI_IND=="Y", test_ind:="TRIGGER"]
data[,test_ind:=as.factor(test_ind)]

# check mix
multi.fun <- function(x) {cbind(freq = table(x), percentage = prop.table(table(x))*100)}
multi.fun(data$test_ind)

multi.fun <- function(data,vars) {
  #var <- deparse(substitute(var))
  output <<- data.table()
  for (var in vars){
    if (!(var %in% names(data))){
      cbind(freq = table(data$test_ind), percentage = prop.table(table(data$test_ind))*100)
    }
    
    else {
      pos <- grep(var,names(data))
      for (i in unique(data[[pos]])){
        sub_data <- data[get(var) == i]
        result <- as.data.table(cbind(freq = table(sub_data$test_ind), percentage = prop.table(table(sub_data$test_ind))*100), keep.rownames = TRUE)
        result[,model:=paste0(var,"_",i)]
        output <<- rbind(output,result)
      }   
    }
  }
}

multi.fun(data,
          c("UW_ROW","BCG_BMT", "BCG_ME","PKG_DISC_IND" , "ICC_FILE_IND","SUB_BMT","V41_USDOT_SCR_GRPS","CR_GRP_ME","POL_TENURE_AGE_GRP"))

multi.fun(data,
          c("ICC_FILE_IND","UW_ROW"))

# EXPORT RESULT
fwrite(output,"D:/Sean/2020_Q1/Tier_Improvement/Analysis/Output.csv")

# PLOT
stackplot <- ggplot(output, aes(fill=rn, y=percentage, x=model)) + 
              geom_bar(position="stack", stat="identity") +
              scale_fill_manual(values = c("Grey","Green","tomato")) +
              geom_abline(slope=0, intercept = 17.34, col = "blue", lty = 2) +
              geom_abline(slope=0, intercept = 62.68, col = "blue", lty = 2)
overall_plot <- ggplotly(stackplot)


htmlwidgets::saveWidget(as_widget(overall_plot), "D:/Sean/2020_Q1/Tier_Improvement/Analysis/trigger_filter_overview.html")

########################
# CHECK RBF VIOL COUNT #
########################

multi.fun.rbf <- function(data,vars) {
  #var <- deparse(substitute(var))
  output_rbf <<- data.table()
  check_list <- names(data)[grep("RBF",names(data))]
  for (var in vars){
    if (!(var %in% names(data))){
      print(paste0(var," not in dataset provided"))
    }
    
    else {
      pos <- grep(var,names(data))
      for (i in unique(data[[pos]])){
        sub_data <- data[get(var) == i]
        for (check in check_list){
          result <- as.data.table(cbind(freq = table(sub_data[,check, with=FALSE]), 
                                        percentage = prop.table(table(sub_data[,check, with=FALSE]))*100), 
                                  keep.rownames = TRUE)
          result[,model:=paste0(var,"_",i)]
          result[,check:=(check)]
          output_rbf <<- rbind(output_rbf,result)
        }
      }   
    }
  }
}

multi.fun.rbf(data,
              c("UW_ROW","BCG_BMT", "BCG_ME","PKG_DISC_IND" , "ICC_FILE_IND","SUB_BMT","V41_USDOT_SCR_GRPS","CR_GRP_ME","POL_TENURE_AGE_GRP"))

fwrite(output_rbf,"D:/Sean/2020_Q1/Tier_Improvement/Analysis/Output_rbf.csv")

ggplot(rbf_np_aaf, aes(x=rn,y=percentage))+
  geom_bar(stat="identity")

# CW
output_rbf_cw <- data.table()
check_list <- names(data)[grep("RBF",names(data))]
for (check in check_list){
  result <- as.data.table(cbind(freq = table(data[,check, with=FALSE]), 
                                percentage = prop.table(table(data[,check, with=FALSE]))*100), 
                          keep.rownames = TRUE)
  result[,check:=(check)]
  output_rbf_cw <<- rbind(output_rbf_cw,result)}

fwrite(output_rbf_cw,"D:/Sean/2020_Q1/Tier_Improvement/Analysis/Output_rbf_cw.csv")

########################
# CHECK RBT VIOL COUNT #
########################
multi.fun.rbt <- function(data,vars) {
  #var <- deparse(substitute(var))
  output_rbt <<- data.table()
  check_list <- names(data)[grep("RBT",names(data))]
  for (var in vars){
    if (!(var %in% names(data))){
      print(paste0(var," not in dataset provided"))
    }
    
    else {
      pos <- grep(var,names(data))
      for (i in unique(data[[pos]])){
        sub_data <- data[get(var) == i]
        for (check in check_list){
          result <- as.data.table(cbind(freq = table(sub_data[,check, with=FALSE]), 
                                        percentage = prop.table(table(sub_data[,check, with=FALSE]))*100), 
                                  keep.rownames = TRUE)
          result[,model:=paste0(var,"_",i)]
          result[,check:=(check)]
          output_rbt <<- rbind(output_rbt,result)
        }
      }   
    }
  }
}

multi.fun.rbt(data,
              c("xx","UW_ROW","BCG_BMT", "BCG_ME","PKG_DISC_IND" , "ICC_FILE_IND","SUB_BMT","V41_USDOT_SCR_GRPS","CR_GRP_ME","POL_TENURE_AGE_GRP"))

fwrite(output_rbt,"D:/Sean/2020_Q1/Tier_Improvement/Analysis/Output_rbt.csv")

# CW
output_rbt_cw <- data.table()
check_list <- names(data)[grep("RBT",names(data))]
for (check in check_list){
  result <- as.data.table(cbind(freq = table(data[,check, with=FALSE]), 
                                percentage = prop.table(table(data[,check, with=FALSE]))*100), 
                          keep.rownames = TRUE)
  result[,check:=(check)]
  output_rbt_cw <<- rbind(output_rbt_cw,result)}

fwrite(output_rbt_cw,"D:/Sean/2020_Q1/Tier_Improvement/Analysis/Output_rbt_cw.csv")


##########################
# Excluding RENW_CNT = 0 #
##########################
rb_data <- data[RENW_CNT!= 0]

multi.fun <- function(x) {cbind(freq = table(x), percentage = prop.table(table(x))*100)}
multi.fun(rb_data$test_ind)

multi.fun(rb_data,
          c("POL_TENURE_AGE_GRP"))


