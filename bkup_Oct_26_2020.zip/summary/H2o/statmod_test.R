#Set working environment
setwd('D:/Sean/H2O')

library("here")
library("data.table")
library("XLConnect")
library("dplyr")
library('ggplot2')
library('reshape2')
library('tweedie')

########
# BIPD #
########
data_path_bipd <<- 'Data/CAPP_BIPD_79C_LITE'
model_path_bipd <<- 'D:/Sean/H2O/Output/h2o_v235/BIPD'

meta_data_bipd <- fread(here(data_path_bipd,"meta.csv"))
dt <- fread("D:/Sean/H2O/Data/CAPP_BIPD_79C_LITE/data.csv", colClasses= meta_data_bipd$types)

# Tweedie Model

mdl <- glm(PP~ UNLD_PCT +
           AGE_GRP01+
           AGE_GRP02+
           AGE_GRP03+
           AGE_GRP04+
           AGE_GRP05+
           AGE_GRP06+
           AGE_GRP08+
           AGE_GRP09+
           AGE_GRP10+
           AGE_GRP11+
           AGE_GRP12+
           AGE_GRP13+
           AGE_GRP14+
           PTS_GRP01+
           PTS_GRP02+
           PTS_GRP03+
           PTS_GRP04+
           PTS_GRP05+
           PTS_GRP06+
           PTS_GRP07+
           PTS_GRP08+
           PTS_GRP09+
           PTS_GRP10+
           PTS_GRP11+
           BTG_ME+
           BCG_ME+
           USE_GRP+
           CR_GRP_ME+
           UW_ROW+
           BIPD_SYM_GRP+ 
           LIMIT_GRP+
           RADIUS_GRP+
           VAGE_RAW+
           VAGE_RAW2+
           VEH_PERS_USE_IND+
           PKG_DISC_NO_RT_NEW2+
           PIF_DISC+
           CDL_NORT_U_PCT_NEW+
           CDL_NORT_Y_PCT_NEW+
           USDOT_V41_GRPS+
           EFT_CURR_TERM+
           ST_GRP+
           TERR_MDL,
          data = dt, 
          weights = BIPD_ECY,
          family=tweedie(var.power=1.624799,link.power=0),na.action = na.omit)
summary(mdl)
