library(data.table)
library(openxlsx)
library(mefa)

# GENERATE COMBINATION FOR ALL LIST DRVR/FAULT AND DEL DRVR/FAULT
del_drvr_tbl <- as.data.table(expand.grid(0:10,0:10,0:10,0:10))
names(del_drvr_tbl) <- c("list_drvr_cnt","list_fault_cnt","del_drvr_cnt","del_fault_cnt") #when del_drvr_cnt =0, that means your are replacing drvrs

del_drvr_tbl[,pre_drvr_cnt:=list_drvr_cnt+del_drvr_cnt]
del_drvr_tbl[,pre_fault_cnt:=list_fault_cnt+del_fault_cnt]

# REMOVE list_drvr_cnt=0 but list_fault_cnt != 0 (illogical)
del_drvr_tbl <- del_drvr_tbl[!(list_drvr_cnt==0 & list_fault_cnt != 0)]

# REMOVE pre_drvr_cnt=0 but pre_fault_cnt != 0 (illogical)
del_drvr_tbl <- del_drvr_tbl[!(pre_drvr_cnt==0 & pre_fault_cnt != 0)]

# REMOVE del_fault_cnt = 0 (it won't trigger DEL DRVR mechanism)
# del_drvr_tbl <- del_drvr_tbl[!(del_fault_cnt==0)]

# REMOVE del_drvr_cnt = 0 but del_fault_Cnt != 0 (del drvr tbl won't cover replace drvr situation)
del_drvr_tbl <- del_drvr_tbl[!(del_drvr_cnt==0 & del_fault_cnt != 0)]

# CAP pre_drvr_cnt pre_fault_cnt at 10 for lkup purpose
del_drvr_tbl[pre_drvr_cnt>10, pre_drvr_cnt:=10]
del_drvr_tbl[pre_fault_cnt>10, pre_fault_cnt:=10]

## CREATE DEL DRVR TBL
# AAF
# READ AAF FCT TBL (I add one row drvr=0 vio = 0, coef = 1 to the original tbl)
AAF <- as.data.table(read.xlsx("D:/Sean/8.0_CAPP/Indicate_sheet/Block1/Atlas_DC_Tiering_Tables_post_MN_block1.xlsx", 
                               sheet="AAF-VIO-COEF-TBL",
                               startRow=2))
  # REMOVE DUPLICATE ROWS AND DROP COLUMN NOT USE
  # REPLACE HYPHEN
  names(AAF) <- gsub("-","_",names(AAF))
  AAF <- AAF[RISK_GROUP==1,]
  AAF <- AAF[,.(TIER_LISTED_DRVR_CNT, AAF_VIO_COUNT, AAF_VIO_COEF)]
  
# FORMAT del_drvr_tbl for left join
DEL_AAF <- data.table(del_drvr_tbl)
for (col in names(DEL_AAF)) {DEL_AAF[,c(col):=as.character(get(col))]}

# DEL_AAF[list_drvr_cnt=="0", list_drvr_cnt:= "0 ... 1"]
DEL_AAF[list_drvr_cnt=="1", list_drvr_cnt:= "0 ... 1"]
DEL_AAF[list_drvr_cnt=="10", list_drvr_cnt:= "10 ... 40"]
DEL_AAF[list_fault_cnt=="10", list_fault_cnt:= "10 ... 5000"]
# DEL_AAF[pre_drvr_cnt=="0", pre_drvr_cnt:= "0 ... 1"]
DEL_AAF[pre_drvr_cnt=="1", pre_drvr_cnt:= "0 ... 1"]
DEL_AAF[pre_drvr_cnt=="10", pre_drvr_cnt:= "10 ... 40"]
DEL_AAF[pre_fault_cnt=="10", pre_fault_cnt:= "10 ... 5000"]

DEL_AAF <- AAF[DEL_AAF, on=.(TIER_LISTED_DRVR_CNT=list_drvr_cnt, AAF_VIO_COUNT=list_fault_cnt)]
names(DEL_AAF)[1:3] <- c("list_drvr_cnt","list_fault_cnt", "post_fct")

DEL_AAF <- AAF[DEL_AAF, on=.(TIER_LISTED_DRVR_CNT=pre_drvr_cnt, AAF_VIO_COUNT=pre_fault_cnt)]
names(DEL_AAF)[1:3] <- c("pre_drvr_cnt","pre_fault_cnt", "pre_fct")

DEL_AAF[,post_fct:=as.numeric(post_fct)]
DEL_AAF[,pre_fct:=as.numeric(pre_fct)]
DEL_AAF[,DEL_DRV_AAF_COEF:= round(post_fct/pre_fct,2)]

# Export DEL_AAF_TBL
DEL_AAF_OUT <- DEL_AAF[,.(pre_drvr_cnt,pre_fault_cnt,list_drvr_cnt,list_fault_cnt,del_drvr_cnt,del_fault_cnt,DEL_DRV_AAF_COEF)]
# setnames(DEL_AAF_OUT,old = c("del_drvr_cnt" , "del_fault_cnt"), new = c("adj_drvr_cnt" , "adj_fault_cnt"))
# Reverse 0...1 format
DEL_AAF_OUT[list_drvr_cnt=="0 ... 1", list_drvr_cnt:= "1"]
DEL_AAF_OUT[pre_drvr_cnt=="0 ... 1", pre_drvr_cnt:= "1"]

# Format del varaible
DEL_AAF_OUT[del_drvr_cnt=="10", del_drvr_cnt:= "10 ... 40"]
DEL_AAF_OUT[del_fault_cnt=="10", del_fault_cnt:= "10 ... 5000"]

# Rep 6 times for 6 BMT (incld LIV)
i <- length(DEL_AAF_OUT$pre_drvr_cnt)
DEL_AAF_OUT <- DEL_AAF_OUT[rep(seq_len(nrow(DEL_AAF_OUT)), each = 6)]
DEL_AAF_OUT[,RISK_GROUP:= rep(1:6, times =i)]
DEL_AAF_OUT <- DEL_AAF_OUT[order(RISK_GROUP),]

fwrite(DEL_AAF_OUT,file="D:/Sean/8.0_CAPP/OUTPUT/TIER/Block1/DEL_DRVR_TBL_AAF.csv")

######################################################################################
## ALL TEST 
# 2 drvr
test <- DEL_AAF[list_drvr_cnt=="0 ... 1"]
test <- test[del_fault_cnt != 0]

# Check Duplicates
DUP_AAF <- DEL_AAF[duplicated(DEL_AAF, by=c("list_drvr_cnt","list_fault_cnt","del_drvr_cnt","del_fault_cnt")) |
                   duplicated(DEL_AAF, by=c("list_drvr_cnt","list_fault_cnt","del_drvr_cnt","del_fault_cnt"), fromLast=TRUE),]

CHK_DUP_AAF <- DEL_AAF[,.(DEL_MIN=min(DEL_DRV_AAF_COEF), DEL_MAX=max(DEL_DRV_AAF_COEF)), 
                       by=c("list_drvr_cnt","list_fault_cnt","del_drvr_cnt","del_fault_cnt")]

CHK_DUP_AAF[,CHK:=DEL_MAX-DEL_MIN]

CHK_DUP_AAF_2 <- DEL_AAF[,.(DEL_MIN=min(DEL_DRV_AAF_COEF), DEL_MAX=max(DEL_DRV_AAF_COEF)), 
                       by=c("pre_drvr_cnt","pre_fault_cnt","del_drvr_cnt","del_fault_cnt")]

CHK_DUP_AAF_2[,CHK:=DEL_MAX-DEL_MIN]

summary(CHK_DUP_AAF$CHK)
summary(CHK_DUP_AAF_2$CHK)

DUP_AAF_2 <- DEL_AAF[duplicated(DEL_AAF, by=c("pre_drvr_cnt","pre_fault_cnt","del_drvr_cnt","del_fault_cnt")) |
                     duplicated(DEL_AAF, by=c("pre_drvr_cnt","pre_fault_cnt","del_drvr_cnt","del_fault_cnt"), fromLast=TRUE),]

DUP_AAF_3 <- DEL_AAF[duplicated(DEL_AAF, by=c("pre_drvr_cnt","pre_fault_cnt","del_drvr_cnt","del_fault_cnt"))]

DUP_AAF_3 <- DEL_AAF[duplicated(DEL_AAF, by=c("list_drvr_cnt","list_fault_cnt","del_drvr_cnt","del_fault_cnt","pre_drvr_cnt")) |
                     duplicated(DEL_AAF, by=c("list_drvr_cnt","list_fault_cnt","del_drvr_cnt","del_fault_cnt","pre_drvr_cnt"), fromLast=TRUE),]

DUP_AAF_4 <- DEL_AAF[duplicated(DEL_AAF, by=c("list_drvr_cnt","list_fault_cnt","del_drvr_cnt","del_fault_cnt","pre_drvr_cnt","pre_drvr_cnt")) |
                       duplicated(DEL_AAF, by=c("list_drvr_cnt","list_fault_cnt","del_drvr_cnt","del_fault_cnt","pre_drvr_cnt","pre_drvr_cnt"), fromLast=TRUE),]

#######################################################################################

# NAF
# READ NAF FCT TBL (I add one row drvr=0 vio = 0, coef = 1 to the original tbl)
NAF <- as.data.table(read.xlsx("D:/Sean/8.0_CAPP/Indicate_sheet/Block1/Atlas_DC_Tiering_Tables_post_MN_block1.xlsx", 
                               sheet="NAF-VIO-COEF-TBL",
                               startRow=2))
# REMOVE DUPLICATE ROWS AND DROP COLUMN NOT USE
# REPLACE HYPHEN
names(NAF) <- gsub("-","_",names(NAF))
NAF <- NAF[RISK_GROUP==1,]
NAF <- NAF[,.(TIER_LISTED_DRVR_CNT, NAF_VIO_COUNT, NAF_VIO_COEF)]

# FORMAT del_drvr_tbl for left join
DEL_NAF <- data.table(del_drvr_tbl)
for (col in names(DEL_NAF)) {DEL_NAF[,c(col):=as.character(get(col))]}

# DEL_NAF[list_drvr_cnt=="0", list_drvr_cnt:= "0 ... 1"]
DEL_NAF[list_drvr_cnt=="1", list_drvr_cnt:= "0 ... 1"]
DEL_NAF[list_drvr_cnt=="10", list_drvr_cnt:= "10 ... 40"]
DEL_NAF[list_fault_cnt=="10", list_fault_cnt:= "10 ... 5000"]
# DEL_NAF[pre_drvr_cnt=="0", pre_drvr_cnt:= "0 ... 1"]
DEL_NAF[pre_drvr_cnt=="1", pre_drvr_cnt:= "0 ... 1"]
DEL_NAF[pre_drvr_cnt=="10", pre_drvr_cnt:= "10 ... 40"]
DEL_NAF[pre_fault_cnt=="10", pre_fault_cnt:= "10 ... 5000"]

DEL_NAF <- NAF[DEL_NAF, on=.(TIER_LISTED_DRVR_CNT=list_drvr_cnt, NAF_VIO_COUNT=list_fault_cnt)]
names(DEL_NAF)[1:3] <- c("list_drvr_cnt","list_fault_cnt", "post_fct")

DEL_NAF <- NAF[DEL_NAF, on=.(TIER_LISTED_DRVR_CNT=pre_drvr_cnt, NAF_VIO_COUNT=pre_fault_cnt)]
names(DEL_NAF)[1:3] <- c("pre_drvr_cnt","pre_fault_cnt", "pre_fct")

DEL_NAF[,post_fct:=as.numeric(post_fct)]
DEL_NAF[,pre_fct:=as.numeric(pre_fct)]
DEL_NAF[,DEL_DRV_NAF_COEF:= round(post_fct/pre_fct,2)]

# Export DEL_NAF_TBL
DEL_NAF_OUT <- DEL_NAF[,.(pre_drvr_cnt,pre_fault_cnt,list_drvr_cnt,list_fault_cnt,del_drvr_cnt,del_fault_cnt,DEL_DRV_NAF_COEF)]
# setnames(DEL_NAF_OUT,old = c("del_drvr_cnt" , "del_fault_cnt"), new = c("adj_drvr_cnt" , "adj_fault_cnt"))
# Reverse 0...1 format
DEL_NAF_OUT[list_drvr_cnt=="0 ... 1", list_drvr_cnt:= "1"]
DEL_NAF_OUT[pre_drvr_cnt=="0 ... 1", pre_drvr_cnt:= "1"]

# Format del varaible
DEL_NAF_OUT[del_drvr_cnt=="10", del_drvr_cnt:= "10 ... 40"]
DEL_NAF_OUT[del_fault_cnt=="10", del_fault_cnt:= "10 ... 5000"]

# Rep 6 times for 6 BMT (incld LIV)
i <- length(DEL_NAF_OUT$pre_drvr_cnt)
DEL_NAF_OUT <- DEL_NAF_OUT[rep(seq_len(nrow(DEL_NAF_OUT)), each = 6)]
DEL_NAF_OUT[,RISK_GROUP:= rep(1:6, times =i)]
DEL_NAF_OUT <- DEL_NAF_OUT[order(RISK_GROUP),]

fwrite(DEL_NAF_OUT,file="D:/Sean/8.0_CAPP/OUTPUT/TIER/Block1/DEL_DRVR_TBL_NAF.csv")

#######################################################################################

# MAJOR
# READ MAJOR FCT TBL (I add one row drvr=0 vio = 0, coef = 1 to the original tbl)
MAJOR <- as.data.table(read.xlsx("D:/Sean/8.0_CAPP/Indicate_sheet/Block1/Atlas_DC_Tiering_Tables_post_MN_block1.xlsx", 
                               sheet="MAJOR-VIO-COEF-TBL",
                               startRow=2))
# REMOVE DUPLICATE ROWS AND DROP COLUMN NOT USE
# REPLACE HYPHEN
names(MAJOR) <- gsub("-","_",names(MAJOR))
MAJOR <- MAJOR[RISK_GROUP==1,]
MAJOR <- MAJOR[,.(TIER_LISTED_DRVR_CNT, MAJOR_VIO_COUNT, MAJOR_VIO_COEF)]

# FORMAT del_drvr_tbl for left join
DEL_MAJOR <- data.table(del_drvr_tbl)
for (col in names(DEL_MAJOR)) {DEL_MAJOR[,c(col):=as.character(get(col))]}

# DEL_MAJOR[list_drvr_cnt=="0", list_drvr_cnt:= "0 ... 1"]
DEL_MAJOR[list_drvr_cnt=="1", list_drvr_cnt:= "0 ... 1"]
DEL_MAJOR[list_drvr_cnt=="10", list_drvr_cnt:= "10 ... 40"]
DEL_MAJOR[list_fault_cnt=="10", list_fault_cnt:= "10 ... 5000"]
# DEL_MAJOR[pre_drvr_cnt=="0", pre_drvr_cnt:= "0 ... 1"]
DEL_MAJOR[pre_drvr_cnt=="1", pre_drvr_cnt:= "0 ... 1"]
DEL_MAJOR[pre_drvr_cnt=="10", pre_drvr_cnt:= "10 ... 40"]
DEL_MAJOR[pre_fault_cnt=="10", pre_fault_cnt:= "10 ... 5000"]

DEL_MAJOR <- MAJOR[DEL_MAJOR, on=.(TIER_LISTED_DRVR_CNT=list_drvr_cnt, MAJOR_VIO_COUNT=list_fault_cnt)]
names(DEL_MAJOR)[1:3] <- c("list_drvr_cnt","list_fault_cnt", "post_fct")

DEL_MAJOR <- MAJOR[DEL_MAJOR, on=.(TIER_LISTED_DRVR_CNT=pre_drvr_cnt, MAJOR_VIO_COUNT=pre_fault_cnt)]
names(DEL_MAJOR)[1:3] <- c("pre_drvr_cnt","pre_fault_cnt", "pre_fct")

DEL_MAJOR[,post_fct:=as.numeric(post_fct)]
DEL_MAJOR[,pre_fct:=as.numeric(pre_fct)]
DEL_MAJOR[,DEL_DRV_MAJOR_COEF:= round(post_fct/pre_fct,2)]

# Export DEL_MAJOR_TBL
DEL_MAJOR_OUT <- DEL_MAJOR[,.(pre_drvr_cnt,pre_fault_cnt,list_drvr_cnt,list_fault_cnt,del_drvr_cnt,del_fault_cnt,DEL_DRV_MAJOR_COEF)]
# setnames(DEL_MAJOR_OUT,old = c("del_drvr_cnt" , "del_fault_cnt"), new = c("adj_drvr_cnt" , "adj_fault_cnt"))
# Reverse 0...1 format
DEL_MAJOR_OUT[list_drvr_cnt=="0 ... 1", list_drvr_cnt:= "1"]
DEL_MAJOR_OUT[pre_drvr_cnt=="0 ... 1", pre_drvr_cnt:= "1"]

# Format del varaible
DEL_MAJOR_OUT[del_drvr_cnt=="10", del_drvr_cnt:= "10 ... 40"]
DEL_MAJOR_OUT[del_fault_cnt=="10", del_fault_cnt:= "10 ... 5000"]

# Rep 6 times for 6 BMT (incld LIV)
i <- length(DEL_MAJOR_OUT$pre_drvr_cnt)
DEL_MAJOR_OUT <- DEL_MAJOR_OUT[rep(seq_len(nrow(DEL_MAJOR_OUT)), each = 6)]
DEL_MAJOR_OUT[,RISK_GROUP:= rep(1:6, times =i)]
DEL_MAJOR_OUT <- DEL_MAJOR_OUT[order(RISK_GROUP),]

fwrite(DEL_MAJOR_OUT,file="D:/Sean/8.0_CAPP/OUTPUT/TIER/Block1/DEL_DRVR_TBL_MAJOR.csv")

#######################################################################################

# MINOR
# READ MINOR FCT TBL (I add one row drvr=0 vio = 0, coef = 1 to the original tbl)
MINOR <- as.data.table(read.xlsx("D:/Sean/8.0_CAPP/Indicate_sheet/Block1/Atlas_DC_Tiering_Tables_post_MN_block1.xlsx", 
                                 sheet="MINOR-VIO-COEF-TBL",
                                 startRow=2))
# REMOVE DUPLICATE ROWS AND DROP COLUMN NOT USE
# REPLACE HYPHEN
names(MINOR) <- gsub("-","_",names(MINOR))
MINOR <- MINOR[RISK_GROUP==1,]
MINOR <- MINOR[,.(TIER_LISTED_DRVR_CNT, MINOR_VIO_COUNT, MINOR_VIO_COEF)]

# FORMAT del_drvr_tbl for left join
DEL_MINOR <- data.table(del_drvr_tbl)
for (col in names(DEL_MINOR)) {DEL_MINOR[,c(col):=as.character(get(col))]}

# DEL_MINOR[list_drvr_cnt=="0", list_drvr_cnt:= "0 ... 1"]
DEL_MINOR[list_drvr_cnt=="1", list_drvr_cnt:= "0 ... 1"]
DEL_MINOR[list_drvr_cnt=="10", list_drvr_cnt:= "10 ... 40"]
DEL_MINOR[list_fault_cnt=="10", list_fault_cnt:= "10 ... 5000"]
# DEL_MINOR[pre_drvr_cnt=="0", pre_drvr_cnt:= "0 ... 1"]
DEL_MINOR[pre_drvr_cnt=="1", pre_drvr_cnt:= "0 ... 1"]
DEL_MINOR[pre_drvr_cnt=="10", pre_drvr_cnt:= "10 ... 40"]
DEL_MINOR[pre_fault_cnt=="10", pre_fault_cnt:= "10 ... 5000"]

DEL_MINOR <- MINOR[DEL_MINOR, on=.(TIER_LISTED_DRVR_CNT=list_drvr_cnt, MINOR_VIO_COUNT=list_fault_cnt)]
names(DEL_MINOR)[1:3] <- c("list_drvr_cnt","list_fault_cnt", "post_fct")

DEL_MINOR <- MINOR[DEL_MINOR, on=.(TIER_LISTED_DRVR_CNT=pre_drvr_cnt, MINOR_VIO_COUNT=pre_fault_cnt)]
names(DEL_MINOR)[1:3] <- c("pre_drvr_cnt","pre_fault_cnt", "pre_fct")

DEL_MINOR[,post_fct:=as.numeric(post_fct)]
DEL_MINOR[,pre_fct:=as.numeric(pre_fct)]
DEL_MINOR[,DEL_DRV_MINOR_COEF:= round(post_fct/pre_fct,2)]

# Export DEL_MINOR_TBL
DEL_MINOR_OUT <- DEL_MINOR[,.(pre_drvr_cnt,pre_fault_cnt,list_drvr_cnt,list_fault_cnt,del_drvr_cnt,del_fault_cnt,DEL_DRV_MINOR_COEF)]
# setnames(DEL_MINOR_OUT,old = c("del_drvr_cnt" , "del_fault_cnt"), new = c("adj_drvr_cnt" , "adj_fault_cnt"))
# Reverse 0...1 format
DEL_MINOR_OUT[list_drvr_cnt=="0 ... 1", list_drvr_cnt:= "1"]
DEL_MINOR_OUT[pre_drvr_cnt=="0 ... 1", pre_drvr_cnt:= "1"]

# Format del varaible
DEL_MINOR_OUT[del_drvr_cnt=="10", del_drvr_cnt:= "10 ... 40"]
DEL_MINOR_OUT[del_fault_cnt=="10", del_fault_cnt:= "10 ... 5000"]

# Rep 6 times for 6 BMT (incld LIV)
i <- length(DEL_MINOR_OUT$pre_drvr_cnt)
DEL_MINOR_OUT <- DEL_MINOR_OUT[rep(seq_len(nrow(DEL_MINOR_OUT)), each = 6)]
DEL_MINOR_OUT[,RISK_GROUP:= rep(1:6, times =i)]
DEL_MINOR_OUT <- DEL_MINOR_OUT[order(RISK_GROUP),]

fwrite(DEL_MINOR_OUT,file="D:/Sean/8.0_CAPP/OUTPUT/TIER/Block1/DEL_DRVR_TBL_MINOR.csv")

#######################################################################################

# DUI
# READ DUI FCT TBL (I add one row drvr=0 vio = 0, coef = 1 to the original tbl)
DUI <- as.data.table(read.xlsx("D:/Sean/8.0_CAPP/Indicate_sheet/Block1/Atlas_DC_Tiering_Tables_post_MN_block1.xlsx", 
                                 sheet="DUI-VIO-COEF-TBL",
                                 startRow=2))
# REMOVE DUPLICATE ROWS AND DROP COLUMN NOT USE
# REPLACE HYPHEN
names(DUI) <- gsub("-","_",names(DUI))
DUI <- DUI[RISK_GROUP==1,]
DUI <- DUI[,.(TIER_LISTED_DRVR_CNT, DUI_VIO_COUNT, DUI_VIO_COEF)]

# FORMAT del_drvr_tbl for left join
DEL_DUI <- data.table(del_drvr_tbl)
for (col in names(DEL_DUI)) {DEL_DUI[,c(col):=as.character(get(col))]}

# DEL_DUI[list_drvr_cnt=="0", list_drvr_cnt:= "0 ... 1"]
DEL_DUI[list_drvr_cnt=="1", list_drvr_cnt:= "0 ... 1"]
DEL_DUI[list_drvr_cnt=="10", list_drvr_cnt:= "10 ... 40"]
DEL_DUI[list_fault_cnt=="10", list_fault_cnt:= "10 ... 5000"]
# DEL_DUI[pre_drvr_cnt=="0", pre_drvr_cnt:= "0 ... 1"]
DEL_DUI[pre_drvr_cnt=="1", pre_drvr_cnt:= "0 ... 1"]
DEL_DUI[pre_drvr_cnt=="10", pre_drvr_cnt:= "10 ... 40"]
DEL_DUI[pre_fault_cnt=="10", pre_fault_cnt:= "10 ... 5000"]

DEL_DUI <- DUI[DEL_DUI, on=.(TIER_LISTED_DRVR_CNT=list_drvr_cnt, DUI_VIO_COUNT=list_fault_cnt)]
names(DEL_DUI)[1:3] <- c("list_drvr_cnt","list_fault_cnt", "post_fct")

DEL_DUI <- DUI[DEL_DUI, on=.(TIER_LISTED_DRVR_CNT=pre_drvr_cnt, DUI_VIO_COUNT=pre_fault_cnt)]
names(DEL_DUI)[1:3] <- c("pre_drvr_cnt","pre_fault_cnt", "pre_fct")

DEL_DUI[,post_fct:=as.numeric(post_fct)]
DEL_DUI[,pre_fct:=as.numeric(pre_fct)]
DEL_DUI[,DEL_DRV_DUI_COEF:= round(post_fct/pre_fct,2)]

# Export DEL_DUI_TBL
DEL_DUI_OUT <- DEL_DUI[,.(pre_drvr_cnt,pre_fault_cnt,list_drvr_cnt,list_fault_cnt,del_drvr_cnt,del_fault_cnt,DEL_DRV_DUI_COEF)]
# setnames(DEL_DUI_OUT,old = c("del_drvr_cnt" , "del_fault_cnt"), new = c("adj_drvr_cnt" , "adj_fault_cnt"))
# Reverse 0...1 format
DEL_DUI_OUT[list_drvr_cnt=="0 ... 1", list_drvr_cnt:= "1"]
DEL_DUI_OUT[pre_drvr_cnt=="0 ... 1", pre_drvr_cnt:= "1"]

# Format del varaible
DEL_DUI_OUT[del_drvr_cnt=="10", del_drvr_cnt:= "10 ... 40"]
DEL_DUI_OUT[del_fault_cnt=="10", del_fault_cnt:= "10 ... 5000"]

# Rep 6 times for 6 BMT (incld LIV)
i <- length(DEL_DUI_OUT$pre_drvr_cnt)
DEL_DUI_OUT <- DEL_DUI_OUT[rep(seq_len(nrow(DEL_DUI_OUT)), each = 6)]
DEL_DUI_OUT[,RISK_GROUP:= rep(1:6, times =i)]
DEL_DUI_OUT <- DEL_DUI_OUT[order(RISK_GROUP),]

fwrite(DEL_DUI_OUT,file="D:/Sean/8.0_CAPP/OUTPUT/TIER/Block1/DEL_DRVR_TBL_DUI.csv")

######################

