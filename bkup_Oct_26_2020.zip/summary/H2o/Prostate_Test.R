#Set working environment
setwd('D:/Sean/H2O')

library("here")
library("data.table")
library("XLConnect")
library("dplyr")
library('ggplot2')
library('reshape2')
library('h2o')
library('statmod')

h2o.init()
 
# Import Data
data_path <<- 'Data/TEST_DATA'

meta_data <- fread(here(data_path,"meta_prostate.csv"))
meta_data[, h2o_types:='unknown']
meta_data[types=='character', h2o_types:='string']
meta_data[types=='integer', h2o_types:='numeric']
meta_data[types=='numeric', h2o_types:='numeric']
meta_data[types=='Date', h2o_types:='time']
meta_data[types=='factor', h2o_types:='enum']

dt_test <- h2o.importFile('D:/Sean/H2O/Data/TEST_DATA/prostate.csv',
                          destination_frame="", col.types=meta_data$h2o_types)
dt <- fread("D:/Sean/H2O/Data/TEST_DATA/prostate.csv", colClasses= meta_data$types)


# Define variables

independent <- c("AGE",
                 "RACE",
                 "DPROS",
                 "DCAPS",
                 "PSA",
                 "VOL",
                 "GLEASON"
                 )
dependent <- "CAPSULE"
power <- 1.1

# Setup reference

dt_test["RACE"] <- h2o.relevel(dt_test["RACE"], "0")
dt_test["DPROS"] <- h2o.relevel(dt_test["DPROS"], "1")
dt_test["DCAPS"] <- h2o.relevel(dt_test["DCAPS"], "1")

# Tweedie model

mdl <- h2o.glm(x = independent,
               y = dependent,
               #interaction_pairs = interaction_pairs,
               training_frame = dt_test,
               model_id = "prostate_V325",
               seed = 44124,
               family = "tweedie",
               #weights_column = weight_var, 
               tweedie_variance_power = power,
               tweedie_link_power = 0,
               solver = 'IRLSM',
               lambda = 0,
               standardize = FALSE,
               compute_p_values = TRUE,
               beta_epsilon = 1e-9,
               remove_collinear_columns = TRUE)

# Post analysis

coef <- mdl@model$coefficients_table
phi <- mdl@model$dispersion
pred <- as.data.table(h2o.predict(mdl,dt_test))

# TEST WITH TEEEDIE PACKAGE WRITTEN BY PETER DUNN

tt <- glm(CAPSULE~ AGE + RACE + DPROS + DCAPS + PSA + VOL + GLEASON,data = dt, 
          family=tweedie(var.power=1.1,link.power=0),na.action = na.omit)
summary(tt)

tt1 <- glm(CAPSULE~ 1,data = dt, 
                 family=tweedie(var.power=1.1,link.power=0),na.action = na.omit)
summary(tt1)