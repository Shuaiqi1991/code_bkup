# Set environment
setwd("D:/Sean/2020_Q1/Tier_Improvement")

library(data.table)
library(odbc)
library(stringr)
library(here)

change_here <- function(new_path){
  new_root <- here:::.root_env
  
  new_root$f <- function(...){file.path(new_path, ...)}
  
  assignInNamespace(".root_env", new_root, ns = "here")
}
change_here("D:/Sean/2020_Q1/Tier_Improvement")

# SET SQL QUERY 
uid <- "x011870"
pwd <- readLines('U:/x011870/pswd.txt', warn = FALSE)
#var_lib_path <- "D:/Sean/8.0_CAPP/Off_Balance/BLOCK_1_2_on_2019/Data/XLS_FILE"

pol_exp_start_date <- "2014-01-01"
pol_exp_end_date <- "2021-01-31"

# CONNECT TO DATA WAREHOUSE
data_con <- dbConnect(odbc(), 'DB2P', uid=uid, pwd=pwd)

# VIOLATIONS QUERY
clue_viol_qry <- 
  "
  SELECT 
  CLU.CL_RPT_CLUE_REPORT.APP_ST_CD,
  CLU.CL_RPT_CLUE_REPORT.POL_ID_CHAR, 
  CLU.CL_RPT_CLUE_REPORT.POL_RENW_CTR, 
  CLU.CL_RPT_CLUE_REPORT.POL_EXP_DT, 
  CLU.CL_RPT_SUBJECT_REPLY.DRVR_LIC_NBR, 
  CLU.CL_RPT_SUBJECT_REPLY.DRVR_BRTH_DT,
  CLU.CL_RPT_SUBJECT_REPLY.DRVR_LIC_ST_CD,
  CLU.CL_RPT_CLAIM.POL_TYPE_CD,
  CLU.CL_RPT_VIOLATION.VIOL_CD,
  CLU.CL_RPT_VIOLATION.VIOL_DT 
  FROM 
  CLU.CL_RPT_CLUE_REPORT,
  CLU.CL_RPT_SUBJECT_REPLY,
  CLU.CL_RPT_CLAIM,
  CLU.CL_RPT_VIOLATION 
  WHERE 
  CLU.CL_RPT_CLUE_REPORT.POL_EXP_DT BETWEEN {d 'startdate'} and {d 'enddate'} 
  AND CLU.CL_RPT_CLUE_REPORT.RPT_ID = CLU.CL_RPT_SUBJECT_REPLY.RPT_ID 
  AND CLU.CL_RPT_SUBJECT_REPLY.SBJCT_ID = CLU.CL_RPT_CLAIM.SBJCT_ID 
  AND CLU.CL_RPT_CLAIM.CLAIM_ID = CLU.CL_RPT_VIOLATION.CLAIM_ID 
  GROUP BY
  CLU.CL_RPT_CLUE_REPORT.APP_ST_CD,
  CLU.CL_RPT_CLUE_REPORT.POL_ID_CHAR, 
  CLU.CL_RPT_CLUE_REPORT.POL_RENW_CTR, 
  CLU.CL_RPT_CLUE_REPORT.POL_EXP_DT, 
  CLU.CL_RPT_SUBJECT_REPLY.DRVR_LIC_NBR, 
  CLU.CL_RPT_SUBJECT_REPLY.DRVR_BRTH_DT,
  CLU.CL_RPT_SUBJECT_REPLY.DRVR_LIC_ST_CD,
  CLU.CL_RPT_CLAIM.POL_TYPE_CD,
  CLU.CL_RPT_VIOLATION.VIOL_CD,
  CLU.CL_RPT_VIOLATION.VIOL_DT 
  ;
"

# INSERT START AND END DATE INTO QUERY
clue_viol_qry <- str_replace_all(clue_viol_qry, 'startdate', pol_exp_start_date)
clue_viol_qry <- str_replace_all(clue_viol_qry, 'enddate', pol_exp_end_date)

# GET VIOLATION DATA
clue_viol_data <- as.data.table(dbGetQuery(data_con, clue_viol_qry))

clue_viol_data[,DRVR_LIC_NBR:=trimws(DRVR_LIC_NBR)]


dup_test <- viol_data [duplicated(viol_data, by=c("APP_ST_CD","POL_ID_CHAR","POL_RENW_CTR","POL_EXP_DT","DRVR_LIC_NBR","DRVR_BRTH_DT","DRVR_LIC_ST_CD",
                                                                             "POL_TYPE_CD","VIOL_CD","VIOL_DT"))|
                       duplicated(viol_data, by=c("APP_ST_CD","POL_ID_CHAR","POL_RENW_CTR","POL_EXP_DT","DRVR_LIC_NBR","DRVR_BRTH_DT","DRVR_LIC_ST_CD",
                                                                              "POL_TYPE_CD","VIOL_CD","VIOL_DT"), fromLast=TRUE)]

dup_test <- dup_test[order(APP_ST_CD,POL_ID_CHAR,POL_RENW_CTR,POL_EXP_DT,DRVR_LIC_NBR,DRVR_BRTH_DT,DRVR_LIC_ST_CD,
                           POL_TYPE_CD,VIOL_CD,VIOL_DT)]
