#Set working environment
setwd('D:/Sean/H2O')

library("here")
library("data.table")
library("XLConnect")
library("dplyr")
library('ggplot2')
library('reshape2')
library('tweedie')
library('statmod')

################
# IMPORT DATA  #
################
# dt1 <- bipd_79b_CA_18
# dt2 <- bipd_79b_FL_18
# dt3 <- bipd_79b_TX_18
# dt4 <- bipd_79b_CWx_18

meta_1 <- fread(here("Data","bipd_79b_ca_18","meta.csv"))
  col_types <- lapply(unique(meta_1$types), function(x){
    meta_1[types==x, columns]
  })
  names(col_types) <- unique(meta_1$types)
  
dt_1 <- fread(here("Data","bipd_79b_ca_18","data.csv"), colClasses= col_types)
dt_2 <- fread(here("Data","bipd_79b_fl_18","data.csv"), colClasses= col_types)
dt_3 <- fread(here("Data","bipd_79b_tx_18","data.csv"), colClasses= col_types)
dt_4 <- fread(here("Data","bipd_79b_cwx_18","data.csv"), colClasses= col_types)

################
# RLEVEL       #
################

dt_4[["ST_GRP"]] <- relevel(factor(dt_4[["ST_GRP"]]),"9")
  
################
# SETUP POWER  #
################

p_1 <- 1.653
p_2 <- 1.655
p_3 <- 1.658
p_4 <- 1.655

##################
# CA DATA MODEL #
##################

dt <- get("dt_1")
p <- get("p_1")
dt_name <- "dt_1"

dt[["BTG_ME"]] <- relevel(factor(dt[["BTG_ME"]]), "999")
dt[["BCG_ME"]] <- relevel(factor(dt[["BCG_ME"]]), "999")
dt[["USE_GRP"]] <- relevel(factor(dt[["USE_GRP"]]), "999") 
dt[["CR_GRP_ME"]] <- relevel(factor(dt[["CR_GRP_ME"]]), "C0")
dt[["UW_ROW"]] <- relevel(factor(dt[["UW_ROW"]]), "1")
dt[["BIPD_SYM_GRP"]] <- relevel(factor(dt[["BIPD_SYM_GRP"]]), "16")
dt[["LIMIT_GRP"]] <- relevel(factor(dt[["LIMIT_GRP"]]), "999")
dt[["RADIUS_GRP"]] <- relevel(factor(dt[["RADIUS_GRP"]]), "050")
dt[["VEH_PERS_USE_IND"]] <- relevel(factor(dt[["VEH_PERS_USE_IND"]]), "N")
dt[["PKG_DISC_NO_RT_NEW2"]] <- relevel(factor(dt[["PKG_DISC_NO_RT_NEW2"]]), "N")
dt[["PIF_DISC"]] <- relevel(factor(dt[["PIF_DISC"]]), "N")
dt[["USDOT_V41_GRPS"]] <- relevel(factor(dt[["USDOT_V41_GRPS"]]), "Z98")

# MODEL
mdl <- glm(PP~ UNLD_PCT +
             AGE_GRP01+
             AGE_GRP02+
             AGE_GRP03+
             AGE_GRP04+
             AGE_GRP05+
             AGE_GRP06+
             AGE_GRP08+
             AGE_GRP09+
             AGE_GRP10+
             AGE_GRP11+
             AGE_GRP12+
             AGE_GRP13+
             AGE_GRP14+
             PTS_GRP01+
             PTS_GRP02+
             PTS_GRP03+
             PTS_GRP04+
             PTS_GRP05+
             PTS_GRP06+
             PTS_GRP07+
             PTS_GRP08+
             PTS_GRP09+
             PTS_GRP10+
             PTS_GRP11+
             # BTG_ME+
             # BCG_ME+
             # USE_GRP+
             CR_GRP_ME+
             UW_ROW+
             BIPD_SYM_GRP+
             LIMIT_GRP+
             RADIUS_GRP+
             VAGE_RAW+
             # VAGE_RAW2+
             VEH_PERS_USE_IND+
             PKG_DISC_NO_RT_NEW2+
             PIF_DISC+
             CDL_NORT_U_PCT_NEW+
             CDL_NORT_Y_PCT_NEW+
             USDOT_V41_GRPS+
             # ST_GRP+
             TERR_MDL,
           data = dt, 
           weights = BIPD_ECY,
           family=tweedie(var.power=p,link.power=0),na.action = na.omit, maxit = 200)

beta <- summary(mdl)$coefficients
phi  <- summary(mdl)$dispersion
output <- rbind(beta,phi)
output <- as.data.table(output, keep.rownames = T)

fwrite(output,file=paste0("D:/Sean/H2O/Output/ST_YEAR_specific/statmod/",dt_name,".csv"))

##################
# FL DATA MODEL #
##################

dt <- get("dt_2")
p <- get("p_2")
dt_name <- "dt_2"

dt[["BTG_ME"]] <- relevel(factor(dt[["BTG_ME"]]), "999")
dt[["BCG_ME"]] <- relevel(factor(dt[["BCG_ME"]]), "999")
dt[["USE_GRP"]] <- relevel(factor(dt[["USE_GRP"]]), "999") 
dt[["CR_GRP_ME"]] <- relevel(factor(dt[["CR_GRP_ME"]]), "C0")
dt[["UW_ROW"]] <- relevel(factor(dt[["UW_ROW"]]), "1")
dt[["BIPD_SYM_GRP"]] <- relevel(factor(dt[["BIPD_SYM_GRP"]]), "16")
dt[["LIMIT_GRP"]] <- relevel(factor(dt[["LIMIT_GRP"]]), "999")
dt[["RADIUS_GRP"]] <- relevel(factor(dt[["RADIUS_GRP"]]), "050")
dt[["VEH_PERS_USE_IND"]] <- relevel(factor(dt[["VEH_PERS_USE_IND"]]), "N")
dt[["PKG_DISC_NO_RT_NEW2"]] <- relevel(factor(dt[["PKG_DISC_NO_RT_NEW2"]]), "N")
dt[["PIF_DISC"]] <- relevel(factor(dt[["PIF_DISC"]]), "N")
dt[["USDOT_V41_GRPS"]] <- relevel(factor(dt[["USDOT_V41_GRPS"]]), "Z98")

# MODEL
mdl <- glm(PP~ UNLD_PCT +
             AGE_GRP01+
             AGE_GRP02+
             AGE_GRP03+
             AGE_GRP04+
             AGE_GRP05+
             AGE_GRP06+
             AGE_GRP08+
             AGE_GRP09+
             AGE_GRP10+
             AGE_GRP11+
             AGE_GRP12+
             AGE_GRP13+
             AGE_GRP14+
             PTS_GRP01+
             PTS_GRP02+
             PTS_GRP03+
             PTS_GRP04+
             PTS_GRP05+
             PTS_GRP06+
             PTS_GRP07+
             PTS_GRP08+
             PTS_GRP09+
             PTS_GRP10+
             PTS_GRP11+
             # BTG_ME+
             # BCG_ME+
             # USE_GRP+
             CR_GRP_ME+
             UW_ROW+
             BIPD_SYM_GRP+
             LIMIT_GRP+
             RADIUS_GRP+
             VAGE_RAW+
             # VAGE_RAW2+
             VEH_PERS_USE_IND+
             PKG_DISC_NO_RT_NEW2+
             PIF_DISC+
             CDL_NORT_U_PCT_NEW+
             CDL_NORT_Y_PCT_NEW+
             USDOT_V41_GRPS+
             # ST_GRP+
             TERR_MDL,
           data = dt, 
           weights = BIPD_ECY,
           family=tweedie(var.power=p,link.power=0),na.action = na.omit, maxit = 200)

beta <- summary(mdl)$coefficients
phi  <- summary(mdl)$dispersion
output <- rbind(beta,phi)
output <- as.data.table(output, keep.rownames = T)

fwrite(output,file=paste0("D:/Sean/H2O/Output/ST_YEAR_specific/statmod/",dt_name,".csv"))

##################
# TX DATA MODEL #
##################

dt <- get("dt_3")
p <- get("p_3")
dt_name <- "dt_3"

dt[["BTG_ME"]] <- relevel(factor(dt[["BTG_ME"]]), "999")
dt[["BCG_ME"]] <- relevel(factor(dt[["BCG_ME"]]), "999")
dt[["USE_GRP"]] <- relevel(factor(dt[["USE_GRP"]]), "999") 
dt[["CR_GRP_ME"]] <- relevel(factor(dt[["CR_GRP_ME"]]), "C0")
dt[["UW_ROW"]] <- relevel(factor(dt[["UW_ROW"]]), "1")
dt[["BIPD_SYM_GRP"]] <- relevel(factor(dt[["BIPD_SYM_GRP"]]), "16")
dt[["LIMIT_GRP"]] <- relevel(factor(dt[["LIMIT_GRP"]]), "999")
dt[["RADIUS_GRP"]] <- relevel(factor(dt[["RADIUS_GRP"]]), "050")
dt[["VEH_PERS_USE_IND"]] <- relevel(factor(dt[["VEH_PERS_USE_IND"]]), "N")
dt[["PKG_DISC_NO_RT_NEW2"]] <- relevel(factor(dt[["PKG_DISC_NO_RT_NEW2"]]), "N")
dt[["PIF_DISC"]] <- relevel(factor(dt[["PIF_DISC"]]), "N")
dt[["USDOT_V41_GRPS"]] <- relevel(factor(dt[["USDOT_V41_GRPS"]]), "Z98")

# MODEL
mdl <- glm(PP~ UNLD_PCT +
             # AGE_GRP01+
             # AGE_GRP02+
             # AGE_GRP03+
             # AGE_GRP04+
             # AGE_GRP05+
             # AGE_GRP06+
             # AGE_GRP08+
             # AGE_GRP09+
             # AGE_GRP10+
             # AGE_GRP11+
             # AGE_GRP12+
             # AGE_GRP13+
             # AGE_GRP14+
             PTS_GRP01+
             PTS_GRP02+
             PTS_GRP03+
             PTS_GRP04+
             PTS_GRP05+
             PTS_GRP06+
             PTS_GRP07+
             PTS_GRP08+
             PTS_GRP09+
             PTS_GRP10+
             PTS_GRP11+
             # BTG_ME+
             # BCG_ME+
             # USE_GRP+
             CR_GRP_ME+
             UW_ROW+
             BIPD_SYM_GRP+
             LIMIT_GRP+
             RADIUS_GRP+
             VAGE_RAW+
             # VAGE_RAW2+
             VEH_PERS_USE_IND+
             PKG_DISC_NO_RT_NEW2+
             PIF_DISC+
             CDL_NORT_U_PCT_NEW+
             CDL_NORT_Y_PCT_NEW+
             USDOT_V41_GRPS+
             # ST_GRP+
             TERR_MDL,
           data = dt, 
           weights = BIPD_ECY,
           family=tweedie(var.power=p,link.power=0),na.action = na.omit, maxit = 200)

beta <- summary(mdl)$coefficients
phi  <- summary(mdl)$dispersion
output <- rbind(beta,phi)
output <- as.data.table(output, keep.rownames = T)

fwrite(output,file=paste0("D:/Sean/H2O/Output/ST_YEAR_specific/statmod/",dt_name,".csv"))

##################
# CWX DATA MODEL #
##################

dt <- get("dt_4")
p <- get("p_4")
dt_name <- "dt_4"

dt[["BTG_ME"]] <- relevel(factor(dt[["BTG_ME"]]), "999")
dt[["BCG_ME"]] <- relevel(factor(dt[["BCG_ME"]]), "999")
dt[["USE_GRP"]] <- relevel(factor(dt[["USE_GRP"]]), "999") 
dt[["CR_GRP_ME"]] <- relevel(factor(dt[["CR_GRP_ME"]]), "C0")
dt[["UW_ROW"]] <- relevel(factor(dt[["UW_ROW"]]), "1")
dt[["BIPD_SYM_GRP"]] <- relevel(factor(dt[["BIPD_SYM_GRP"]]), "16")
dt[["LIMIT_GRP"]] <- relevel(factor(dt[["LIMIT_GRP"]]), "999")
dt[["RADIUS_GRP"]] <- relevel(factor(dt[["RADIUS_GRP"]]), "050")
dt[["VEH_PERS_USE_IND"]] <- relevel(factor(dt[["VEH_PERS_USE_IND"]]), "N")
dt[["PKG_DISC_NO_RT_NEW2"]] <- relevel(factor(dt[["PKG_DISC_NO_RT_NEW2"]]), "N")
dt[["PIF_DISC"]] <- relevel(factor(dt[["PIF_DISC"]]), "N")
dt[["USDOT_V41_GRPS"]] <- relevel(factor(dt[["USDOT_V41_GRPS"]]), "Z98")
dt[["ST_GRP"]] <- relevel(factor(dt[["ST_GRP"]]),"9")

# MODEL
mdl <- glm(PP~ UNLD_PCT +
             AGE_GRP01+
             AGE_GRP02+
             AGE_GRP03+
             AGE_GRP04+
             AGE_GRP05+
             AGE_GRP06+
             AGE_GRP08+
             AGE_GRP09+
             AGE_GRP10+
             AGE_GRP11+
             AGE_GRP12+
             AGE_GRP13+
             AGE_GRP14+
             PTS_GRP01+
             PTS_GRP02+
             PTS_GRP03+
             PTS_GRP04+
             PTS_GRP05+
             PTS_GRP06+
             PTS_GRP07+
             PTS_GRP08+
             PTS_GRP09+
             PTS_GRP10+
             PTS_GRP11+
             # BTG_ME+
             # BCG_ME+
             # USE_GRP+
             CR_GRP_ME+
             UW_ROW+
             BIPD_SYM_GRP+
             LIMIT_GRP+
             RADIUS_GRP+
             VAGE_RAW+
             # VAGE_RAW2+
             VEH_PERS_USE_IND+
             PKG_DISC_NO_RT_NEW2+
             PIF_DISC+
             CDL_NORT_U_PCT_NEW+
             CDL_NORT_Y_PCT_NEW+
             USDOT_V41_GRPS+
             ST_GRP+
             TERR_MDL,
           data = dt, 
           weights = BIPD_ECY,
           family=tweedie(var.power=p,link.power=0),na.action = na.omit, maxit = 200)
          
          beta <- summary(mdl)$coefficients
          phi  <- summary(mdl)$dispersion
          output <- rbind(beta,phi)
          output <- as.data.table(output, keep.rownames = T)
          
fwrite(output,file=paste0("D:/Sean/H2O/Output/ST_YEAR_specific/statmod/",dt_name,".csv"))

#######################
# LOOP OVER DATASETS  #
#######################

for (i in 1:3){
  dt <- get(paste0("dt_",i))
  p <- get(paste0("p_",i))
  dt_name <- paste0("dt_",i)
  
  # RELEVEL
  dt[["BTG_ME"]] <- relevel(factor(dt[["BTG_ME"]]), "999")
  dt[["BCG_ME"]] <- relevel(factor(dt[["BCG_ME"]]), "999")
  dt[["USE_GRP"]] <- relevel(factor(dt[["USE_GRP"]]), "999") 
  dt[["CR_GRP_ME"]] <- relevel(factor(dt[["CR_GRP_ME"]]), "C0")
  dt[["UW_ROW"]] <- relevel(factor(dt[["UW_ROW"]]), "1")
  dt[["BIPD_SYM_GRP"]] <- relevel(factor(dt[["BIPD_SYM_GRP"]]), "16")
  dt[["LIMIT_GRP"]] <- relevel(factor(dt[["LIMIT_GRP"]]), "999")
  dt[["RADIUS_GRP"]] <- relevel(factor(dt[["RADIUS_GRP"]]), "050")
  dt[["VEH_PERS_USE_IND"]] <- relevel(factor(dt[["VEH_PERS_USE_IND"]]), "N")
  dt[["PKG_DISC_NO_RT_NEW2"]] <- relevel(factor(dt[["PKG_DISC_NO_RT_NEW2"]]), "N")
  dt[["PIF_DISC"]] <- relevel(factor(dt[["PIF_DISC"]]), "N")
  dt[["USDOT_V41_GRPS"]] <- relevel(factor(dt[["USDOT_V41_GRPS"]]), "Z98")
  
  # MODEL
  mdl <- glm(PP~ UNLD_PCT +
               AGE_GRP01+
               AGE_GRP02+
               AGE_GRP03+
               AGE_GRP04+
               AGE_GRP05+
               AGE_GRP06+
               AGE_GRP08+
               AGE_GRP09+
               AGE_GRP10+
               AGE_GRP11+
               AGE_GRP12+
               AGE_GRP13+
               AGE_GRP14+
               PTS_GRP01+
               PTS_GRP02+
               PTS_GRP03+
               PTS_GRP04+
               PTS_GRP05+
               PTS_GRP06+
               PTS_GRP07+
               PTS_GRP08+
               PTS_GRP09+
               PTS_GRP10+
               PTS_GRP11+
               # BTG_ME+
               # BCG_ME+
               # USE_GRP+
               CR_GRP_ME+
               UW_ROW+
               BIPD_SYM_GRP+
               LIMIT_GRP+
               RADIUS_GRP+
               VAGE_RAW+
               # VAGE_RAW2+
               VEH_PERS_USE_IND+
               PKG_DISC_NO_RT_NEW2+
               PIF_DISC+
               CDL_NORT_U_PCT_NEW+
               CDL_NORT_Y_PCT_NEW+
               USDOT_V41_GRPS+
               # ST_GRP+
               TERR_MDL,
             data = dt, 
             weights = BIPD_ECY,
             family=tweedie(var.power=p,link.power=0),na.action = na.omit, maxit = 200)
  
  beta <- summary(mdl)$coefficients
  phi  <- summary(mdl)$dispersion
  output <- rbind(beta,phi)
  output <- as.data.table(output, keep.rownames = T)
  
  fwrite(output,file=paste0("D:/Sean/H2O/Output/ST_YEAR_specific/statmod/",dt_name,".csv"))
  print(i)
  
}