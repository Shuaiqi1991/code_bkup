library(h2o)
h2o.init()

step1 <- h2o.loadModel("D:/Sean/github/Casper/model/h2o/bipd_79b_2018_age_pts_s2_mdl/bipd_79b_2018_age_pts_s2_mdl_step_1")
step2 <- h2o.loadModel("D:/Sean/github/Casper/model/h2o/bipd_79b_2018_age_pts_s2_mdl/bipd_79b_2018_age_pts_s2_mdl_step_2")

for (i in 1:2){
  
  step <- get(paste0("step",i))
  step_name <- paste0("step",i)
  
  coef_tab <- step@model$coefficients_table
  phi <- as.data.table(step@model$dispersion)
  colnames(phi) <- "coefficients" 
  phi <- data.table(names = "dispersion", phi)
  coef <- rbind(coef_tab, phi, fill = TRUE)
  fwrite(coef,file=paste0("D:/Sean/CAPP_2019_79C/79B_mod_79C/OUTPUT/PTS_Sensitivity_Test/",step_name,".csv"))
  
}