# Set environment
library(data.table)
library(odbc)
library(stringr)
library(here)

change_here <- function(new_path){
  new_root <- here:::.root_env
  
  new_root$f <- function(...){file.path(new_path, ...)}
  
  assignInNamespace(".root_env", new_root, ns = "here")
}
change_here("D:/Sean/2020_Q1/Tier_Improvement")

# SET SQL QUERY 
uid <- "x011870"
pwd <- readLines('U:/x011870/pswd.txt', warn = FALSE)
var_lib_path <- "D:/Sean/8.0_CAPP/Off_Balance/BLOCK_1_2_on_2019/Data/XLS_FILE"

start_date <- "2014-01-01"
end_date <- "2020-01-31"

###################################
# GET VIOLATION CNT AT DRVR LEVEL #
###################################
# CONNECT TO CAW
caw_con <- dbConnect(odbc(), 'DB2P', uid=uid, pwd=pwd)

# VIOLATIONS QUERY
viol_qry <- 
  "
SELECT 
CAW.DRIVER_VIOL.ST_CD, 
CAW.DRIVER_VIOL.PHYS_POL_KEY, 
CAW.DRIVER_VIOL.PHYS_DRVR_KEY, 
CAW.DRIVER_VIOL.VIOL_CD, 
CAW.DRIVER_VIOL.DRVR_INCID_DT, 
CAW.DRIVER_VIOL.DRVR_PNT_SRCE_CD
FROM 
CAW.DRIVER_VIOL
WHERE 
CAW.DRIVER_VIOL.POL_EXPR_YR IN (pol_expr_yrs)
;
"

# DRIVER LICIENCE NBR QUERY
dr_lic_qry <- 
  "
SELECT 
CAW.DRVR_SEC_VIEW.ST_CD,
CAW.DRVR_SEC_VIEW.PHYS_POL_KEY,
CAW.DRVR_SEC_VIEW.PHYS_DRVR_KEY,
CAW.DRVR_SEC_VIEW.DRVR_LIC_NBR 
FROM
CAW.DRVR_SEC_VIEW 
WHERE 
CAW.DRVR_SEC_VIEW.POL_EXPR_YR IN (pol_expr_yrs)
;
"

# POLICY DATES QUERY
pol_qry <- 
  "
SELECT 
CAW.POLICY.ST_CD, 
CAW.POLICY.PHYS_POL_KEY,
CAW.POLICY.POL_ID_NBR,
CAW.POLICY.RENW_CNT,
CAW.POL_DATES.POL_EFF_DT,
CAW.POL_DATES.POL_STOP_DT
FROM 
CAW.POL_DATES, 
CAW.POLICY 
WHERE 
CAW.POL_DATES.POL_ID_CHAR = CAW.POLICY.POL_ID_CHAR 
AND CAW.POL_DATES.RENW_SFX_NBR = CAW.POLICY.RENW_SFX_NBR 
AND CAW.POL_DATES.POL_EXPR_YR = CAW.POLICY.POL_EXPR_YR 
AND CAW.POL_DATES.POL_EFF_DT BETWEEN {d 'startdate'} AND {d 'enddate'}
;
"

# INSERT START AND END DATE INTO QUERY
min_pol_expr_yr <- lubridate::year(as.Date(start_date))
pol_expr_yrs <- seq(min_pol_expr_yr, lubridate::year(lubridate::today())+1)
pol_expr_yrs <- substr(pol_expr_yrs, 3, 4)
pol_expr_yrs <- paste(paste0("'", pol_expr_yrs, "'"), collapse=",")
viol_qry <- str_replace_all(viol_qry, 'pol_expr_yrs', pol_expr_yrs)
dr_lic_qry <- str_replace_all(dr_lic_qry, 'pol_expr_yrs', pol_expr_yrs)
pol_qry <- str_replace_all(pol_qry, 'startdate', start_date)
pol_qry <- str_replace_all(pol_qry, 'enddate', end_date)

# GET VIOLATION DATA
viol_data <- as.data.table(dbGetQuery(caw_con, viol_qry))

# GET DRIVER DATES DATA
dr_lic_data <- as.data.table(dbGetQuery(caw_con, dr_lic_qry))

# GET POLICY DATES
pol_data <- as.data.table(dbGetQuery(caw_con, pol_qry))

# JOIN VIOLATION AND LICIENCE NBR
viol_data <- dr_lic_data[viol_data, on=.(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY)]

# JOIN DATES AND VIOLATION DATA
viol_data <- merge(pol_data, viol_data, by=c('ST_CD', 'PHYS_POL_KEY'))

# FDL AND UDR HAVE VIOLATION DATE SET TO 11/11/1911
viol_data[DRVR_INCID_DT<=as.Date('1911-11-11'), DRVR_INCID_DT:=POL_EFF_DT]

# GET DRVR POS CNT
viol_data[,DRVR_POS_CNT:=substr(PHYS_DRVR_KEY,14,16)]

# LOOKUP VIOLATION CLASS
lookup_vio_cls <- fread(here('Data','lookup_vio_cls.csv'))
viol_data[, VIOL_CD:=trimws(VIOL_CD)]
viol_data <- lookup_vio_cls[viol_data, on=.(VIOL_CD)]
# IN IOWA SP1 CONSIDERED AS SPD IN MIN_CL
viol_data[ST_CD=='14' & VIOL_CD=='SP1', VIOL_CLS:='C']

# ASSIGN POINTS FOR FIRST VIOLATION
viol_data <- viol_data[order(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY, VIOL_CLS, DRVR_INCID_DT)]
first_viol_pts <- fread(here('Data','lookup_first_pts.csv'))
viol_data <- first_viol_pts[viol_data, on=.(VIOL_CLS)]

# ASSIGN POINTS FOR ADDITIONAL VIOLATIONS
addtl_viol_pts <- fread(here('Data','lookup_addtl_pts.csv'))
setnames(addtl_viol_pts, 'VIOL_PT', 'ADDTL_PT')
viol_data <- addtl_viol_pts[viol_data, on=.(VIOL_CLS)]
first_inds <- viol_data[, .I[1], by=.(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY, VIOL_CLS)]$V1
viol_data[!first_inds, VIOL_PT:=ADDTL_PT]

# REMOVE SAME DAY VIOLATIONS AND KEEP HIGHEST RANKED VIOLATION IN A DAY
viol_data <- viol_data[order(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY, DRVR_INCID_DT, -VIOL_PT, -VIOL_CLS)]
first_inds <- viol_data[, .I[1], by=.(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY, DRVR_INCID_DT)]$V1
viol_data <- viol_data[first_inds]

# COUNT VIOLATION BY TYPE
vio_type <- c("NP_AAF", "P_AAF", "MAJ", "MIN", "P_NAF", "NP_NAF", "DUI")
for (vio in vio_type) {viol_data[,(vio):=0]}

viol_data[,VIOL_CD:=trimws(VIOL_CD)]
viol_data[,DRVR_PNT_SRCE_CD:=trimws(DRVR_PNT_SRCE_CD)]

viol_data[VIOL_CD %in% c('AAF','AC1','CAF','CC1') & DRVR_PNT_SRCE_CD == 'P', P_AAF:= 1]
viol_data[VIOL_CD %in% c('AAF','AC1','CAF','CC1') & DRVR_PNT_SRCE_CD != 'P', NP_AAF:= 1]

viol_data[VIOL_CD %in% c('CRD','DR','FAR','FEL','FLE','FRA','HOM','LTS','RKD','SUS','WOC'), MAJ:= 1]

viol_data[VIOL_CD %in% c('DEV','FTC','FTY','IBK','IP','IT','LIC','MMV','NCS','OVW','SAF','SBV','SCH','SP1','SP2','SPD','SPO','WSR'), MIN:= 1]

viol_data[VIOL_CD %in% c('AFR','CNF','NAF') & DRVR_PNT_SRCE_CD == 'P', P_NAF:= 1]
viol_data[VIOL_CD %in% c('AFR','CNF','NAF') & DRVR_PNT_SRCE_CD != 'P', NP_NAF:= 1]

viol_data[VIOL_CD %in% c('DWI','BOT','REF'), DUI:= 1] 

##################
# Driver Data    #
##################
# DRVR QUERY 
drv_qry <- 
  "
  SELECT 
  CAW.POLICY.ST_CD, 
  CAW.POLICY.PHYS_POL_KEY, 
  CAW.DRVR_PUB_VIEW.PHYS_DRVR_KEY, 
  CAW.DRVR_DATES.DRVR_AT_INCP_IND,
  CAW.DRVR_DATES.DRVR_STRT_DT, 
  CAW.DRVR_DATES.DRVR_STOP_DT, 
  CAW.POLICY.POWER_UNIT_CNT,
  CAW.DRVR_PUB_VIEW.DRVR_AGE, 
  CAW.DRVR_PUB_VIEW.EXCL_IND, 
  CAW.DRVR_PUB_VIEW.DRVR_MOCK_IND,
  CAW.DRVR_PUB_VIEW.DRVR_BRTH_DT
  FROM 
  CAW.POL_DATES, 
  CAW.DRVR_DATES, 
  CAW.DRVR_PUB_VIEW, 
  CAW.POLICY 
  WHERE 
  CAW.POL_DATES.POL_EFF_DT BETWEEN {d 'startdate'} and {d 'enddate'}
  AND CAW.POLICY.POL_ID_CHAR = CAW.DRVR_PUB_VIEW.POL_ID_CHAR 
  AND CAW.POLICY.RENW_SFX_NBR = CAW.DRVR_PUB_VIEW.RENW_SFX_NBR 
  AND CAW.POLICY.POL_EXPR_YR = CAW.DRVR_PUB_VIEW.POL_EXPR_YR 
  AND CAW.DRVR_PUB_VIEW.ST_CD = CAW.DRVR_DATES.ST_CD 
  AND CAW.DRVR_PUB_VIEW.POL_ID_CHAR = CAW.DRVR_DATES.POL_ID_CHAR 
  AND CAW.DRVR_PUB_VIEW.RENW_SFX_NBR = CAW.DRVR_DATES.RENW_SFX_NBR 
  AND CAW.DRVR_PUB_VIEW.POL_EXPR_YR = CAW.DRVR_DATES.POL_EXPR_YR 
  AND CAW.DRVR_PUB_VIEW.DRVR_POS_CNT = CAW.DRVR_DATES.DRVR_POS_CNT 
  AND CAW.DRVR_PUB_VIEW.DRVR_VRSN_NBR = CAW.DRVR_DATES.DRVR_VRSN_NBR 
  AND CAW.POLICY.POL_ID_CHAR = CAW.POL_DATES.POL_ID_CHAR 
  AND CAW.POLICY.RENW_SFX_NBR = CAW.POL_DATES.RENW_SFX_NBR 
  AND CAW.POLICY.POL_EXPR_YR = CAW.POL_DATES.POL_EXPR_YR 
  GROUP BY
  CAW.POLICY.ST_CD, 
  CAW.POLICY.PHYS_POL_KEY, 
  CAW.DRVR_PUB_VIEW.PHYS_DRVR_KEY, 
  CAW.DRVR_DATES.DRVR_AT_INCP_IND,
  CAW.DRVR_DATES.DRVR_STRT_DT,
  CAW.DRVR_DATES.DRVR_STOP_DT, 
  CAW.POLICY.POWER_UNIT_CNT,
  CAW.DRVR_PUB_VIEW.DRVR_AGE, 
  CAW.DRVR_PUB_VIEW.EXCL_IND, 
  CAW.DRVR_PUB_VIEW.DRVR_MOCK_IND,
  CAW.DRVR_PUB_VIEW.DRVR_BRTH_DT
  ;
  "

# INSERT START AND END DATE INTO QUERY
drv_qry <- str_replace_all(drv_qry, 'startdate', start_date)
drv_qry <- str_replace_all(drv_qry, 'enddate', end_date)

# GET DRIVER DATA
drv_data <- as.data.table(dbGetQuery(caw_con, drv_qry))

# FILTER OUT MOCK DRIVERS, EXCLUDED DRIVERS
# drv_data <- drv_data[DRVR_AT_INCP_IND=='Y'] 
drv_data <- drv_data[EXCL_IND!='Y']
drv_data <- drv_data[DRVR_MOCK_IND!='Y']

#######################
# GET VIOLATION COUNT #
#######################
# MERGE DRVR DATA WITH VIOLATION DATA (GET VIOLATION COUNT)
viol_cnt <- merge(drv_data, viol_data, by=c('ST_CD', 'PHYS_POL_KEY', 'PHYS_DRVR_KEY'))
viol_cnt[,DRVR_LIC_NBR:=trimws(DRVR_LIC_NBR)]

# RESET DRVR_BRTH_DAY FOR DRVR WITH DRVR_LIC_NBR (portion of DRVR_LIC_NBR associate with multiple DRVR_BRTH_DAY)
viol_cnt[DRVR_LIC_NBR !='INTERNATIONAL'&DRVR_LIC_NBR !='REQUESTED', DRVR_BRTH_DT:= as.Date("1900-01-01")]

# REMOVE DUPLICATE VIOLATION RECORDS DUE TO DRVR VERSION UPDATE
viol_cnt <- viol_cnt[order(ST_CD, PHYS_POL_KEY, DRVR_LIC_NBR, DRVR_BRTH_DT, VIOL_CD, DRVR_PNT_SRCE_CD, DRVR_INCID_DT, -DRVR_AT_INCP_IND)]
first_vio <- viol_cnt[,.I[1], by=.(ST_CD, PHYS_POL_KEY, DRVR_LIC_NBR, DRVR_BRTH_DT, VIOL_CD, DRVR_PNT_SRCE_CD, DRVR_INCID_DT)]$V1
viol_cnt <- viol_cnt[first_vio]

# # SPLIT DATA FOR DRVR_LIC_NBR == INTERNATIONAL/ REQUESTED
# viol_cnt_normal <- viol_cnt[DRVR_LIC_NBR !='INTERNATIONAL'&DRVR_LIC_NBR !='REQUESTED']
# viol_cnt_reqint <- viol_cnt[DRVR_LIC_NBR =='INTERNATIONAL'|DRVR_LIC_NBR =='REQUESTED']

# # REMOVE DUPLICATE VIOLATION RECORDS DUE TO DRVR VERSION UPDATE
# viol_cnt_normal <- viol_cnt_normal[order(ST_CD, PHYS_POL_KEY, DRVR_LIC_NBR, VIOL_CD, DRVR_PNT_SRCE_CD, DRVR_INCID_DT, -DRVR_AT_INCP_IND)]
# first_vio <- viol_cnt_normal[,.I[1], by=.(ST_CD, PHYS_POL_KEY, DRVR_LIC_NBR, VIOL_CD, DRVR_PNT_SRCE_CD, DRVR_INCID_DT)]$V1
# viol_cnt_normal <- viol_cnt_normal[first_vio]
# 
# viol_cnt_reqint <- viol_cnt_reqint[order(ST_CD, PHYS_POL_KEY, DRVR_LIC_NBR, DRVR_BRTH_DT, VIOL_CD, DRVR_PNT_SRCE_CD, DRVR_INCID_DT, -DRVR_AT_INCP_IND)]
# first_vio <- viol_cnt_reqint[,.I[1], by=.(ST_CD, PHYS_POL_KEY, DRVR_LIC_NBR, DRVR_BRTH_DT, VIOL_CD, DRVR_PNT_SRCE_CD, DRVR_INCID_DT)]$V1
# viol_cnt_reqint <- viol_cnt_reqint[first_vio]

###############
# Load policy #
###############
pol <- fread(here('Data','POL.CSV'))
# FORMAT
pol[,ST_CD:=str_pad(ST_CD, width=2, side='left', pad='0')]
pol[,PHYS_POL_KEY:=as.character(PHYS_POL_KEY)]
pol[,POL_EFF_DT:=as.Date(POL_EFF_DT,"%d%b%Y")]
pol[,POL_EXPR_DT:=as.Date(POL_EXPR_DT,"%d%b%Y")]
pol[,POL_STOP_DT:=as.Date(POL_STOP_DT,"%d%b%Y")]

# Term cnt & term pos
pol <- pol[order(ST_CD, POL_ID_NBR, RENW_CNT)]
pol[,term_cnt:=.N, by=.(ST_CD, POL_ID_NBR)]
pol[,term_pos:=sequence(.N), by=.(ST_CD, POL_ID_NBR)]

#######################
# Assign Drvr to Pol  #
#######################
# ATTACH DRVR LIC NBR TO DRVR DATA
drv_data <-  dr_lic_data[drv_data, on=.(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY)]
drv_data_at_incp <- drv_data[DRVR_AT_INCP_IND=='Y']

# ASSIGN DRVR TO POLICY
pol_drvr <- drv_data_at_incp[pol, on=.(ST_CD, PHYS_POL_KEY)]
pol_drvr[, DRVR_LIC_NBR:=trimws(DRVR_LIC_NBR)]

# SPLIT POLICIES THAT CAN NOT FIND MATCHED DRVR WITH DRVR AT INCP
pol_drvr_rematch <- pol_drvr[is.na(PHYS_DRVR_KEY)]
pol_drvr <- pol_drvr[!is.na(PHYS_DRVR_KEY)]

  # RESET DRVR_BRTH_DAY FOR DRVR WITH DRVR_LIC_NBR (portion of DRVR_LIC_NBR associate with multiple DRVR_BRTH_DAY)
  pol_drvr <- pol_drvr[DRVR_LIC_NBR !='INTERNATIONAL'&DRVR_LIC_NBR !='REQUESTED', DRVR_BRTH_DT:= as.Date("1900-01-01")]
  
  # REMOVE DUPLICATE DRVR DUE TO DRVR VERSION UPDATE (INTERNATIONAL/ REQUESTED)
  pol_drvr <- pol_drvr[order (ST_CD, PHYS_POL_KEY, DRVR_LIC_NBR, DRVR_BRTH_DT, -PHYS_DRVR_KEY)]
  first_obs <- pol_drvr[,.I[1], by=.(ST_CD, PHYS_POL_KEY, DRVR_LIC_NBR, DRVR_BRTH_DT)]$V1
  pol_drvr <- pol_drvr[first_obs]
  
  # # SPLIT RECOREDS BETWEEN DRVR WITH LIC NBR AND WITHOUT
  # pol_drvr_normal <- pol_drvr[DRVR_LIC_NBR !='INTERNATIONAL'&DRVR_LIC_NBR !='REQUESTED']
  # pol_drvr_reqint <- pol_drvr[DRVR_LIC_NBR =='INTERNATIONAL'|DRVR_LIC_NBR =='REQUESTED']
  # 
  # # REMOVE DUPLICATE DRVR DUE TO DRVR VERSION UPDATE (NOT INTERNATIONAL/ REQUESTED)
  # pol_drvr_normal <- pol_drvr_normal[order (ST_CD, PHYS_POL_KEY, DRVR_LIC_NBR, -PHYS_DRVR_KEY)]
  # first_obs <- pol_drvr_normal[,.I[1], by=.(ST_CD, PHYS_POL_KEY, DRVR_LIC_NBR)]$V1
  # pol_drvr_normal <- pol_drvr_normal[first_obs]
  # 
  # # REMOVE DUPLICATE DRVR DUE TO DRVR VERSION UPDATE (INTERNATIONAL/ REQUESTED)
  # pol_drvr_reqint <- pol_drvr_reqint[order (ST_CD, PHYS_POL_KEY, DRVR_LIC_NBR, DRVR_BRTH_DT, -PHYS_DRVR_KEY)]
  # first_obs <- pol_drvr_reqint[,.I[1], by=.(ST_CD, PHYS_POL_KEY, DRVR_LIC_NBR, DRVR_BRTH_DT)]$V1
  # pol_drvr_reqint <- pol_drvr_reqint[first_obs]

# REMATCH
pol_drvr_rematch[,c("PHYS_DRVR_KEY","DRVR_LIC_NBR","DRVR_AT_INCP_IND","DRVR_STRT_DT","DRVR_STOP_DT",
                    "POWER_UNIT_CNT","DRVR_AGE","EXCL_IND","DRVR_MOCK_IND", "DRVR_BRTH_DT"):=NULL] 

pol_drvr_rematch <- drv_data[pol_drvr_rematch, on=.(ST_CD, PHYS_POL_KEY)]
pol_drvr_rematch[, DRVR_LIC_NBR:=trimws(DRVR_LIC_NBR)]

  # RESET DRVR_BRTH_DAY FOR DRVR WITH DRVR_LIC_NBR (portion of one DRVR_LIC_NBR associate with multiple DRVR_BRTH_DAY)
  pol_drvr_rematch <- pol_drvr_rematch[DRVR_LIC_NBR !='INTERNATIONAL'&DRVR_LIC_NBR !='REQUESTED', DRVR_BRTH_DT:= as.Date("1900-01-01")]
  
  # REMOVE DUPLICATE DRVR DUE TO DRVR VERSION UPDATE (INTERNATIONAL/ REQUESTED)
  pol_drvr_rematch <- pol_drvr_rematch[order (ST_CD, PHYS_POL_KEY, DRVR_LIC_NBR, DRVR_BRTH_DT, -PHYS_DRVR_KEY)]
  first_obs <- pol_drvr_rematch[,.I[1], by=.(ST_CD, PHYS_POL_KEY, DRVR_LIC_NBR, DRVR_BRTH_DT)]$V1
  pol_drvr_rematch <- pol_drvr_rematch[first_obs]

  # # SPLIT RECOREDS BETWEEN DRVR WITH LIC NBR AND WITHOUT
  # pol_drvr_rematch_normal <- pol_drvr_rematch[DRVR_LIC_NBR !='INTERNATIONAL'&DRVR_LIC_NBR !='REQUESTED']
  # pol_drvr_rematch_reqint <- pol_drvr_rematch[DRVR_LIC_NBR =='INTERNATIONAL'|DRVR_LIC_NBR =='REQUESTED']
  # 
  # # REMOVE DUPLICATE DRVR DUE TO DRVR VERSION UPDATE (NOT INTERNATIONAL/ REQUESTED)
  # pol_drvr_rematch_normal <- pol_drvr_rematch_normal[order (ST_CD, PHYS_POL_KEY, DRVR_LIC_NBR, -PHYS_DRVR_KEY)]
  # first_obs <- pol_drvr_rematch_normal[,.I[1], by=.(ST_CD, PHYS_POL_KEY, DRVR_LIC_NBR)]$V1
  # pol_drvr_rematch_normal <- pol_drvr_rematch_normal[first_obs] 
  # 
  # # REMOVE DUPLICATE DRVR DUE TO DRVR VERSION UPDATE (INTERNATIONAL/ REQUESTED)
  # pol_drvr_rematch_reqint <- pol_drvr_rematch_reqint[order (ST_CD, PHYS_POL_KEY, DRVR_LIC_NBR, DRVR_BRTH_DT, -PHYS_DRVR_KEY)]
  # first_obs <- pol_drvr_rematch_reqint[,.I[1], by=.(ST_CD, PHYS_POL_KEY, DRVR_LIC_NBR, DRVR_BRTH_DT)]$V1
  # pol_drvr_rematch_reqint <- pol_drvr_rematch_reqint[first_obs] 
  
# COMBINE
pol_drvr <- rbind(pol_drvr, pol_drvr_rematch)
  
############################
# FLAG ADD DRVR / DEL DRVR #
############################
# SUBSET DATA 
sub <- pol_drvr[,.(ST_CD, PHYS_POL_KEY, DRVR_LIC_NBR, DRVR_BRTH_DT, POL_ID_NBR, RENW_CNT, term_cnt, term_pos)]

## FLAG DELETE DRVR IN NEXT TERM
# ORDER DATA TO GET DIFFERENT TERM TOGETHER
sub <- sub[order(ST_CD, POL_ID_NBR, RENW_CNT)]
first <- sub[,.I[1], by=.(ST_CD, PHYS_POL_KEY)]$V1
sub_2 <- sub[first]

# ASSGIN PREVIOUS TERM POL_KEY TO NEXT TERM DRVR
sub_2[,pre_POL_KEY:=lag(PHYS_POL_KEY)]
sub_2 <- sub_2[,.(ST_CD, PHYS_POL_KEY, pre_POL_KEY)]
sub_2 <- sub[,.(ST_CD, PHYS_POL_KEY, DRVR_LIC_NBR, DRVR_BRTH_DT)][sub_2, on=.(ST_CD, PHYS_POL_KEY)]
sub_2[,DEL_DRVR_NEXT_TERM:=0][,PHYS_POL_KEY:=NULL]
sub_2[,PHYS_POL_KEY:=pre_POL_KEY][,pre_POL_KEY:=NULL]

# IF DRVR DOES NOT GET MATCHED, THEN IT'S A DELETE DRVR IN THE NEXT TERM
pol_drvr <- merge(pol_drvr, sub_2, by = c("ST_CD", "PHYS_POL_KEY", "DRVR_LIC_NBR", "DRVR_BRTH_DT"),all.x = T)
pol_drvr[is.na(DEL_DRVR_NEXT_TERM), DEL_DRVR_NEXT_TERM:=1]
# LAST TERM SHOULD NOT CONTAIN DELETED DRVR
pol_drvr[term_pos==term_cnt, DEL_DRVR_NEXT_TERM:=0]

## FLAG ADD DRVR IN CURRENT TERM
# ORDER DATA TO GET DIFFERENT TERM TOGETHER
sub <- sub[order(ST_CD, POL_ID_NBR, RENW_CNT)]
first <- sub[,.I[1], by=.(ST_CD, PHYS_POL_KEY)]$V1
sub_2 <- sub[first]

# ASSGIN NEXT TERM POL_KEY TO PREVIOUS TERM DRVR
sub_2[,next_POL_KEY:=lead(PHYS_POL_KEY)]
sub_2 <- sub_2[,.(ST_CD, PHYS_POL_KEY, next_POL_KEY)]
sub_2 <- sub[,.(ST_CD, PHYS_POL_KEY, DRVR_LIC_NBR, DRVR_BRTH_DT)][sub_2, on=.(ST_CD, PHYS_POL_KEY)]
sub_2[,ADD_DRVR:=0][,PHYS_POL_KEY:=NULL]
sub_2[,PHYS_POL_KEY:=next_POL_KEY][,next_POL_KEY:=NULL]

# IF DRVR DOES NOT GET MATCHED, THEN IT'S A NEWLY ADD DRVR
pol_drvr <- merge(pol_drvr, sub_2, by = c("ST_CD","PHYS_POL_KEY", "DRVR_LIC_NBR",  "DRVR_BRTH_DT"),all.x = TRUE)
pol_drvr[is.na(ADD_DRVR), ADD_DRVR:=1]
# FIRST TERM SHOULD NOT CONTAIN ADD DRVR
pol_drvr[term_pos==1, ADD_DRVR:=0]

# ORDER POLICY BY POL_ID_NBR TO GET MULTIPLE TERM TOGETHER
pol_drvr <- pol_drvr[order(ST_CD, POL_ID_NBR, RENW_CNT, DRVR_LIC_NBR)]

# DELETE UNNECESSARY FILE
rm(list=c("sub","sub_2"))

###################################################
# Assign VIOL to DRVR & AGGREGATE TO POLICY LEVEL #
###################################################
# CLEAN VIOLATION COUNT
drop<-c("PHYS_DRVR_KEY","DRVR_AT_INCP_IND","DRVR_STRT_DT", "DRVR_STOP_DT","POWER_UNIT_CNT","DRVR_POS_CNT",
        "DRVR_AGE","EXCL_IND","DRVR_MOCK_IND","POL_ID_NBR","POL_EFF_DT","POL_STOP_DT","RENW_CNT")

viol_cnt[,c(drop):=NULL]

# ASSIGN VIOLATION TO DRVR
pol_viol <- merge(pol_drvr, viol_cnt, by=c("ST_CD", "PHYS_POL_KEY", "DRVR_LIC_NBR", "DRVR_BRTH_DT"))

# GET FIRST DAY A VIOLATION WILL BE COUNTED
pol_viol[,FIRST_LKBK_DT:=POL_EFF_DT-lubridate::years(5)]

# GET PRIOR TERM POL_EFF_DT
  sub <- pol[,.(ST_CD,POL_ID_NBR,PHYS_POL_KEY,POL_EFF_DT,RENW_CNT,term_cnt,term_pos)]
  sub <- sub[order(ST_CD, POL_ID_NBR, RENW_CNT)]
  first <- sub[,.I[1], by=.(ST_CD, PHYS_POL_KEY)]$V1
  sub <- sub[first]
  
  sub <- sub[order(ST_CD, POL_ID_NBR, RENW_CNT)]
  sub[,PRIOR_POL_EFF_DT:=lag(POL_EFF_DT)]
  # FORCE FIRST TREM POLICY PRIOR_POL_EFF_DT AS CURRENT TERM POL_EFF_DT
  sub[term_pos==1, PRIOR_POL_EFF_DT:=POL_EFF_DT]
  
  # ATTACH PRIOR_POL_EFF_DT
  sub <- sub[,.(ST_CD, PHYS_POL_KEY, PRIOR_POL_EFF_DT)]
  pol_viol <- merge(pol_viol, sub, by=c("ST_CD", "PHYS_POL_KEY"), all.x = TRUE)
  
  rm(sub)

# TRIM VIOL BEFORE FIRST_LKBK_DT AND AFTER POL_EFF_DT
pol_viol <- pol_viol[DRVR_INCID_DT >= FIRST_LKBK_DT & DRVR_INCID_DT < POL_EFF_DT]

# COUNT RBF (ALSO USED FOR FIRST TIME IN TIER VIOL COUNT)-- 5 YR BK TO CURRENT TERM EFF DT
pol_viol_RBF <- pol_viol[, 
                         .(RBF_NP_AAFs=sum(NP_AAF),
                           RBF_P_AAFs=sum(P_AAF),
                           RBF_MAJs=sum(MAJ),
                           RBF_MINs=sum(MIN),
                           RBF_P_NAFs=sum(P_NAF),
                           RBF_NP_NAFs=sum(NP_NAF),
                           RBF_DUIs=sum(DUI)),
                          by=.(ST_CD, PHYS_POL_KEY)]

pol_viol_RBF[,RBF_NAFs:= RBF_P_NAFs+RBF_NP_NAFs]

# COUNT RBT -- PRI TERM EFF DT TO CURRENT TERM EFF DT + NEWLY ADD DRVR 5 YR LKBK (IN THIS R LOGIC, RBF INCLUDE RBT VIOLATIONS)
  # COUNT RBT FOR DRVR INHERITING FROM PREVIOUS TERM 
  pol_viol_RBT_LIST <- pol_viol[ADD_DRVR != 1 & DRVR_INCID_DT >= PRIOR_POL_EFF_DT, 
                                .(RBT_NP_AAFs=sum(NP_AAF),
                                  RBT_P_AAFs=sum(P_AAF),
                                  RBT_MAJs=sum(MAJ),
                                  RBT_MINs=sum(MIN),
                                  RBT_P_NAFs=sum(P_NAF),
                                  RBT_NP_NAFs=sum(NP_NAF),
                                  RBT_DUIs=sum(DUI)),
                                by=.(ST_CD, PHYS_POL_KEY)]
  # COUNT RBT FOR NEWLY ADD DRVR
  pol_viol_RBT_NEW <- pol_viol[ADD_DRVR == 1, 
                               .(RBT_NP_AAFs=sum(NP_AAF),
                                 RBT_P_AAFs=sum(P_AAF),
                                 RBT_MAJs=sum(MAJ),
                                 RBT_MINs=sum(MIN),
                                 RBT_P_NAFs=sum(P_NAF),
                                 RBT_NP_NAFs=sum(NP_NAF),
                                 RBT_DUIs=sum(DUI)),
                               by=.(ST_CD, PHYS_POL_KEY)]
  
  # COMBINE
  pol_viol_RBT <- rbind(pol_viol_RBT_LIST, pol_viol_RBT_NEW)
  pol_viol_RBT <- pol_viol_RBT[,.(RBT_NP_AAFs=sum(RBT_NP_AAFs),
                                  RBT_P_AAFs=sum(RBT_P_AAFs),
                                  RBT_MAJs=sum(RBT_MAJs),
                                  RBT_MINs=sum(RBT_MINs),
                                  RBT_P_NAFs=sum(RBT_P_NAFs),
                                  RBT_NP_NAFs=sum(RBT_NP_NAFs),
                                  RBT_DUIs=sum(RBT_DUIs)),
                               by=.(ST_CD, PHYS_POL_KEY)]

  pol_viol_RBT[,RBT_NAFs:= RBT_P_NAFs+RBT_NP_NAFs]
  
# DEL DRVR + ASSOCIATE VIOLATIONS
  # SUM NUMBER OF DELETE DRVR
  pol_drvr_DEL <- pol_drvr[,.(ST_CD, PHYS_POL_KEY, DRVR_LIC_NBR, DRVR_BRTH_DT, DEL_DRVR_NEXT_TERM)]
  pol_drvr_DEL <- pol_drvr_DEL[DEL_DRVR_NEXT_TERM == 1,
                               .(DEL_DRVR_CNT = sum(DEL_DRVR_NEXT_TERM)),
                               by=.(ST_CD, PHYS_POL_KEY)]
  
  # SUM NUMBER OF VIOLATION BEING DELETED
  pol_viol_DEL_prepare <- pol_viol[DEL_DRVR_NEXT_TERM == 1, 
                                   .(DEL_NP_AAFs=sum(NP_AAF),
                                     DEL_P_AAFs=sum(P_AAF),
                                     DEL_MAJs=sum(MAJ),
                                     DEL_MINs=sum(MIN),
                                     DEL_P_NAFs=sum(P_NAF),
                                     DEL_NP_NAFs=sum(NP_NAF),
                                     DEL_DUIs=sum(DUI)),
                                   by=.(ST_CD, PHYS_POL_KEY)]
  
  pol_viol_DEL_prepare[,DEL_NAFs:= DEL_P_NAFs+DEL_NP_NAFs]
  
  # COMINE
  pol_viol_DEL <- merge(pol_drvr_DEL, pol_viol_DEL_prepare, by=c("ST_CD", "PHYS_POL_KEY"), all.x = TRUE)
  
  # REPLACE NA WITH 0
  for (i in names(pol_viol_DEL)) pol_viol_DEL[is.na(get(i)), (i):=0]

  # REPLACE PHYS_POL_KEY WITH NEXT TERM PHYS+POL_KEY
  sub <- pol[,.(ST_CD,POL_ID_NBR,PHYS_POL_KEY,RENW_CNT,term_cnt,term_pos)]
  sub <- sub[order(ST_CD, POL_ID_NBR, RENW_CNT)]
  first <- sub[,.I[1], by=.(ST_CD, PHYS_POL_KEY)]$V1
  sub <- sub[first]
  
  sub <- sub[order(ST_CD, POL_ID_NBR, RENW_CNT)]
  sub[,next_POL_KEY:=lead(PHYS_POL_KEY)]
  # FORCE LAST TREM PHYS_POL_KEYAS CURRENT TERM PHYS_POL_KEYAS
  sub[term_cnt==term_pos, next_POL_KEY:= PHYS_POL_KEY]
  
  # REPLACE
  sub <- sub[,.(ST_CD, PHYS_POL_KEY, next_POL_KEY)]
  pol_viol_DEL <- merge(pol_viol_DEL, sub, by=c("ST_CD", "PHYS_POL_KEY"), all.x = TRUE)
  pol_viol_DEL[,PHYS_POL_KEY:=NULL]
  pol_viol_DEL[,PHYS_POL_KEY:=next_POL_KEY][,next_POL_KEY:=NULL]
  
  rm(list=c("sub","pol_viol_DEL_prepare"))

##############
# AGGREGRATE #
##############
# GET DRVR CNT
pol_viol_cnt <- pol_drvr[,.(DRVR_CNT=.N), by=.(ST_CD, PHYS_POL_KEY, POL_ID_NBR, RENW_CNT)]

# JOIN RBF CNT
pol_viol_cnt <- merge(pol_viol_cnt, pol_viol_RBF, by=c("ST_CD", "PHYS_POL_KEY"), all.x = TRUE)

# JOIN RBT CNT
pol_viol_cnt <- merge(pol_viol_cnt, pol_viol_RBT, by=c("ST_CD", "PHYS_POL_KEY"), all.x = TRUE)

# JOIN DEL CNT
pol_viol_cnt <- merge(pol_viol_cnt, pol_viol_DEL, by=c("ST_CD", "PHYS_POL_KEY"), all.x = TRUE)
 
# REPLACE NA WITH 0
for (i in names(pol_viol_cnt)) pol_viol_cnt[is.na(get(i)), (i):=0]

# ORDER
pol_viol_cnt <- pol_viol_cnt[order(ST_CD, POL_ID_NBR, RENW_CNT)]

# EXPORT
fwrite(pol_viol_cnt,"D:/Sean/2020_Q1/Tier_Improvement/Output/pol_viol_cnt_DC_Tier.csv")

