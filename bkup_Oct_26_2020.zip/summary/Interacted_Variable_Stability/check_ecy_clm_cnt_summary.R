# SET ENVIRONMENT 
setwd("D:/Sean/Interacted_Variable_Stability")
library(here)
library(data.table)

  # CHANGE HERE ROOT DIRECTORY
  change_here <- function(new_path){
    new_root <- here:::.root_env
    new_root$f <- function(...) {file.path(new_path, ...)}
    assignInNamespace(".root_env", new_root, ns = "here")
    }
  
  change_here("D:/Sean/Interacted_Variable_Stability")
  
# LOAD DATA
meta <- fread(here("Data","check_interaction_meta.csv"))
  col_types <- sapply(unique(meta$types), function(x){
    meta[types==x, columns]
  })
  
base_data <- fread(here("Data", "check_interaction_data.csv"), colClasses = col_types)

# SUMMARY
summary <- as.data.table(
              base_data[,.(ECY=sum(BIPD_ECY), 
                        CLM_CNT = sum(CLM_CNT_INCR),
                        LOSS = sum(LOSS_CPD_DEV_TRND_INCR),
                        EP = sum(BIPD_EP)),
                        by=.(as.factor(LUSDOT_GRP),
                             as.factor(USDOT_V41_LVL),
                             as.factor(MKT))
                     ])

list <- as.data.table(summary$as.factor)
fwrite(list,here("Data","list.txt"))

# CHECK RESIDUAL
check <- names(base_data)[grep("ADJ_PP", names(base_data))]
weight <- names(base_data)[grep("ADJ_ECY", names(base_data))]

overall <- data.table()
for (i in seq_along(check)){
  residual <- base_data[,
                          .( check_res =
                          weighted.mean(get(check[i]),get(weight[i]))
                          ),
                        by=.(MKT,LUSDOT_GRP)
  
  ]
  names(residual)[3] <- paste0("step_",i)
  overall <- cbind(overall,residual)
}

## CHECK BY POTENTIAL INTERACTION LSUDOT, UW_ROW, CR_GRP_ME_ModOne
# SUMMARY
summary <- as.data.table(
  base_data[,.(ECY=sum(BIPD_ECY), 
               CLM_CNT = sum(CLM_CNT_INCR),
               LOSS = sum(LOSS_CPD_DEV_TRND_INCR),
               EP = sum(BIPD_EP)),
            by=.(as.factor(LUSDOT_GRP),
                 as.factor(UW_ROW),
                 as.factor(CR_GRP_ME_ModOne))
            ])


# CHECK RESIDUAL
check <- names(base_data)[grep("ADJ_PP", names(base_data))]
weight <- names(base_data)[grep("ADJ_ECY", names(base_data))]

overall <- data.table()
for (i in seq_along(check)){
  residual <- base_data[,
                        .( check_res =
                             weighted.mean(get(check[i]),get(weight[i]))
                        ),
                        by=.(LUSDOT_GRP, UW_ROW, CR_GRP_ME_ModOne)
                        
                        ]
  names(residual)[3] <- paste0("step_",i)
  overall <- cbind(overall,residual)
}

fwrite(overall,here("Output", "check_pp.csv"))

# CHECK ECY/CLM_CNT/LOSS DISTRIBUTION
dist <- dcast(base_data, CR_TIER_MTHD2_ModOne+UW_ROW ~ MKT, value.var="BIPD_ECY", fun=sum)
dist[,NS_pct:=NS/(MM+NS+PR+ST+UL)]

dist_1 <- dcast(base_data, CR_TIER_MTHD2_ModOne+UW_ROW ~ MKT, 
              value.var="CLM_CNT_INCR", fun=sum)

dist_2 <- dcast(base_data, CR_TIER_MTHD2_ModOne+UW_ROW ~ MKT, 
              value.var="LOSS_CPD_DEV_TRND_INCR", fun=sum)

fwrite(dist,here("ecy.txt"))
fwrite(dist_1,here("clm_cnt.txt"))
fwrite(dist_2,here("loss.txt"))

## CHECK BY POTENTIAL INTERACTION LSUDOT, uw_ROW + CR_GRP MIMIC MKT
# SUMMARY
summary <- as.data.table(
  base_data[,.(ECY=sum(BIPD_ECY), 
               CLM_CNT = sum(CLM_CNT_INCR),
               LOSS = sum(LOSS_CPD_DEV_TRND_INCR),
               EP = sum(BIPD_EP)),
            by=.(as.factor(LUSDOT_GRP),
                 as.factor(MKT_FROM_CR_UW))
            ])



