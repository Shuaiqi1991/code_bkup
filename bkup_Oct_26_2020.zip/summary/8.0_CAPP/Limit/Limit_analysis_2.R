# Set environment
library(data.table)
library(here)

change_here <- function(new_path){
  new_root <- here:::.root_env
  
  new_root$f <- function(...){file.path(new_path, ...)}
  
  assignInNamespace(".root_env", new_root, ns = "here")
}
change_here("D:/Sean/8.0_CAPP/LIMIT")

## Load & Clean Data
data <- fread(here("limit_fit_data.csv"))
data[,Ind:=round(Ind,2)] #In dataset, Ind was replaced with 78a SEL to fit this line
data[,Ind_reg:=Ind]
data[,group:=.GRP, by=.(BTG,Ind)]
data[,wtd_avg:=weighted.mean(Ind, ECY), by=.(BTG,group)]

btg_list <- unique(data$BTG)

## lele

# for (btg in btg_list) {
#   data_sub <- data_alpha[BTG==btg,]
#   group_list <- unique(data_sub$group)
#   }

data_sub <- data[BTG=="Extra_Heavy"]
group_list <- unique(data_sub$group)

propose_all <- data.table()
  # fit initial 0.01 slope line
  for (gp in group_list) {
    data_sub_gp <- data_sub[group==gp]
    propose <- as.data.table((lm(Ind~ offset(0.01*X), data=data_sub_gp, weight=ECY))$fitted.values)
    propose_all <- rbind(propose_all,propose)
    print(gp)
  }
  names(propose_all) <- "propose"
  propose_all[,propose:=round(propose,2)]
  data_sub <- cbind(data_sub,propose_all)
  propose_all <- data.table()
  
  #check overlap
  for (i in 1:length(group_list)){
    data_sub_gp <- data_sub[group %in% c(group_list[i],group_list[min(length(group_list),i+1)])]
    
    if (length(data_sub_gp$propose) > length(unique(data_sub_gp$propose))){
      # update group
      data_sub[group== group_list[i+1],group:=group_list[i]]
      group_list <<- unique(data_sub$group)
      
      # update Ind_reg
      data_sub[,Ind_reg:= round(weighted.mean(Ind, ECY),2), by=.(BTG,group)]

      # Drop orignal propose
      #data_sub[,propose:=NULL]
      
      # refit 0.01 slope line
      for (gp in group_list) {
        data_sub_gp <- data_sub[group==gp]
        propose <- as.data.table((lm(Ind_reg ~ offset(0.01*X), data=data_sub_gp, weight=ECY))$fitted.values)
        propose_all <- rbind(propose_all,propose)
        print(gp)
      }
      names(propose_all) <- "propose"
      propose_all[,propose:=round(propose,2)]
      data_sub <- cbind(data_sub,propose_all)
      propose_all <- data.table()
      
    }
  }
  
  fwrite(data_sub, here("result.csv"))
  
  data_sub[group==12, group:=11]
  data_sub[group==13, group:=11]
  data_sub[group==22, group:=21]
  data_sub[group==32, group:=31]
  data_sub[group==33, group:=31]
  
  #######
  
  data_sub <- data[BTG=="Heavy"]
  group_list <- unique(data_sub$group)
  
  propose_all <- data.table()
  # fit initial 0.01 slope line
  for (gp in group_list) {
    data_sub_gp <- data_sub[group==gp]
    propose <- as.data.table((lm(Ind~ offset(0.01*X), data=data_sub_gp, weight=ECY))$fitted.values)
    propose_all <- rbind(propose_all,propose)
    print(gp)
  }
  names(propose_all) <- "propose"
  propose_all[,propose:=round(propose,2)]
  data_sub <- cbind(data_sub,propose_all)
  propose_all <- data.table()
  
  
  i <- 1
  data_sub_gp <- data_sub[group %in% c(group_list[i],group_list[min(length(group_list),i+1)])]
  
  while (i <= length(group_list)){
    
    if (length(data_sub_gp$propose) > length(unique(data_sub_gp$propose))){
      # update group
      data_sub[group== group_list[i+1],group:=group_list[i]]
      group_list <<- unique(data_sub$group)
      
      # update Ind_reg
      data_sub[,Ind_reg:= round(weighted.mean(Ind, ECY),2), by=.(BTG,group)]
      
      # Drop orignal propose
      #data_sub[,propose:=NULL]
      
      # refit 0.01 slope line
      for (gp in group_list) {
        data_sub_gp <- data_sub[group==gp]
        propose <- as.data.table((lm(Ind_reg ~ offset(0.01*X), data=data_sub_gp, weight=ECY))$fitted.values)
        propose_all <- rbind(propose_all,propose)
        print(gp)
      }
      names(propose_all) <- "propose"
      propose_all[,propose:=round(propose,2)]
      data_sub <- cbind(data_sub,propose_all)
      propose_all <- data.table()
      
      # reset loop
      i <- 1
    } else {
      i <- i+1
      data_sub_gp <- data_sub[group %in% c(group_list[i],group_list[min(length(group_list),i+1)])]
    }
  }

#####
  i <- 1
  data_sub_gp <- data_sub[group %in% c(group_list[i],group_list[min(length(group_list),i+1)])]
  
  while (i <= length(group_list)){
    if (length(data_sub_gp$propose) > length(unique(data_sub_gp$propose))){
      data_sub[group== group_list[i+1],group:=group_list[i]]
      group_list <<- unique(data_sub$group)
      i <- 1
    }
  
   
     for (i in 1:length(group_list)){
      data_sub_gp <- data_sub[group %in% c(group_list[i],group_list[min(length(group_list),i+1)])]
      
      if (length(data_sub_gp$propose) > length(unique(data_sub_gp$propose))){
        # update group
        data_sub[group== group_list[i+1],group:=group_list[i]]
        group_list <<- unique(data_sub$group)


}

