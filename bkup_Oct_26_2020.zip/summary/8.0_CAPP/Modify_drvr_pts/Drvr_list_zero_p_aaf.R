# SET ENVIRONMENT
library(here)
library(readtext)
library(data.table)
library(odbc)
library(stringr)

  # CHANGE HERE ROOT DIRECTORY
  change_here <- function(new_path){
    new_root <- here:::.root_env
    new_root$f <- function(...) {file.path(new_path, ...)}
    assignInNamespace(".root_env", new_root, ns = "here")
  }
  change_here("D:/Sean/8.0_CAPP")


## CREATE DRVR_LIST DATA
# GET ARGUMENTS
start_date <- "2010-05-01"
end_date <- "2019-04-30"
uid <- "A131732"
pwd <- readtext("U:/Sean/pswd.txt", docid_field = NULL)[[2]]

# CONNECT TO CAW
caw_con <- dbConnect(odbc(), 'DB2P', uid=uid, pwd=pwd)

# VIOLATIONS QUERY
viol_qry <- 
  "
SELECT 
CAW.DRIVER_VIOL.ST_CD, 
CAW.DRIVER_VIOL.PHYS_POL_KEY, 
CAW.DRIVER_VIOL.PHYS_DRVR_KEY, 
CAW.DRIVER_VIOL.VIOL_CD, 
CAW.DRIVER_VIOL.DRVR_INCID_DT, 
CAW.DRIVER_VIOL.DRVR_PNT_SRCE_CD
FROM 
CAW.DRIVER_VIOL
WHERE 
CAW.DRIVER_VIOL.POL_EXPR_YR IN (pol_expr_yrs)
;
"

# DRIVER DATES QUERY
dts_qry <- 
  "
SELECT 
CAW.DRVR_DATES.ST_CD, 
CAW.DRVR_DATES.PHYS_POL_KEY, 
CAW.DRVR_DATES.PHYS_DRVR_KEY,
CAW.DRVR_DATES.DRVR_POS_CNT, 
CAW.DRVR_DATES.DRVR_STRT_DT 
FROM 
CAW.DRVR_DATES
WHERE
CAW.DRVR_DATES.DRVR_STRT_DT BETWEEN {d 'startdate'} AND {d 'enddate'}
;
"

# POLICY DATES QUERY
pol_qry <- 
  "
SELECT 
CAW.POLICY.ST_CD, 
CAW.POLICY.PHYS_POL_KEY,
CAW.POL_DATES.POL_EFF_DT 
FROM 
CAW.POL_DATES, 
CAW.POLICY 
WHERE 
CAW.POL_DATES.POL_ID_CHAR = CAW.POLICY.POL_ID_CHAR 
AND CAW.POL_DATES.RENW_SFX_NBR = CAW.POLICY.RENW_SFX_NBR 
AND CAW.POL_DATES.POL_EXPR_YR = CAW.POLICY.POL_EXPR_YR 
AND CAW.POL_DATES.POL_EFF_DT BETWEEN {d 'startdate'} AND {d 'enddate'}
;
"

# INSERT START AND END DATE INTO QUERY
min_pol_expr_yr <- lubridate::year(as.Date(start_date))
pol_expr_yrs <- seq(min_pol_expr_yr, lubridate::year(lubridate::today())+1)
pol_expr_yrs <- substr(pol_expr_yrs, 3, 4)
pol_expr_yrs <- paste(paste0("'", pol_expr_yrs, "'"), collapse=",")
viol_qry <- str_replace_all(viol_qry, 'pol_expr_yrs', pol_expr_yrs)
dts_qry <- str_replace_all(dts_qry, 'startdate', start_date)
dts_qry <- str_replace_all(dts_qry, 'enddate', end_date)
pol_qry <- str_replace_all(pol_qry, 'startdate', start_date)
pol_qry <- str_replace_all(pol_qry, 'enddate', end_date)

# GET VIOLATION DATA
viol_data <- as.data.table(dbGetQuery(caw_con, viol_qry))

# GET DRIVER DATES DATA
dts_data <- as.data.table(dbGetQuery(caw_con, dts_qry))

# GET POLICY DATES
pol_data <- as.data.table(dbGetQuery(caw_con, pol_qry))

# GET FIRST DRIVER DATE
dts_data <- dts_data[order(ST_CD, PHYS_POL_KEY, DRVR_POS_CNT, DRVR_STRT_DT)]
first_inds <- dts_data[, .I[1], by=.(ST_CD, PHYS_POL_KEY, DRVR_POS_CNT)]$V1
dts_data <- dts_data[first_inds]

# JOIN VIOLATION AND DATES DATA
viol_data <- dts_data[viol_data, on=.(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY)]

# JOIN DATES AND VIOLATION DATA
viol_data <- merge(pol_data, viol_data, by=c('ST_CD', 'PHYS_POL_KEY'))

# NA DRIVER START DATES ARE ASSIGNED TO POLICY EFFECTIVE DATE
viol_data[is.na(DRVR_STRT_DT), DRVR_STRT_DT:=POL_EFF_DT]

# FDL AND UDR HAVE VIOLATION DATE SET TO 11/11/1911
viol_data[DRVR_INCID_DT<=as.Date('1911-11-11'), DRVR_INCID_DT:=DRVR_STRT_DT]

# DELETE OLDER THAN 36 MONTH VIOLATION DATE
viol_data <- viol_data[!((DRVR_INCID_DT > as.Date('1911-11-11')) & (DRVR_STRT_DT - DRVR_INCID_DT + 1 >= 1095))]

# DELETE VIOLATION DATE > START DATE
viol_data <- viol_data[!(DRVR_INCID_DT > DRVR_STRT_DT)]

# LOOKUP VIOLATION CLASS
lookup_vio_cls <- fread(here('Data', 'lookup_vio_cls.csv'))
viol_data[, VIOL_CD:=trimws(VIOL_CD)]
viol_data <- lookup_vio_cls[viol_data, on=.(VIOL_CD)]
# IN IOWA SP1 CONSIDERED AS SPD IN MIN_CL
viol_data[ST_CD=='14' & VIOL_CD=='SP1', VIOL_CLS:='C']

# ASSIGN POINTS FOR FIRST VIOLATION
viol_data <- viol_data[order(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY, VIOL_CLS, DRVR_INCID_DT)]
first_viol_pts <- fread(here('Data', 'lookup_first_pts.csv'))
viol_data <- first_viol_pts[viol_data, on=.(VIOL_CLS)]

# ASSIGN POINTS FOR ADDITIONAL VIOLATIONS
addtl_viol_pts <- fread(here('Data', 'lookup_addtl_pts.csv'))
setnames(addtl_viol_pts, 'VIOL_PT', 'ADDTL_PT')
viol_data <- addtl_viol_pts[viol_data, on=.(VIOL_CLS)]
first_inds <- viol_data[, .I[1], by=.(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY, VIOL_CLS)]$V1
viol_data[!first_inds, VIOL_PT:=ADDTL_PT]

# REMOVE SAME DAY VIOLATIONS AND KEEP HIGHEST RANKED VIOLATION IN A DAY
viol_data <- viol_data[order(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY, DRVR_INCID_DT, -VIOL_PT, -VIOL_CLS)]
first_inds <- viol_data[, .I[1], by=.(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY, DRVR_INCID_DT)]$V1
viol_data <- viol_data[first_inds]

# REASSIGN POINTS AFTER SAME DAY FILTER
viol_data[, VIOL_PT:=NULL]
viol_data <- viol_data[order(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY, VIOL_CLS, DRVR_INCID_DT)]
viol_data <- first_viol_pts[viol_data, on=.(VIOL_CLS)]
  # CHANGE P SOURCE AAF TO 0 POINT
  viol_data[,DRVR_PNT_SRCE_CD:=trimws(DRVR_PNT_SRCE_CD)]
  viol_data[VIOL_CD=="AAF" & DRVR_PNT_SRCE_CD=="P", VIOL_PT:=0]
viol_data <- addtl_viol_pts[viol_data, on=.(VIOL_CLS)]
  # CHANGE P SOURCE AAF TO 0 POINT
  viol_data[VIOL_CD=="AAF" & DRVR_PNT_SRCE_CD=="P", ADDTL_PT:=0]
first_inds <- viol_data[, .I[1], by=.(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY, VIOL_CLS)]$V1
viol_data[!first_inds, VIOL_PT:=ADDTL_PT]

# SUMMARIZE POINT SUM TO DRIVER LEVEL
viol_data <- viol_data[, .(DRVR_PTS=sum(VIOL_PT)), by=.(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY)]

# CAW QUERY
drv_qry <- 
  "
SELECT 
CAW.POLICY.ST_CD, 
CAW.POLICY.PHYS_POL_KEY, 
CAW.DRVR_PUB_VIEW.PHYS_DRVR_KEY, 
CAW.DRVR_PUB_VIEW.DRVR_POS_CNT,
CAW.DRVR_DATES.DRVR_AT_INCP_IND, 
CAW.POLICY.POWER_UNIT_CNT,
CAW.DRVR_PUB_VIEW.DRVR_AGE, 
CAW.DRVR_PUB_VIEW.EXCL_IND, 
CAW.DRVR_PUB_VIEW.DRVR_MOCK_IND
FROM 
CAW.POL_DATES, 
CAW.DRVR_DATES, 
CAW.DRVR_PUB_VIEW, 
CAW.POLICY 
WHERE 
CAW.POL_DATES.POL_EFF_DT BETWEEN {d 'startdate'} and {d 'enddate'}
AND CAW.POLICY.POL_ID_CHAR = CAW.DRVR_PUB_VIEW.POL_ID_CHAR 
AND CAW.POLICY.RENW_SFX_NBR = CAW.DRVR_PUB_VIEW.RENW_SFX_NBR 
AND CAW.POLICY.POL_EXPR_YR = CAW.DRVR_PUB_VIEW.POL_EXPR_YR 
AND CAW.DRVR_PUB_VIEW.ST_CD = CAW.DRVR_DATES.ST_CD 
AND CAW.DRVR_PUB_VIEW.POL_ID_CHAR = CAW.DRVR_DATES.POL_ID_CHAR 
AND CAW.DRVR_PUB_VIEW.RENW_SFX_NBR = CAW.DRVR_DATES.RENW_SFX_NBR 
AND CAW.DRVR_PUB_VIEW.POL_EXPR_YR = CAW.DRVR_DATES.POL_EXPR_YR 
AND CAW.DRVR_PUB_VIEW.DRVR_POS_CNT = CAW.DRVR_DATES.DRVR_POS_CNT 
AND CAW.DRVR_PUB_VIEW.DRVR_VRSN_NBR = CAW.DRVR_DATES.DRVR_VRSN_NBR 
AND CAW.POLICY.POL_ID_CHAR = CAW.POL_DATES.POL_ID_CHAR 
AND CAW.POLICY.RENW_SFX_NBR = CAW.POL_DATES.RENW_SFX_NBR 
AND CAW.POLICY.POL_EXPR_YR = CAW.POL_DATES.POL_EXPR_YR 
GROUP BY
CAW.POLICY.ST_CD, 
CAW.POLICY.PHYS_POL_KEY, 
CAW.DRVR_PUB_VIEW.PHYS_DRVR_KEY, 
CAW.DRVR_PUB_VIEW.DRVR_POS_CNT,
CAW.DRVR_DATES.DRVR_AT_INCP_IND, 
CAW.POLICY.POWER_UNIT_CNT,
CAW.DRVR_PUB_VIEW.DRVR_AGE, 
CAW.DRVR_PUB_VIEW.EXCL_IND, 
CAW.DRVR_PUB_VIEW.DRVR_MOCK_IND
;
"

# INSERT START AND END DATE INTO QUERY
drv_qry <- str_replace_all(drv_qry, 'startdate', start_date)
drv_qry <- str_replace_all(drv_qry, 'enddate', end_date)

# GET DRIVER DATA
drv_data <- as.data.table(dbGetQuery(caw_con, drv_qry))

# JOIN POINTS TO DRIVER DATA
drv_data <- viol_data[drv_data, on=.(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY)]
drv_data[is.na(DRVR_PTS), DRVR_PTS:=0]

# FILTER OUT MOCK DRIVERS, EXCLUDED DRIVERS, AND POST-INCEPTION DRIVERS
drv_data <- drv_data[DRVR_AT_INCP_IND=='Y']
drv_data <- drv_data[EXCL_IND!='Y']
drv_data <- drv_data[DRVR_MOCK_IND!='Y']

# GET FIRST RECORD FOR EACH DRIVER
inds <- drv_data[, .I[1], by=.(ST_CD, PHYS_POL_KEY, DRVR_POS_CNT)]$V1
drv_data <- drv_data[inds, .(ST_CD, PHYS_POL_KEY, POWER_UNIT_CNT, DRVR_POS_CNT, DRVR_AGE, DRVR_PTS)]

# REMOVE pwd VALUE
rm(ls=pwd)

# EXPORT drv_data (euqal to DRVR_LIST in 79 CAPP FILE)
fwrite(drv_data,here('Data','DRVR_LIST_0_P_AAF.csv'))
