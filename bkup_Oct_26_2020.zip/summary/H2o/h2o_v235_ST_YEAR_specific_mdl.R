#Set working environment
setwd('D:/Sean/H2O')

library("here")
library("data.table")
library("XLConnect")
library("dplyr")
library('ggplot2')
library('reshape2')
library('h2o')

h2o.init()

################
# IMPORT DATA  #
################
# dt1 <- bipd_79b_CA_18
# dt2 <- bipd_79b_FL_18
# dt3 <- bipd_79b_TX_18
# dt4 <- bipd_79b_CWx_18

data_path <<- 'Data/bipd_79b_ca_18'

#Import data
meta_1 <- fread(here(data_path,"meta.csv"))
meta_1[, h2o_types:='unknown']
meta_1[types=='character', h2o_types:='string']
meta_1[types=='integer', h2o_types:='numeric']
meta_1[types=='numeric', h2o_types:='numeric']
meta_1[types=='Date', h2o_types:='time']
meta_1[types=='factor', h2o_types:='enum']

dt_1 <- h2o.importFile('D:/Sean/H2O/Data/bipd_79b_ca_18/data.csv',
                       destination_frame="", col.types=meta_1$h2o_types)

dt_2 <- h2o.importFile('D:/Sean/H2O/Data/bipd_79b_fl_18/data.csv',
                       destination_frame="", col.types=meta_1$h2o_types)

dt_3 <- h2o.importFile('D:/Sean/H2O/Data/bipd_79b_tx_18/data.csv',
                       destination_frame="", col.types=meta_1$h2o_types)

dt_4 <- h2o.importFile('D:/Sean/H2O/Data/bipd_79b_cwx_18/data.csv',
                       destination_frame="", col.types=meta_1$h2o_types)

################
# RLEVEL       #
################

dt_4["ST_GRP"] <- h2o.relevel(dt_4["ST_GRP"],"9")

################
# SETUP POWER  #
################

p_1 <- 1.653
p_2 <- 1.655
p_3 <- 1.658
p_4 <- 1.655

################################
# DEFINE predictor & response  #
################################

independent <<- c("UNLD_PCT",
                  "AGE_GRP01",
                  "AGE_GRP02",
                  "AGE_GRP03",
                  "AGE_GRP04",
                  "AGE_GRP05",
                  "AGE_GRP06",
                  "AGE_GRP08",
                  "AGE_GRP09",
                  "AGE_GRP10",
                  "AGE_GRP11",
                  "AGE_GRP12",
                  "AGE_GRP13",
                  "AGE_GRP14",
                  "PTS_GRP01",
                  "PTS_GRP02",
                  "PTS_GRP03",
                  "PTS_GRP04",
                  "PTS_GRP05",
                  "PTS_GRP06",
                  "PTS_GRP07",
                  "PTS_GRP08",
                  "PTS_GRP09",
                  "PTS_GRP10",
                  "PTS_GRP11",
                  "BTG_ME",
                  "BCG_ME",
                  "USE_GRP",
                  "CR_GRP_ME",
                  "UW_ROW",
                  "BIPD_SYM_GRP", 
                  "LIMIT_GRP",
                  "RADIUS_GRP",
                  "VAGE_RAW",
                  "VAGE_RAW2",
                  "VEH_PERS_USE_IND",
                  "PKG_DISC_NO_RT_NEW2",
                  "PIF_DISC",
                  "CDL_NORT_U_PCT_NEW",
                  "CDL_NORT_Y_PCT_NEW",
                  "USDOT_V41_GRPS",
                  "ST_GRP",
                  "TERR_MDL"
) 
dependent <<- 'PP'
weight_var <<- 'BIPD_ECY'

#######################
# LOOP OVER DATASETS  #
#######################

for (i in 1:3){
  dt <- get(paste0("dt_",i))
  p <- get(paste0("p_",i))
  dt_name <- paste0("dt_",i)
  
  # RELEVEL
  dt["BTG_ME"] <- h2o.relevel(dt["BTG_ME"], "999")
  dt["BCG_ME"] <- h2o.relevel(dt["BCG_ME"], "999")
  dt["USE_GRP"] <- h2o.relevel(dt["USE_GRP"], "999") 
  dt["CR_GRP_ME"] <- h2o.relevel(dt["CR_GRP_ME"], "C0")
  dt["UW_ROW"] <- h2o.relevel(dt["UW_ROW"], "1")
  dt["BIPD_SYM_GRP"] <- h2o.relevel(dt["BIPD_SYM_GRP"], "16")
  dt["LIMIT_GRP"] <- h2o.relevel(dt["LIMIT_GRP"], "999")
  dt["RADIUS_GRP"] <- h2o.relevel(dt["RADIUS_GRP"], "050")
  dt["VEH_PERS_USE_IND"] <- h2o.relevel(dt["VEH_PERS_USE_IND"], "N")
  dt["PKG_DISC_NO_RT_NEW2"] <- h2o.relevel(dt["PKG_DISC_NO_RT_NEW2"], "N")
  dt["PIF_DISC"] <- h2o.relevel(dt["PIF_DISC"], "N")
  dt["USDOT_V41_GRPS"] <- h2o.relevel(dt["USDOT_V41_GRPS"], "Z98")
  
  # MODEL 
  mdl <- h2o.glm(x = independent,
                 y = dependent,
                 #interaction_pairs = interaction_pairs,
                 training_frame = dt,
                 model_id = "st_year_specific",
                 seed = 44124,
                 family = "tweedie",
                 weights_column = weight_var, 
                 tweedie_variance_power = p,
                 tweedie_link_power = 0,
                 solver = 'IRLSM',
                 lambda = 0,
                 standardize = FALSE,
                 compute_p_values = TRUE,
                 beta_epsilon = 1e-9,
                 remove_collinear_columns = TRUE)
  
  # Get Coefficient
  coef_tab <- mdl@model$coefficients_table
  phi <- as.data.table(mdl@model$dispersion)
  colnames(phi) <- "coefficients"
  phi <- data.table(names = "dispersion", phi)
  coef <- rbind(coef_tab, phi, fill = TRUE)
  fwrite(coef,file=paste0("D:/Sean/H2O/Output/ST_YEAR_specific/h2o_v235/",dt_name,".csv"))
}

##########################################
# CA & FL MODEL corresponding to statmod #
##########################################

independent <<- c("UNLD_PCT",
                  "AGE_GRP01",
                  "AGE_GRP02",
                  "AGE_GRP03",
                  "AGE_GRP04",
                  "AGE_GRP05",
                  "AGE_GRP06",
                  "AGE_GRP08",
                  "AGE_GRP09",
                  "AGE_GRP10",
                  "AGE_GRP11",
                  "AGE_GRP12",
                  "AGE_GRP13",
                  "AGE_GRP14",
                  "PTS_GRP01",
                  "PTS_GRP02",
                  "PTS_GRP03",
                  "PTS_GRP04",
                  "PTS_GRP05",
                  "PTS_GRP06",
                  "PTS_GRP07",
                  "PTS_GRP08",
                  "PTS_GRP09",
                  "PTS_GRP10",
                  "PTS_GRP11",
                  # "BTG_ME",
                  # "BCG_ME",
                  # "USE_GRP",
                  "CR_GRP_ME",
                  "UW_ROW",
                  "BIPD_SYM_GRP", 
                  "LIMIT_GRP",
                  "RADIUS_GRP",
                  "VAGE_RAW",
                  # "VAGE_RAW2",
                  "VEH_PERS_USE_IND",
                  "PKG_DISC_NO_RT_NEW2",
                  "PIF_DISC",
                  "CDL_NORT_U_PCT_NEW",
                  "CDL_NORT_Y_PCT_NEW",
                  "USDOT_V41_GRPS",
                  # "ST_GRP",
                  "TERR_MDL"
) 
dependent <<- 'PP'
weight_var <<- 'BIPD_ECY'

for (i in 1:2){
  dt <- get(paste0("dt_",i))
  p <- get(paste0("p_",i))
  dt_name <- paste0("dt_",i)
  
  # RELEVEL
  dt["BTG_ME"] <- h2o.relevel(dt["BTG_ME"], "999")
  dt["BCG_ME"] <- h2o.relevel(dt["BCG_ME"], "999")
  dt["USE_GRP"] <- h2o.relevel(dt["USE_GRP"], "999") 
  dt["CR_GRP_ME"] <- h2o.relevel(dt["CR_GRP_ME"], "C0")
  dt["UW_ROW"] <- h2o.relevel(dt["UW_ROW"], "1")
  dt["BIPD_SYM_GRP"] <- h2o.relevel(dt["BIPD_SYM_GRP"], "16")
  dt["LIMIT_GRP"] <- h2o.relevel(dt["LIMIT_GRP"], "999")
  dt["RADIUS_GRP"] <- h2o.relevel(dt["RADIUS_GRP"], "050")
  dt["VEH_PERS_USE_IND"] <- h2o.relevel(dt["VEH_PERS_USE_IND"], "N")
  dt["PKG_DISC_NO_RT_NEW2"] <- h2o.relevel(dt["PKG_DISC_NO_RT_NEW2"], "N")
  dt["PIF_DISC"] <- h2o.relevel(dt["PIF_DISC"], "N")
  dt["USDOT_V41_GRPS"] <- h2o.relevel(dt["USDOT_V41_GRPS"], "Z98")
  
  # MODEL 
  mdl <- h2o.glm(x = independent,
                 y = dependent,
                 #interaction_pairs = interaction_pairs,
                 training_frame = dt,
                 model_id = "st_year_specific",
                 seed = 44124,
                 family = "tweedie",
                 weights_column = weight_var, 
                 tweedie_variance_power = p,
                 tweedie_link_power = 0,
                 solver = 'IRLSM',
                 lambda = 0,
                 standardize = FALSE,
                 compute_p_values = TRUE,
                 beta_epsilon = 1e-9,
                 remove_collinear_columns = TRUE)
  
  # Get Coefficient
  coef_tab <- mdl@model$coefficients_table
  phi <- as.data.table(mdl@model$dispersion)
  colnames(phi) <- "coefficients"
  phi <- data.table(names = "dispersion", phi)
  coef <- rbind(coef_tab, phi, fill = TRUE)
  fwrite(coef,file=paste0("D:/Sean/H2O/Output/ST_YEAR_specific/h2o_v235/",dt_name,".csv"))
}

#########################################
# TX MODEL corresponding to statmod     #
#########################################

independent <<- c("UNLD_PCT",
                  # "AGE_GRP01",
                  # "AGE_GRP02",
                  # "AGE_GRP03",
                  # "AGE_GRP04",
                  # "AGE_GRP05",
                  # "AGE_GRP06",
                  # "AGE_GRP08",
                  # "AGE_GRP09",
                  # "AGE_GRP10",
                  # "AGE_GRP11",
                  # "AGE_GRP12",
                  # "AGE_GRP13",
                  # "AGE_GRP14",
                  "PTS_GRP01",
                  "PTS_GRP02",
                  "PTS_GRP03",
                  "PTS_GRP04",
                  "PTS_GRP05",
                  "PTS_GRP06",
                  "PTS_GRP07",
                  "PTS_GRP08",
                  "PTS_GRP09",
                  "PTS_GRP10",
                  "PTS_GRP11",
                  # "BTG_ME",
                  # "BCG_ME",
                  # "USE_GRP",
                  "CR_GRP_ME",
                  "UW_ROW",
                  "BIPD_SYM_GRP", 
                  "LIMIT_GRP",
                  "RADIUS_GRP",
                  "VAGE_RAW",
                  # "VAGE_RAW2",
                  "VEH_PERS_USE_IND",
                  "PKG_DISC_NO_RT_NEW2",
                  "PIF_DISC",
                  "CDL_NORT_U_PCT_NEW",
                  "CDL_NORT_Y_PCT_NEW",
                  "USDOT_V41_GRPS",
                  # "ST_GRP",
                  "TERR_MDL"
) 
dependent <<- 'PP'
weight_var <<- 'BIPD_ECY'

  dt <- get(paste0("dt_",3))
  p <- get(paste0("p_",3))
  dt_name <- paste0("dt_",3)
  
  # RELEVEL
  dt["BTG_ME"] <- h2o.relevel(dt["BTG_ME"], "999")
  dt["BCG_ME"] <- h2o.relevel(dt["BCG_ME"], "999")
  dt["USE_GRP"] <- h2o.relevel(dt["USE_GRP"], "999") 
  dt["CR_GRP_ME"] <- h2o.relevel(dt["CR_GRP_ME"], "C0")
  dt["UW_ROW"] <- h2o.relevel(dt["UW_ROW"], "1")
  dt["BIPD_SYM_GRP"] <- h2o.relevel(dt["BIPD_SYM_GRP"], "16")
  dt["LIMIT_GRP"] <- h2o.relevel(dt["LIMIT_GRP"], "999")
  dt["RADIUS_GRP"] <- h2o.relevel(dt["RADIUS_GRP"], "050")
  dt["VEH_PERS_USE_IND"] <- h2o.relevel(dt["VEH_PERS_USE_IND"], "N")
  dt["PKG_DISC_NO_RT_NEW2"] <- h2o.relevel(dt["PKG_DISC_NO_RT_NEW2"], "N")
  dt["PIF_DISC"] <- h2o.relevel(dt["PIF_DISC"], "N")
  dt["USDOT_V41_GRPS"] <- h2o.relevel(dt["USDOT_V41_GRPS"], "Z98")
  
  # MODEL 
  mdl <- h2o.glm(x = independent,
                 y = dependent,
                 #interaction_pairs = interaction_pairs,
                 training_frame = dt,
                 model_id = "st_year_specific",
                 seed = 44124,
                 family = "tweedie",
                 weights_column = weight_var, 
                 tweedie_variance_power = p,
                 tweedie_link_power = 0,
                 solver = 'IRLSM',
                 lambda = 0,
                 standardize = FALSE,
                 compute_p_values = TRUE,
                 beta_epsilon = 1e-9,
                 remove_collinear_columns = TRUE)
  
  # Get Coefficient
  coef_tab <- mdl@model$coefficients_table
  phi <- as.data.table(mdl@model$dispersion)
  colnames(phi) <- "coefficients"
  phi <- data.table(names = "dispersion", phi)
  coef <- rbind(coef_tab, phi, fill = TRUE)
  fwrite(coef,file=paste0("D:/Sean/H2O/Output/ST_YEAR_specific/h2o_v235/",dt_name,".csv"))
  
  ##########################################
  # CWX MODEL corresponding to statmod #
  ##########################################
  
  independent <<- c("UNLD_PCT",
                    "AGE_GRP01",
                    "AGE_GRP02",
                    "AGE_GRP03",
                    "AGE_GRP04",
                    "AGE_GRP05",
                    "AGE_GRP06",
                    "AGE_GRP08",
                    "AGE_GRP09",
                    "AGE_GRP10",
                    "AGE_GRP11",
                    "AGE_GRP12",
                    "AGE_GRP13",
                    "AGE_GRP14",
                    "PTS_GRP01",
                    "PTS_GRP02",
                    "PTS_GRP03",
                    "PTS_GRP04",
                    "PTS_GRP05",
                    "PTS_GRP06",
                    "PTS_GRP07",
                    "PTS_GRP08",
                    "PTS_GRP09",
                    "PTS_GRP10",
                    "PTS_GRP11",
                    # "BTG_ME",
                    # "BCG_ME",
                    # "USE_GRP",
                    "CR_GRP_ME",
                    "UW_ROW",
                    "BIPD_SYM_GRP", 
                    "LIMIT_GRP",
                    "RADIUS_GRP",
                    "VAGE_RAW",
                    # "VAGE_RAW2",
                    "VEH_PERS_USE_IND",
                    "PKG_DISC_NO_RT_NEW2",
                    "PIF_DISC",
                    "CDL_NORT_U_PCT_NEW",
                    "CDL_NORT_Y_PCT_NEW",
                    "USDOT_V41_GRPS",
                    "ST_GRP",
                    "TERR_MDL"
  ) 
  dependent <<- 'PP'
  weight_var <<- 'BIPD_ECY'
  
    dt <- get(paste0("dt_",4))
    p <- get(paste0("p_",4))
    dt_name <- paste0("dt_",4)
    
    # RELEVEL
    dt["BTG_ME"] <- h2o.relevel(dt["BTG_ME"], "999")
    dt["BCG_ME"] <- h2o.relevel(dt["BCG_ME"], "999")
    dt["USE_GRP"] <- h2o.relevel(dt["USE_GRP"], "999") 
    dt["CR_GRP_ME"] <- h2o.relevel(dt["CR_GRP_ME"], "C0")
    dt["UW_ROW"] <- h2o.relevel(dt["UW_ROW"], "1")
    dt["BIPD_SYM_GRP"] <- h2o.relevel(dt["BIPD_SYM_GRP"], "16")
    dt["LIMIT_GRP"] <- h2o.relevel(dt["LIMIT_GRP"], "999")
    dt["RADIUS_GRP"] <- h2o.relevel(dt["RADIUS_GRP"], "050")
    dt["VEH_PERS_USE_IND"] <- h2o.relevel(dt["VEH_PERS_USE_IND"], "N")
    dt["PKG_DISC_NO_RT_NEW2"] <- h2o.relevel(dt["PKG_DISC_NO_RT_NEW2"], "N")
    dt["PIF_DISC"] <- h2o.relevel(dt["PIF_DISC"], "N")
    dt["USDOT_V41_GRPS"] <- h2o.relevel(dt["USDOT_V41_GRPS"], "Z98")
    
    # MODEL 
    mdl <- h2o.glm(x = independent,
                   y = dependent,
                   #interaction_pairs = interaction_pairs,
                   training_frame = dt,
                   model_id = "st_year_specific",
                   seed = 44124,
                   family = "tweedie",
                   weights_column = weight_var, 
                   tweedie_variance_power = p,
                   tweedie_link_power = 0,
                   solver = 'IRLSM',
                   lambda = 0,
                   standardize = FALSE,
                   compute_p_values = TRUE,
                   beta_epsilon = 1e-9,
                   remove_collinear_columns = TRUE)
    
    # Get Coefficient
    coef_tab <- mdl@model$coefficients_table
    phi <- as.data.table(mdl@model$dispersion)
    colnames(phi) <- "coefficients"
    phi <- data.table(names = "dispersion", phi)
    coef <- rbind(coef_tab, phi, fill = TRUE)
    fwrite(coef,file=paste0("D:/Sean/H2O/Output/ST_YEAR_specific/h2o_v235/",dt_name,".csv"))
