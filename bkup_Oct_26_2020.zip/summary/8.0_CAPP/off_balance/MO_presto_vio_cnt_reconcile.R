# SET ENVIRONMENT
library(data.table)
library(odbc)
library(stringr)

# DEFINE ARGUMENT 
start_date <- "2017-01-01"
end_date <- "2019-12-31"
uid <- "x011870"
pwd <- readLines('U:/x011870/pswd.txt', warn = FALSE)
var_lib_path <- "D:/Sean/8.0_CAPP/Off_Balance/BLOCK_1_2_on_2019/Data/XLS_FILE"
MN_PIF_day <- "2019-06-28"
B1_PIF_day <- "2019-12-31"

###################################
# GET VIOLATION CNT AT DRVR LEVEL #
###################################
# CONNECT TO CAW
caw_con <- dbConnect(odbc(), 'DB2P', uid=uid, pwd=pwd)

# VIOLATIONS QUERY
viol_qry <- 
  "
SELECT 
CAW.DRIVER_VIOL.ST_CD, 
CAW.DRIVER_VIOL.PHYS_POL_KEY, 
CAW.DRIVER_VIOL.PHYS_DRVR_KEY, 
CAW.DRIVER_VIOL.VIOL_CD, 
CAW.DRIVER_VIOL.DRVR_INCID_DT, 
CAW.DRIVER_VIOL.DRVR_PNT_SRCE_CD
FROM 
CAW.DRIVER_VIOL
WHERE 
CAW.DRIVER_VIOL.POL_EXPR_YR IN (pol_expr_yrs)
;
"

# DRIVER LICIENCE NBR QUERY
dr_lic_qry <- 
  "
SELECT 
CAW.DRVR_SEC_VIEW.ST_CD,
CAW.DRVR_SEC_VIEW.PHYS_POL_KEY,
CAW.DRVR_SEC_VIEW.PHYS_DRVR_KEY,
CAW.DRVR_SEC_VIEW.DRVR_LIC_NBR 
FROM
CAW.DRVR_SEC_VIEW 
WHERE 
CAW.DRVR_SEC_VIEW.POL_EXPR_YR IN (pol_expr_yrs)
;
"

# POLICY DATES QUERY
pol_qry <- 
  "
SELECT 
CAW.POLICY.ST_CD, 
CAW.POLICY.PHYS_POL_KEY,
CAW.POLICY.POL_ID_NBR,
CAW.POLICY.RENW_SFX_NBR,
CAW.POLICY.RENW_CNT,
CAW.POLICY.POL_MOCK_IND,
CAW.POL_DATES.POL_EFF_DT,
CAW.POL_DATES.POL_STOP_DT
FROM 
CAW.POL_DATES, 
CAW.POLICY 
WHERE 
CAW.POL_DATES.POL_ID_CHAR = CAW.POLICY.POL_ID_CHAR 
AND CAW.POL_DATES.RENW_SFX_NBR = CAW.POLICY.RENW_SFX_NBR 
AND CAW.POL_DATES.POL_EXPR_YR = CAW.POLICY.POL_EXPR_YR 
AND CAW.POL_DATES.POL_EFF_DT BETWEEN {d 'startdate'} AND {d 'enddate'}
;
"

# INSERT START AND END DATE INTO QUERY
min_pol_expr_yr <- lubridate::year(as.Date(start_date))
pol_expr_yrs <- seq(min_pol_expr_yr, lubridate::year(lubridate::today())+1)
pol_expr_yrs <- substr(pol_expr_yrs, 3, 4)
pol_expr_yrs <- paste(paste0("'", pol_expr_yrs, "'"), collapse=",")
viol_qry <- str_replace_all(viol_qry, 'pol_expr_yrs', pol_expr_yrs)
dr_lic_qry <- str_replace_all(dr_lic_qry, 'pol_expr_yrs', pol_expr_yrs)
pol_qry <- str_replace_all(pol_qry, 'startdate', start_date)
pol_qry <- str_replace_all(pol_qry, 'enddate', end_date)

# GET VIOLATION DATA
viol_data <- as.data.table(dbGetQuery(caw_con, viol_qry))

# GET DRIVER DATES DATA
dr_lic_data <- as.data.table(dbGetQuery(caw_con, dr_lic_qry))

# GET POLICY DATES
pol_data <- as.data.table(dbGetQuery(caw_con, pol_qry))

# JOIN VIOLATION AND LICIENCE NBR
viol_data <- dr_lic_data[viol_data, on=.(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY)]

# JOIN DATES AND VIOLATION DATA
viol_data <- merge(pol_data, viol_data, by=c('ST_CD', 'PHYS_POL_KEY'))

# FDL AND UDR HAVE VIOLATION DATE SET TO 11/11/1911
viol_data[DRVR_INCID_DT<=as.Date('1911-11-11'), DRVR_INCID_DT:=POL_EFF_DT]

# GET DRVR POS CNT
viol_data[,DRVR_POS_CNT:=substr(PHYS_DRVR_KEY,14,16)]

# LOOKUP VIOLATION CLASS
lookup_vio_cls <- fread(paste0(var_lib_path,'/lookup_vio_cls.csv'))
viol_data[, VIOL_CD:=trimws(VIOL_CD)]
viol_data <- lookup_vio_cls[viol_data, on=.(VIOL_CD)]
# IN IOWA SP1 CONSIDERED AS SPD IN MIN_CL
viol_data[ST_CD=='14' & VIOL_CD=='SP1', VIOL_CLS:='C']

# ASSIGN POINTS FOR FIRST VIOLATION
viol_data <- viol_data[order(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY, VIOL_CLS, DRVR_INCID_DT)]
first_viol_pts <- fread(paste0(var_lib_path,'/lookup_first_pts.csv'))
viol_data <- first_viol_pts[viol_data, on=.(VIOL_CLS)]

# ASSIGN POINTS FOR ADDITIONAL VIOLATIONS
addtl_viol_pts <- fread(paste0(var_lib_path,'/lookup_addtl_pts.csv'))
setnames(addtl_viol_pts, 'VIOL_PT', 'ADDTL_PT')
viol_data <- addtl_viol_pts[viol_data, on=.(VIOL_CLS)]
first_inds <- viol_data[, .I[1], by=.(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY, VIOL_CLS)]$V1
viol_data[!first_inds, VIOL_PT:=ADDTL_PT]

# REMOVE SAME DAY VIOLATIONS AND KEEP HIGHEST RANKED VIOLATION IN A DAY
viol_data <- viol_data[order(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY, DRVR_INCID_DT, -VIOL_PT, -VIOL_CLS)]
first_inds <- viol_data[, .I[1], by=.(ST_CD, PHYS_POL_KEY, PHYS_DRVR_KEY, DRVR_INCID_DT)]$V1
viol_data <- viol_data[first_inds]

# COUNT VIOLATION BY TYPE
vio_type <- c("NP_AAF", "P_AAF", "MAJ", "MIN", "P_NAF", "NP_NAF", "DUI")
for (vio in vio_type) {viol_data[,(vio):=0]}

viol_data[,VIOL_CD:=trimws(VIOL_CD)]
viol_data[,DRVR_PNT_SRCE_CD:=trimws(DRVR_PNT_SRCE_CD)]

viol_data[VIOL_CD %in% c('AAF','AC1','CAF','CC1') & DRVR_PNT_SRCE_CD == 'P', P_AAF:= 1]
viol_data[VIOL_CD %in% c('AAF','AC1','CAF','CC1') & DRVR_PNT_SRCE_CD != 'P', NP_AAF:= 1]

viol_data[VIOL_CD %in% c('CRD','DR','FAR','FEL','FLE','FRA','HOM','LTS','RKD','SUS','WOC'), MAJ:= 1]

viol_data[VIOL_CD %in% c('DEV','FTC','FTY','IBK','IP','IT','LIC','MMV','NCS','OVW','SAF','SBV','SCH','SP1','SP2','SPD','SPO','WSR'), MIN:= 1]

viol_data[VIOL_CD %in% c('AFR','CNF','NAF') & DRVR_PNT_SRCE_CD == 'P', P_NAF:= 1]
viol_data[VIOL_CD %in% c('AFR','CNF','NAF') & DRVR_PNT_SRCE_CD != 'P', NP_NAF:= 1]

viol_data[VIOL_CD %in% c('DWI','BOT','REF'), DUI:= 1]

# LOAD MO PRESTO POL_ID_NBR
mo_pol_id <- fread("D:/Sean/8.0_CAPP/Off_Balance/BLOCK_1_2_on_2019/Data/Presto_Detail/MO_presto_POL_ID.csv")

mo_pol_id[,POL_NBR:=NULL]
mo_pol_id <- mo_pol_id[RENW_SFX_NBR>0]

mo_pol_id[,ST_CD:=as.character(ST_CD)]

# GET PHYS_POL_KEY FOR MO PRESTO POLICY
mo_policy <- merge (mo_pol_id, pol_data, by=c("ST_CD", "POL_ID_NBR", "RENW_SFX_NBR"))

# REMOVE SAME DAY STRT STOP
mo_policy <- mo_policy[POL_EFF_DT != POL_STOP_DT]

# REMOVE POLICY EFF AFTER PULLING DATE
mo_policy <- mo_policy[POL_EFF_DT<= as.Date(B1_PIF_day)]

# GET LATEST PHYS_POL_KEY
mo_policy <- mo_policy[order(ST_CD, POL_ID_NBR, -PHYS_POL_KEY)]
first_ind <- mo_policy[,.I[1], by=.(ST_CD, POL_ID_NBR)]$V1
mo_policy <- mo_policy[first_ind]



