# Set Environment
library(openxlsx)
library(data.table)
library(dplyr)

# Load data
 # Data from ILF_cOMPRISON_2018_VS_2019 Sheet1
data <- as.data.table(read.xlsx("C:/Users/A131732/Desktop/test.xlsx"))

# Group CSL
data[BIPD_CSL_CURR<=40, LIM_GRP:= "<=40K"]
data[BIPD_CSL_CURR>40 & BIPD_CSL_CURR<=100, LIM_GRP:= "<=100K"]
data[BIPD_CSL_CURR>100 & BIPD_CSL_CURR<=300, LIM_GRP:= "<=300K"]
data[BIPD_CSL_CURR>300 & BIPD_CSL_CURR<1000, LIM_GRP:= "<1M"]
data[BIPD_CSL_CURR>=1000, LIM_GRP:= ">=1M"]

# Summary
summary <- data[,.(wtd_ILF_2019 = weighted.mean(ILF_2019,ERN_EXPS_CNT),
                   wtd_CP_2019 = weighted.mean(Class_Plan_2019,ERN_EXPS_CNT),
                   wtd_ILF_2018 = weighted.mean(ILF_2018,ERN_EXPS_CNT),
                   wtd_CP_2018 = weighted.mean(Class_Plan_2018,ERN_EXPS_CNT)), 
                by = .(ST_TYPE, BTG_LIMIT, LIM_GRP)]

summary[, CP_CNG := (wtd_CP_2019/wtd_CP_2018)-1]
summary[, ILF_CNG := (wtd_ILF_2019/wtd_ILF_2018)-1]

# Export Result
fwrite(summary, "D:/Sean/ILF/Analysis/ILF_Change.csv")

## Rebased Weighted Average of Writen Premium summary
  # Rebase by State Cluster & Weight Class
  data[,rb_mean_ilf_2019:= weighted.mean(ILF_2019,BIPD_WP), by=.(ST_TYPE, BTG_LIMIT)]
  data[,rb_ILF_2019:= ILF_2019/rb_mean_ilf_2019]
  data[,rb_mean_cp_2019:= weighted.mean(Class_Plan_2019,BIPD_WP), by=.(ST_TYPE, BTG_LIMIT)]
  data[,rb_CP_2019:= Class_Plan_2019/rb_mean_cp_2019]
  
  data[,rb_mean_ilf_2018:= weighted.mean(ILF_2018,BIPD_WP), by =.(ST_TYPE, BTG_LIMIT)]
  data[,rb_ILF_2018:= ILF_2018/rb_mean_ilf_2018]
  data[,rb_mean_cp_2018:= weighted.mean(Class_Plan_2018,BIPD_WP), by=.(ST_TYPE, BTG_LIMIT)]
  data[,rb_CP_2018:= Class_Plan_2018/rb_mean_cp_2018]
  
  # Summary
  summary_2 <- data[,.(wtd_ILF_2019 = weighted.mean(rb_ILF_2019,BIPD_WP),
                     wtd_CP_2019 = weighted.mean(rb_CP_2019,BIPD_WP),
                     wtd_ILF_2018 = weighted.mean(rb_ILF_2018,BIPD_WP),
                     wtd_CP_2018 = weighted.mean(rb_CP_2018,BIPD_WP)), 
                  by = .(ST_TYPE, BTG_LIMIT, LIM_GRP)]
  
  summary_2[, CP_CNG := (wtd_CP_2019/wtd_CP_2018)-1]
  summary_2[, ILF_CNG := (wtd_ILF_2019/wtd_ILF_2018)-1]
  
  # Export Result
  fwrite(summary_2, "D:/Sean/ILF/Analysis/ILF_Change_rebase_by_WP.csv")
  