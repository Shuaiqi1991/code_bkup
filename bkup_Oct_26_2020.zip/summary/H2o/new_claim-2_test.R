#Set working environment
setwd('D:/Sean/H2O')

library("here")
library("data.table")
library("XLConnect")
library("dplyr")
library('ggplot2')
library('reshape2')
library('statmod')
library('h2o')
library('COUNT')

h2o.init()

# Import Data
dt_test <- h2o.importFile('D:/Sean/H2O/Data/TEST_DATA/new_claim-2.csv')
dt <- fread("D:/Sean/H2O/Data/TEST_DATA/new_claim-2.csv")


# Tweedie Model

independent <- c("NVVar1",
                 "NVVar2",
                 "NVVar3",
                 "NVVar4",
                 "veh_age"
)
dependent <- "y"
power <- 2.56

mdl <- h2o.glm(x = independent,
               y = dependent,
               #interaction_pairs = interaction_pairs,
               training_frame = dt_test,
               model_id = "newclaim_V325",
               seed = 44124,
               family = "tweedie",
               #weights_column = weight_var, 
               tweedie_variance_power = power,
               tweedie_link_power = 0,
               solver = 'IRLSM',
               lambda = 0,
               standardize = FALSE,
               compute_p_values = TRUE,
               beta_epsilon = 1e-9,
               remove_collinear_columns = TRUE)

# Post analysis

coef <- mdl@model$coefficients_table
phi <- mdl@model$dispersion
pred <- as.data.table(h2o.predict(mdl,dt_test))

coef
phi

# TEST WITH TEEEDIE PACKAGE WRITTEN BY PETER DUNN

tt <- glm(y~NVVar1 + NVVar2 +  NVVar3+ NVVar4 + veh_age,data = dt, 
        family=tweedie(var.power=2.56,link.power=0),na.action = na.omit)
summary(tt)

tt1 <- glm(y~1,data = dt, 
          family=tweedie(var.power=2.56,link.power=0),na.action = na.omit)
summary(tt1)

#
# MODELING WITH ROUNDED Y dt[,yrd:= round(y,digits = 0)]
#

independent <- c("NVVar1",
                 "NVVar2",
                 "NVVar3",
                 "NVVar4",
                 "veh_age"
)
dependent <- "yrd"
power <- 1.94

mdl <- h2o.glm(x = independent,
               y = dependent,
               #interaction_pairs = interaction_pairs,
               training_frame = dt_test,
               model_id = "newclaim_V325",
               seed = 44124,
               family = "tweedie",
               #weights_column = weight_var, 
               tweedie_variance_power = power,
               tweedie_link_power = 0,
               solver = 'IRLSM',
               lambda = 0,
               standardize = FALSE,
               compute_p_values = TRUE,
               beta_epsilon = 1e-9,
               remove_collinear_columns = TRUE)

# Post analysis

coef <- mdl@model$coefficients_table
phi <- mdl@model$dispersion
pred <- as.data.table(h2o.predict(mdl,dt_test))

# TEST WITH TEEEDIE PACKAGE WRITTEN BY PETER DUNN

tt <- glm(yrd~NVVar1 + NVVar2 +  NVVar3+ NVVar4 + veh_age,data = dt, 
          family=tweedie(var.power=1.94,link.power=0),na.action = na.omit)
summary(tt)

tt1 <- glm(yrd~1,data = dt, 
          family=tweedie(var.power=1.94,link.power=0),na.action = na.omit)
summary(tt1)
