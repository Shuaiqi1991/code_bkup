# SET ENVIRONMENT
setwd("D:/Sean/Interacted_Variable_Stability")

library("data.table")
library("h2o")
library("here")
library("dplyr")

# CHANGE HERE ROOT DIRECTORY
change_here <- function(new_path){
  new_root <- here:::.root_env
  new_root$f <- function(...) {file.path(new_path, ...)}
  assignInNamespace(".root_env", new_root, ns = "here")
}
change_here("D:/Sean/Interacted_Variable_Stability")

# LOAD DATA
meta <- fread(here("Data","check_interaction_meta.csv"))
  col_types <- sapply(unique(meta$types), function(x){
    meta[types==x, columns]
  })

base_data <- fread(here("Data", "check_interaction_data.csv"), colClasses = col_types)

# JOIN MKT_FROM_CR_UW
lkup_data <- fread(here("Data", "grp_lkup_2.csv"), select = c("CR_TIER_MTHD2_ModOne","UW_ROW","MKT_FROM_CR_UW_2"))
names(lkup_data) <- c("CR_TIER_MTHD2_ModOne","UW_ROW","MKT_FROM_CR_UW")

if (!is.null(base_data$MKT_FROM_CR_UW)) base_data[,MKT_FROM_CR_UW:=NULL]
base_data <- lkup_data[base_data, on=.(CR_TIER_MTHD2_ModOne, UW_ROW)]
base_data[, MKT_FROM_CR_UW:=as.factor(MKT_FROM_CR_UW)]

# LUSDOT * CR_UW_GRP
base_data[,LUSDOT_GRP:=trimws(LUSDOT_GRP)]
base_data[,MKT_FROM_CR_UW:=trimws(MKT_FROM_CR_UW)]
base_data[LUSDOT_GRP != "-998", LUSDOT_GRP_MKT_FROM_CR_UW:=paste0(as.character(LUSDOT_GRP),"||", as.character(MKT_FROM_CR_UW))]
base_data[is.na(LUSDOT_GRP_MKT_FROM_CR_UW), LUSDOT_GRP_MKT_FROM_CR_UW:="-998"]
base_data[,LUSDOT_GRP_MKT_FROM_CR_UW:=as.factor(LUSDOT_GRP_MKT_FROM_CR_UW)]

# UPDATE meta
meta <- data.table(names(base_data),sapply(base_data,class))
names(meta) <- c("columns","types")

## MODEL 
h2o.init()
# LOAD DATA
pla_bmt_data <- base_data

seed_list <- c(543,888,266,200,458,132,87,968,343,904)
var_list <- c("LUSDOT_GRP_MKT_FROM_CR_UW")
tweedie_power <- 1.653959
if (isTRUE(exists("ase_summary"))) rm(ase_summary)
if (isTRUE(exists("coef_summary"))) rm(coef_summary)
if (isTRUE(exists("adj_pp_summary"))) rm(adj_pp_summary)
ase_summary <- data.table()
coef_summary <- data.table()
adj_pp_summary <- data.table()

#meta <- fread(here("Data","pla_bmt_check_interaction_meta.csv"))
meta[, h2o_types:='unknown']
meta[types=='character', h2o_types:='string']
meta[types %in% c('integer','integer64','numeric'), h2o_types:='numeric']
meta[types=='Date', h2o_types:='time']
meta[types=='factor', h2o_types:='enum']


for(seed in seed_list){
  # PARTITION DATA
  train <- pla_bmt_data[get(paste0("seed_",seed,"_T"))=="train",]
  test <- pla_bmt_data[get(paste0("seed_",seed,"_T"))=="test",]
  fwrite(train,here("Data","train.csv"))
  fwrite(test,here("Data","test.csv"))
  train <- h2o.importFile(here("Data","train.csv"), destination_frame="train", col.types=meta$h2o_types)
  h2o_test <- h2o.importFile(here("Data","test.csv"), destination_frame="test", col.types=meta$h2o_types)
  print("partition complete")
  # GET RB_PP RB_STEP4 ASE_STP4
  mean_pp <- weighted.mean(test$PP, test$BIPD_ECY)
  if (mean_pp>0){test[,RB_PP:= 100*PP/mean_pp]} else {test[,RB_PP:=0]}
  test[,PRED_AT_STP4:= Pred_PP*Pred_PP2*Pred_PP3*Pred_PP4_All]
  mean_stp4 <- weighted.mean(test$PRED_AT_STP4, test$BIPD_ECY)
  if (mean_stp4>0){test[,RB_STP4:= 100*PRED_AT_STP4/mean_stp4]} else {test[,RB_STP4:=0]}
  test[,STP4_SE:= (RB_PP-RB_STP4)^2]
  ase_stp4 <- weighted.mean(test$STP4_SE, test$BIPD_ECY)
  print("basic SE complete")
  
  for(var in var_list){
    mdl_name <- paste0(var,"_",seed)
    print(mdl_name)
    mdl <- h2o.glm(x = var,
                   y = "ADJ_PP4",
                   # interaction_pairs = interaction_pairs,
                   training_frame = train,
                   model_id = mdl_name,
                   seed = 44124,
                   family = "tweedie",
                   weights_column = "ADJ_ECY4", 
                   tweedie_variance_power = tweedie_power,
                   tweedie_link_power = 0,
                   solver = 'IRLSM',
                   lambda = 0,
                   standardize = FALSE,
                   compute_p_values = TRUE,
                   beta_epsilon = 1e-9,
                   remove_collinear_columns = TRUE)
    # SAVE MODEL
    h2o.saveModel(mdl, path=here("Output","/h2o_model"), force=T)
    print("model saved")
    # GET PREDICTION ON TEST DATASET
    Pred_PP5_cal <- as.data.table(h2o.predict(mdl, h2o_test)[['predict']])[[1]]
    test[,Pred_PP5:= Pred_PP5_cal]
    print("prediction saved")
    # GET SE FOR STEP 5
    test[,PRED_AT_STP5:=Pred_PP5*PRED_AT_STP4]
    mean_stp5 <- weighted.mean(test$PRED_AT_STP5, test$BIPD_ECY)
    if (mean_stp5>0){test[,RB_STP5:= 100*PRED_AT_STP5/mean_stp5]} else {test[,RB_STP5:=0]}
    test[,STP5_SE:= (RB_PP-RB_STP5)^2]
    ase_stp5 <- weighted.mean(test$STP5_SE, test$BIPD_ECY)
    print("step 5 SE complete")
    # CHECK ADJ_PP AT STEP 4 AND 5
    test[,ADJ_PP5:=ADJ_PP4/Pred_PP5]
    adj_pp <- as.data.table(test[,.(ADJ_PP_STP4=weighted.mean(ADJ_PP4, BIPD_ECY),
                                    ADJ_PP_STP5=weighted.mean(ADJ_PP5, BIPD_ECY)),
                                  by=.(BMT_NO_LIV,LUSDOT_GRP_MKT_FROM_CR_UW)])
    adj_pp[,model:=mdl_name]
    print("adj_pp complete")
    
    # GET ASE
    ase <- list(mdl_name,
                ase_stp5,
                ase_stp4
    )
    ase <- as.data.table(ase)
    ase_summary <- rbind(ase_summary,ase)
    print("ase saved")
    # GET COEFFICIENTS
    coef <- as.data.table(mdl@model$coefficients_table)
    coef[,seed:= seed]
    coef_summary <- rbind(coef_summary, coef)
    print("coefficient saved")
    # GET ADJ PP
    adj_pp_summary <- rbind(adj_pp_summary, adj_pp)
    print("adj_pp saved")
    # EXPORT PREDICTION ON TEST DATASET
    # fwrite(test,here("Output","Pred_record",paste0(mdl_name,".csv")))
    # print("prediction saved")
  }
}

names(ase_summary) <- c("Model", "ASE_STP5", "ASE_STP4")
fwrite(ase_summary,here("Output","pla_bmt_pla_bmt2_ase.csv"))
fwrite(coef_summary,here("Output","pla_bmt_pla_bmt2_coef.csv"))
fwrite(adj_pp_summary,here("Output","pla_bmt_pla_bmt2_adj_pp.csv"))
