# Set environment
library(data.table)
library(here)

change_here <- function(new_path){
  new_root <- here:::.root_env
  
  new_root$f <- function(...){file.path(new_path, ...)}
  
  assignInNamespace(".root_env", new_root, ns = "here")
}
change_here("D:/Sean/8.0_CAPP/LIMIT")

## model
data <- fread(here("limit_fit_data.csv"))
data[,X_2:=X^2]
data[,X_3:=X^3]
data[,X_4:=X^4]
data[,X_5:=X^5]
data[,X_6:=X^6]

# split data <=100 limit and >100 limit, Ind has a large jump when across 100
data_alpha <- data[LIMIT<=100,]
data_beta <- data[LIMIT >100,]

btg_list <- unique(data$BTG)

## Model alpha part

if (exists("adj_r_summary")) rm(adj_r_summary)
if (exists("output_summary")) rm(output_summary)
adj_r_summary <- data.table()
output_summary <- data.table()

for (btg in btg_list) {
  data_sub <- data_alpha[BTG==btg,]
  
  order_1 <- lm(Ind~ X, data=data_sub, weight=ECY)
  order_2 <- lm(Ind~ X + X_2, data=data_sub, weight=ECY)
  order_3 <- lm(Ind~ X + X_2 + X_3, data=data_sub, weight=ECY)
  order_4 <- lm(Ind~ X + X_2 + X_3 + X_4, data=data_sub, weight=ECY)
  order_5 <- lm(Ind~ X + X_2 + X_3 + X_4 + X_5, data=data_sub, weight=ECY)
  order_6 <- lm(Ind~ X + X_2 + X_3 + X_4 + X_5 + X_6, data=data_sub, weight=ECY)
  
  adj_r <- as.data.table(
    rbind(
    summary(order_1)$adj.r.squared,
    summary(order_2)$adj.r.squared,
    summary(order_3)$adj.r.squared,
    summary(order_4)$adj.r.squared,
    summary(order_5)$adj.r.squared,
    summary(order_6)$adj.r.squared
    )
  )
  names(adj_r) <- btg
  
  adj_r_summary <- cbind(adj_r_summary, adj_r)
  
  output <- as.data.table(
    cbind(
    data_sub$BTG,
    data_sub$ECY,
    data_sub$Ind,
    order_1$fitted.values,
    order_2$fitted.values,
    order_3$fitted.values,
    order_4$fitted.values,
    order_5$fitted.values,
    order_6$fitted.values
    )
  )
  names(output) <- c("BTG","ECY","Ind", "Order_1","Order_2","Order_3","Order_4","Order_5","Order_6")

  output_summary <- cbind(output_summary,output)
}

output_summary <- cbind(data_sub$LIMIT, output_summary)
names(output_summary)[1] <- "LIMIT"

fwrite(output_summary,here("fit_result_alpha.csv"))
fwrite(adj_r_summary,here('fit_stas_alpha.csv'))

## Model beta part

if (exists("adj_r_summary")) rm(adj_r_summary)
if (exists("output_summary")) rm(output_summary)
adj_r_summary <- data.table()
output_summary <- data.table()

for (btg in btg_list) {
  data_sub <- data_beta[BTG==btg,]
  
  order_1 <- lm(Ind~ X, data=data_sub, weight=ECY)
  order_2 <- lm(Ind~ X + X_2, data=data_sub, weight=ECY)
  order_3 <- lm(Ind~ X + X_2 + X_3, data=data_sub, weight=ECY)
  order_4 <- lm(Ind~ X + X_2 + X_3 + X_4, data=data_sub, weight=ECY)
  order_5 <- lm(Ind~ X + X_2 + X_3 + X_4 + X_5, data=data_sub, weight=ECY)
  order_6 <- lm(Ind~ X + X_2 + X_3 + X_4 + X_5 + X_6, data=data_sub, weight=ECY)
  
  adj_r <- as.data.table(
    rbind(
      summary(order_1)$adj.r.squared,
      summary(order_2)$adj.r.squared,
      summary(order_3)$adj.r.squared,
      summary(order_4)$adj.r.squared,
      summary(order_5)$adj.r.squared,
      summary(order_6)$adj.r.squared
    )
  )
  names(adj_r) <- btg
  
  adj_r_summary <- cbind(adj_r_summary, adj_r)
  
  output <- as.data.table(
    cbind(
      data_sub$BTG,
      data_sub$ECY,
      data_sub$Ind,
      order_1$fitted.values,
      order_2$fitted.values,
      order_3$fitted.values,
      order_4$fitted.values,
      order_5$fitted.values,
      order_6$fitted.values
    )
  )
  names(output) <- c("BTG","ECY","Ind", "Order_1","Order_2","Order_3","Order_4","Order_5","Order_6")
  
  output_summary <- cbind(output_summary,output)
}

output_summary <- cbind(data_sub$LIMIT, output_summary)
names(output_summary)[1] <- "LIMIT"

fwrite(output_summary,here("fit_result_beta.csv"))
fwrite(adj_r_summary,here('fit_stas_beta.csv'))
