# SET ENVIRONMENT 
setwd("C:/Sean/R")

library(data.table)
library(dplyr)
library(XLConnect)
library(here)
library(tidyverse)
library(matrixStats)

# READ FACTOR TABLE
# SAS
sas <- fread(here("DATA","SAS_DRVR_FCT.csv"))
  
  level <- lapply(unique(sas$Var), function(x){
    sas[Var==x, Level]
  })
  names(level) <- unique(sas$Var)
  level <- setDT(lapply(level,'length<-',max(lengths(level))))[]
  
  coef <- lapply(unique(sas$Var), function(x){
    sas[Var==x, round(exp(coef),2)]
  })
  names(coef) <- paste0(unique(sas$Var),"_fct")
  coef <- setDT(lapply(coef,'length<-',max(lengths(coef))))[]

lk_sas <- cbind(level,coef)
lk_sas <- lk_sas %>% select(sort(names(.)))

# H2O
h2o <- fread(here("DATA"))

lk_h2o 

# DRVR_ADJ_FCT 

# Creating factor level lookup Table for Numeric Variable 
wb <- loadWorkbook(here("DATA","factor_lvl_lkup.xlsx"))
fct_lvl_lkup <- readWorksheet(wb, sheet = getSheets(wb))

for (i in 1: length(fct_lvl_lkup)){
  var <- names(fct_lvl_lkup)[i]
  table <- as.data.table(fct_lvl_lkup[i])
  names(table) <- 
    gsub(paste0(var,"."), "", names(table))
  assign(var,table)
}

# CREATE DRVR_ADJ_FCT
dt <- fread(here("DATA","DRVR_LIST.csv"))

# Clening  DRVR_AGE DRVR_PTS
dt[,AGE := DRVR_AGE]
dt[DRVR_AGE < 14, AGE := 14]
dt[DRVR_AGE > 99, AGE := 99]

dt[,POINTS := DRVR_PTS]
dt[DRVR_PTS < 0, POINTS := 0]
dt[DRVR_PTS > 50, POINTS := 50]

# MATCH FACTOR LEVEL
for (i in 1: length(fct_lvl_lkup)){
  table <- get(names(fct_lvl_lkup)[i])
  table <- subset(table,select = names(sort(sapply(table,class))))#reorder lkup table to put string in front (influence rolling join)
  count <- sum(sum(sapply(table,class) == "integer")
            ,sum(sapply(table,class) == "numeric"))
  if (count < 2){
    dt <- table[dt, on= c(names(table)[-1]), roll = -Inf]
  } else {
     for (j in 2:length(table)){
       
       roundUpList <- function(x, list=unique(table[[j]])) {
         if(length(x) != 1) stop("'x' must be of length 1")
         list[[which(x <= list)[[1]]]]
       }
       
       dt[,paste0(names(table)[j],"_round"):= 
            as.numeric(lapply(dt[[which(names(table)[j] == names(dt))[[1]]]],roundUpList))]
     }
    names(table)[-1] <- paste0(names(table)[-1],"_round")
    dt <- table[dt, on= c(names(table)[-1])]
    dt <- dt %>% select(-contains("_round"))
  }
}

# MATCH FACTOR 
for (i in 1:length(fct_lvl_lkup)){
  var <- names(fct_lvl_lkup)[i]
  fct <- paste0(names(fct_lvl_lkup)[i],"_fct")
  lk_table <- na.omit(subset(lk_sas,select = c(var,fct)))
  dt <- lk_table[dt, on = c(names(fct_lvl_lkup)[i])]
  dt <- dt %>% mutate_at(fct, ~replace(.,is.na(.), 1))
}

# PRODUCT OF ALL FACTOR
factor <- rowProds(as.matrix(dt[,grep("_fct",names(dt))]))
factor <- as.data.table(factor)
dt <- cbind(dt,factor)

# ADJ FOR PUC > # OF DRIVER



# CAPP DRVR_ADJ AT 10 to mimic the production process
dt[,drvr_adj_pr := drvr_adj]
dt[drvr_adj_pr >= 9.99, drvr_adj_pr = 9.99]

# VAGE

# REST VARIABLE

# Import Level & Coefficients

# Match factor

# archeive
dt[,grep("_fct", names(dt))]

dt[, factor:= Map('*',dt[,grep("_fct", names(dt))])]

dt[, factor:= rowProds(dt[,grep("_fct", names(dt))])]

mutate_at(vars(matches("_fct")), sum)



# IMPORTANT FUNCTION
roundUpNice <- function(x, nice=c(29,59,75,99)) {
  if(length(x) != 1) stop("'x' must be of length 1")
  as.numeric(nice[[which(x <= nice)[[1]]]])
}

dt[,paste0(names(table)[j],"round"):= lapply(dt[[grep(names(table)[j],names(dt))[[1]]]],
                                             roundUpList)]

dt[,paste0(names(table)[j],"round"):= lapply(dt[[which(names(table)[j] == names(dt))[[1]]]],
                                             roundUpList)]

test2[,paste0(names(test2)[1],"round"):= as.numeric(lapply(test2[[which(names(test2)[1] == names(test2))[[1]]]],
                                             roundUpNice))]

test2[,paste0("AGE","_round") := lapply(test2[[grep("AGE",names(test2))[[1]]]],roundUpNice)]

grep("string",sapply(table,class))

dt %>% group_by(AGE_GRP) %>% summarize(lower = min(AGE))

# AGE_PTS_GRP JOIN

test1 <- as.data.table(select(AGE_PTS_GRP, names(AGE_PTS_GRP)[2]))
test1 <- unique(test1)
test1[,paste0(names(test1),"1"):= replicate(1,test1)]

test2 <- as.data.table(select(AGE_PTS_GRP, names(AGE_PTS_GRP)[3]))
test2 <- unique(test2)
test2[,paste0(names(test2),"1"):= replicate(1,test2)]

test <- test1[test, on=.(AGE), roll = -Inf]
test <- test2[test, on=.(POINTS), roll = -Inf]

names(AGE_PTS_GRP)[-1] <- paste0(names(AGE_PTS_GRP)[-1],"1")

test <- AGE_PTS_GRP[test, on= .(AGE1, POINTS1)]

test <- BMT2_PTS_GRP[test, on= .(POINTS, BMT2), roll = -Inf]

test3 <- rep.col(test3[[2]], 1)

# TEST DATASET

test <- as.data.table(
  cbind(AGE=c(15,20,28,30,60,76),POINTS=c(0,1,2,3,4,11),
          BMT2=c("BACON","TRUCK","BACON","BACON","BACON","BACON")))
test[,AGE := as.numeric(AGE)]
test[,POINTS := as.numeric(POINTS)]

table <- as.data.table(cbind(BMT2_PTS_GRP = c("00","01","02","03","04","GE5"), POINTS=c(0,1,2,3,4,50),
        BMT2=c("BACON","BACON","BACON","BACON","BACON","BACON")))
table[,POINTS:=as.numeric(POINTS)]

test <- table[test, on= c(names(table)[-1]), roll = -Inf]


