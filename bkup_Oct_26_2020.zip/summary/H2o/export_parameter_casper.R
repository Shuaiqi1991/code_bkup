step1 <- h2o.loadModel(here("model","h2o","CAPP_BIPD_79b_LITE_mdl","CAPP_BIPD_79b_LITE_mdl_step_1"))
step2 <- h2o.loadModel(here("model","h2o","CAPP_BIPD_79b_LITE_mdl","CAPP_BIPD_79b_LITE_mdl_step_2"))
step3 <- h2o.loadModel(here("model","h2o","CAPP_BIPD_79b_LITE_mdl","CAPP_BIPD_79b_LITE_mdl_step_3"))
step4 <- h2o.loadModel(here("model","h2o","CAPP_BIPD_79b_LITE_STP4_mdl","CAPP_BIPD_79b_LITE_STP4_mdl_step_1"))

for (i in 1:3){
  
  step <- get(paste0("step",i))
  step_name <- paste0("step",i)
  
  coef_tab <- step@model$coefficients_table
  phi <- as.data.table(step@model$dispersion)
  colnames(phi) <- "coefficients" 
  phi <- data.table(names = "dispersion", phi)
  coef <- rbind(coef_tab, phi, fill = TRUE)
  fwrite(coef,file=paste0("D:/Sean/H2O/Output/CAPP_comparison/BIPD/h2o/",step_name,".csv"))
  
}

  # STEP 4
  step <- get(paste0("step",4))
  step_name <- paste0("step",4)
  
  coef_tab <- step@model$coefficients_table
  phi <- as.data.table(step@model$dispersion)
  colnames(phi) <- "coefficients" 
  phi <- data.table(names = "dispersion", phi)
  coef <- rbind(coef_tab, phi, fill = TRUE)
  fwrite(coef,file=paste0("D:/Sean/H2O/Output/CAPP_comparison/BIPD/h2o/",step_name,".csv"))

# Verify Modeling Dataset

meta <- fread(here("data","datasets","CAPP_BIPD_79C_LITE","meta.csv"))
  col_types <- lapply(unique(meta$types), function(x){
    meta[types==x,columns]
  })
  names(col_types) <- unique(meta$types)
dt <- fread(here("data","datasets","CAPP_BIPD_79C_LITE","data.csv"), colClasses = col_types)