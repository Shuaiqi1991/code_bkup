install.packages("tables")
# sET WORKING DIRECTORY 
setwd('D:/Sean/SAS/Methodology_verification')

library(data.table)
library(here)
library(tables)
library(xlsx)

# Get data 
fct_cols <- c("PREF_TRUCK",
              "PIF_DISC",
              "RADIUS_GRP",
              "USDOT_INTRACTN_GRP",
              "BCG_RAD",
              "USE_GRP",
              "BTG_LIMIT_GRP",
              "PUC_GRP_FLEET_CR_GRP_FLEET",
              "OWN_OP_FR_BMT",
              "ST_CD",
              "BMT_NO_LIV",
              "CR_GRP_ME",
              "BTG_ME",
              "LIMIT_GRP",
              "BMT_NO_LIV_UW_ROW",
              "BMT2",
              "USDOT_V41_GRPS",
              "BIPD_SYM_GRP",
              "PKG_DISC_NO_RT_NEW2",
              "BTG_VAGE",
              "cr_grp_fleet",
              "BCG_BT_BTG_BC",
              "OOS_BMT_NO_LIV",
              "PREF_TRUCK_INT",
              "UW_ROW",
              "VEH_PERS_USE_IND",
              "OOS_DRVR_POL_LVL",
              "BCG_ME",
              "ST_GRP",
              "BCG_RAD_Radius",
              "BMT_NO_LIV_CR_GRP_BUSTIER_UW_ROW",
              "OWN_OP_FR"
              )

num_cols <- c("PP",
              "ADJ_ECY1",
              "PHYS_VEH_KEY",
              "rownumber",
              "ADJ_PP1",
              "PHYS_POL_KEY",
              "BIPD_ECY",
              "ADJ_LS1",
              "TERR_MDL",
              "VAGE_RAW"
)

dt <- fread(here('Data', 'sample_var_79B_pred_BIPD.csv'),
              select = c(fct_cols, num_cols),
              colClasses = list(factor=fct_cols, numeric=num_cols))

# Calculating ADJ_PP & ECY matrix 

table <- tabular(
                  (BTG_ME+1)~(BCG_RAD_Radius+1)*
                  weighted.mean*(ADJ_PP1)*Arguments(w = ADJ_ECY1),
                  data = dt
                ) 

matrix <- as.matrix(table, format=as.numeric)
matrix

print(table)

ecy_p <- tabular(
                  (BTG_ME+1)~(BCG_RAD_Radius+1)*
                  (ADJ_PP1)*(sum),
                  data = dt
)

ecy_sum <- as.matrix(ecy_p, format = TRUE, rowLabels = FALSE, colLabels = FALSE)

ecy_sum2 <- as.matrix(head(ecy_sum,-1)) #remove last row from a matrix
ecy_sum3 <- as.matrix(ecy_sum2[,1:(ncol(ecy_sum2)-1)]) #remove last col from a matrix 

ecy_lscol <- as.numeric(ecy_sum2[,(ncol(ecy_sum2)-1)])

ecy_test <- ecy_sum3/ecy_lscol

var2_pp <- tabular(
                    (BCG_RAD_Radius+1)~(n=1)*
                    weighted.mean*(ADJ_PP1)*Arguments(w = ADJ_ECY1),
                    data = dt
)



# Calculate adj_pp vector for var 2
adj_pp_var2 <- sapply(split(data,data$BCG_RAD_Radius), 
                      function(x){
                        weighted.mean(x$ADJ_PP1,X$ADJ_ECY1)
                      })
print(adj_pp_var2)


dt <- data[,c("BCG_RAD_Radius","ADJ_PP1","ADJ_ECY1","ADJ_LS1")]

dt2 <- dt[, lapply(ADJ_PP1, weighted.mean, w=ADJ_ECY1), by=list(BCG_RAD_Radius)]
print(dt2)

matrix <- as.matrix(dt2, format = TRUE, rowLabels = TRUE, colLabels = TRUE)

print(adj_pp_var2)

