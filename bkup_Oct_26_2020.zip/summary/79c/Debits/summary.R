library(data.table)

wt.col <- 'COLL_ECY'
loss.data <- fread('D:/Joey N/CAPP/CAPP 2018/clrd-capp-coll/Analysis/Debits/Model/COLL DEBITS LOSS DATA.CSV')

wt.col <- 'BIPD_ECY'
loss.data <- fread('D:/Joey N/CAPP/CAPP 2018/clrd-capp-coll/Analysis/Debits/Model/BIPD DEBITS LOSS DATA.CSV')

summary <- loss.data[, .(LOSS=sum(LOSS_CPD_DEV_TRND_INCR),
                         ECY=sum(get(wt.col)),
                         CLM=sum(CLM_CNT_INCR),
                         PP=sum(LOSS_CPD_DEV_TRND_INCR)/sum(get(wt.col))),
                     by=.(BMT_NO_LIV)][order(BMT_NO_LIV)]
write.table(summary, 'clipboard', sep='\t', row.names=F)

summary <- loss.data[, .(LOSS=sum(LOSS_CPD_DEV_TRND_INCR),
                         ECY=sum(get(wt.col)),
                         CLM=sum(CLM_CNT_INCR),
                         PP=sum(LOSS_CPD_DEV_TRND_INCR)/sum(get(wt.col))),
                     by=.(eds_debit)][order(eds_debit)]
write.table(summary, 'clipboard', sep='\t', row.names=F)

summary <- loss.data[, .(LOSS=sum(LOSS_CPD_DEV_TRND_INCR),
                         ECY=sum(get(wt.col)),
                         CLM=sum(CLM_CNT_INCR),
                         PP=sum(LOSS_CPD_DEV_TRND_INCR)/sum(get(wt.col))),
                     by=.(BMT_NO_LIV, eds_debit)][order(BMT_NO_LIV, eds_debit)]
write.table(summary, 'clipboard', sep='\t', row.names=F)

summary <- loss.data[, .(LOSS=sum(LOSS_CPD_DEV_TRND_INCR),
                         ECY=sum(get(wt.col)),
                         CLM=sum(CLM_CNT_INCR),
                         PP=sum(LOSS_CPD_DEV_TRND_INCR)/sum(get(wt.col))),
                     by=.(uld_debit_new)][order(uld_debit_new)]
write.table(summary, 'clipboard', sep='\t', row.names=F)

summary <- loss.data[, .(LOSS=sum(LOSS_CPD_DEV_TRND_INCR),
                         ECY=sum(get(wt.col)),
                         CLM=sum(CLM_CNT_INCR),
                         PP=sum(LOSS_CPD_DEV_TRND_INCR)/sum(get(wt.col))),
                     by=.(LPNSF_DEBIT)][order(LPNSF_DEBIT)]
write.table(summary, 'clipboard', sep='\t', row.names=F)

summary <- loss.data[, .(LOSS=sum(LOSS_CPD_DEV_TRND_INCR),
                         ECY=sum(get(wt.col)),
                         CLM=sum(CLM_CNT_INCR),
                         PP=sum(LOSS_CPD_DEV_TRND_INCR)/sum(get(wt.col))),
                     by=.(BMT_NO_LIV, LPNSF_DEBIT)][order(BMT_NO_LIV, LPNSF_DEBIT)]
write.table(summary, 'clipboard', sep='\t', row.names=F)

summary <- loss.data[, .(LOSS=sum(LOSS_CPD_DEV_TRND_INCR),
                         ECY=sum(get(wt.col)),
                         CLM=sum(CLM_CNT_INCR),
                         PP=sum(LOSS_CPD_DEV_TRND_INCR)/sum(get(wt.col))),
                     by=.(VIN_DEBIT)][order(VIN_DEBIT)]
write.table(summary, 'clipboard', sep='\t', row.names=F)

